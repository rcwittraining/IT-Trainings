#!/usr/bin/env python3
"""RCW - AWSNixOps :: entry point.

Double-click Start_AWSNixOps.bat (Windows) or run:  python RCW_AWSNixOps.py
Optional flags (rarely needed):  --demo   start in demo mode (no AWS required)
"""
from __future__ import annotations

import sys
import traceback


def main() -> int:
    demo = "--demo" in sys.argv
    autoshot = None
    for arg in sys.argv:
        if arg.startswith("--autoshot="):
            autoshot = arg.split("=", 1)[1].split("|")
    try:
        from awsnixops.gui import launch
    except ImportError as e:
        print("Missing dependency:", e)
        print("Run Install_AWSNixOps.bat first (or:  pip install -r requirements.txt)")
        try:
            import tkinter.messagebox as mb
            import tkinter
            root = tkinter.Tk(); root.withdraw()
            mb.showerror("RCW - AWSNixOps",
                         "Setup problem: %s\n\nIf the message mentions 'boto3', run "
                         "Install_AWSNixOps.bat first." % e)
        except Exception:
            pass
        return 1
    try:
        launch(demo=demo, autoshot=autoshot)
    except Exception:
        traceback.print_exc()
        try:
            import tkinter.messagebox as mb
            import tkinter
            root = tkinter.Tk(); root.withdraw()
            mb.showerror("RCW - AWSNixOps", "Unexpected error:\n" + traceback.format_exc())
        except Exception:
            pass
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
