"""Parser tests for RCW - AWSNixOps (run: python tests/test_parser.py)."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from awsnixops.parser import parse, parse_one

CASES = [
    # (input, expected verb, service, resource, key params check)
    ("list ec2 instances", "list", "ec2", "instance", {}),
    ("show all instances", "list", "ec2", "instance", {"targets": ["*"]}),
    ("list running instances", "list", "ec2", "instance", {"state": "running"}),
    ("create ec2 instance web1 t3.medium with ports 22 and 80",
     "create", "ec2", "instance", {"name": "web1", "instance_type": "t3.medium",
                                   "ports": [22, 80]}),
    ("create instance web1 t3.medium with ports 22 and 80 in mumbai",
     "create", "ec2", "instance", {"region": "ap-south-1"}),
    ("launch 2 instances t3.large", "create", "ec2", "instance", {"count": 2}),
    ("create windows server win1 medium", "create", "ec2", "instance",
     {"windows": True, "instance_type": "t3.medium", "name": "win1"}),
    ("stop i-0abc123def4567890", "stop", "ec2", "instance",
     {"targets": ["i-0abc123def4567890"]}),
    ("stop all running instances", "stop", "ec2", "instance", {"targets": ["*"]}),
    ("terminate instance i-0abc123def4567890", "terminate", "ec2", "instance",
     {"targets": ["i-0abc123def4567890"]}),
    ("describe instance i-0abc123def4567890", "describe", "ec2", "instance", {}),
    ("status i-0abc123def4567890", "describe", "ec2", "instance",
     {"targets": ["i-0abc123def4567890"]}),
    ("create bucket my-test-2026", "create", "s3", "bucket",
     {"name": "my-test-2026", "targets": ["my-test-2026"]}),
    ("list buckets", "list", "s3", "bucket", {}),
    ("delete bucket my-test-2026", "delete", "s3", "bucket",
     {"targets": ["my-test-2026"]}),
    ("empty bucket my-data", "empty", "s3", "bucket", {"targets": ["my-data"]}),
    ("list objects in bucket my-data", "list", "s3", "object", {}),
    ("create vpc 10.0.0.0/16 named prod", "create", "ec2", "vpc", {}),
    ("create subnet 10.0.1.0/24 in vpc vpc-0abc123def4567890", "create", "ec2", "subnet",
     {"targets": ["vpc-0abc123def4567890"]}),
    ("create security group web-sg with ports 80 and 443", "create", "ec2", "sg",
     {"name": "web-sg", "ports": [80, 443]}),
    ("open port 8080 on sg web-sg", "open", "ec2", "sg",
     {"ports": [8080], "targets": ["web-sg"]}),
    ("allow 22 from 1.2.3.4/32 on sg-0abc123def4567890", "open", "ec2", "sg",
     {"cidrs": ["1.2.3.4/32"], "ports": [22]}),
    ("close port 22 on sg web-sg", "close", "ec2", "sg", {"ports": [22]}),
    ("create keypair deploy-key", "create", "ec2", "keypair", {"name": "deploy-key"}),
    ("list volumes", "list", "ec2", "volume", {}),
    ("create volume 100gb", "create", "ec2", "volume", {"size_gb": 100}),
    ("attach volume vol-0abc123def4567890 to instance i-0def4567890abc12",
     "attach", "ec2", "volume", {}),
    ("list functions", "list", "lambda", "function", {}),
    ("invoke function my-fn with payload {\"k\": 1}", "invoke", "lambda", "function",
     {"payload": '{"k": 1}', "targets": ["my-fn"]}),
    ("create db appdb postgres t3.micro", "create", "rds", "db",
     {"engine": "postgres", "name": "appdb", "instance_type": "db.t3.micro"}),
    ("create mysql db named blogdb", "create", "rds", "db",
     {"engine": "mysql", "name": "blogdb"}),
    ("list dbs", "list", "rds", "db", {}),
    ("stop db appdb", "stop", "rds", "db", {"targets": ["appdb"]}),
    ("create table orders with key order_id", "create", "dynamodb", "table",
     {"name": "orders", "dynamo_key": "order_id"}),
    ("list items in table orders", "list", "dynamodb", "item", {}),
    ("create user alice", "create", "iam", "user", {"name": "alice"}),
    ("attach policy AdministratorAccess to user alice", "attach", "iam", "policy",
     {"name": "AdministratorAccess", "user": "alice"}),
    ("create access key for user bob", "create", "iam", "accesskey", {"user": "bob"}),
    ("list alarms", "list", "cw", "alarm", {}),
    ("create alarm high-cpu for instance i-0abc123def4567890 at 80",
     "create", "cw", "alarm", {"name": "high-cpu", "threshold": 80.0}),
    ("logs /aws/lambda/my-fn", "tail", "logs", "loggroup",
     {"targets": ["/aws/lambda/my-fn"]}),
    ("list clusters", "list", "ecs", "cluster", {}),
    ("list eks clusters", "list", "eks", "cluster", {}),
    ("list load balancers", "list", "elb", "lb", {}),
    ("list zones", "list", "r53", "zone", {}),
    ("list records in zone example.com", "list", "r53", "record",
     {"zone": "example.com"}),
    ("deploy stack my-stack from C:\\templates\\vpc.yaml with iam", "create", "cfn", "stack",
     {"name": "my-stack", "template": "C:\\templates\\vpc.yaml"}),
    ("list stacks", "list", "cfn", "stack", {}),
    ("stack events my-stack", "tail", "cfn", "stack", {}),
    ("create topic alerts", "create", "sns", "topic", {"name": "alerts"}),
    ("publish message \"deploy done\" to topic alerts", "send", "sns", "topic",
     {"targets": ["alerts"], "message": "deploy done"}),
    ("create queue jobs", "create", "sqs", "queue", {"name": "jobs"}),
    ("send message \"job 1\" to queue jobs", "send", "sqs", "queue",
     {"targets": ["jobs"], "message": "job 1"}),
    ("list secrets", "list", "secrets", "secret", {}),
    ("create secret my-api-key with value abc123", "create", "secrets", "secret",
     {"name": "my-api-key", "value": "abc123"}),
    ("list distributions", "list", "cf", "distribution", {}),
    ("list asgs", "list", "asg", "asg", {}),
    ("create alarm high-cpu for instance i-0abc at 80 for 5 minutes", "create", "cw",
     "alarm", {"period": 300}),
    ("boto3 firehose list_delivery_streams {}", "", "", "", {"special": "boto3"}),
    ("aws s3 ls", "", "", "", {"special": "cli"}),
    ("help", "", "", "", {"special": "help"}),
    ("whoami", "", "", "", {"special": "whoami"}),
    ("use region mumbai", "", "", "", {"special": "set_region"}),
    ("cost last 7 days", "", "", "", {"special": "cost", "days": 7}),
    ("cost this month", "", "", "", {"special": "cost", "month": True}),
    ("open ec2 console", "", "", "", {"special": "console"}),
]

fails = 0
for raw, verb, svc, res, check in CASES:
    cmd = parse_one(raw)
    problems = []
    if check.get("special"):
        if cmd.special != check["special"]:
            problems.append(f"special={cmd.special!r} want {check['special']!r}")
        if check.get("days") and cmd.params.get("days") != check["days"]:
            problems.append(f"days={cmd.params.get('days')!r}")
        if check.get("month") and not cmd.params.get("month"):
            problems.append("month missing")
    else:
        if cmd.special:
            problems.append(f"unexpected special={cmd.special}")
        if (cmd.verb, cmd.service, cmd.resource) != (verb, svc, res):
            problems.append(f"(verb,svc,res)=({cmd.verb},{cmd.service},{cmd.resource}) "
                            f"want ({verb},{svc},{res})")
        for k, v in check.items():
            got = cmd.targets if k == "targets" else cmd.params.get(k)
            ok_ = got == v
            if k == "ports" and isinstance(got, list) and isinstance(v, list):
                ok_ = sorted(got) == sorted(v)
            if not ok_:
                problems.append(f"{k}={got!r} want {v!r}")
    if problems:
        fails += 1
        print(f"FAIL  {raw!r}\n      {'; '.join(problems)}")

# chaining
multi = parse("list buckets then list instances; cost this month")
assert len(multi) == 3, f"chaining broke: {multi}"
assert [m.special or m.verb for m in multi] == ["list", "list", "cost"]

print(f"\n{len(CASES) + 1} parser checks, {fails} failed")
sys.exit(1 if fails else 0)
