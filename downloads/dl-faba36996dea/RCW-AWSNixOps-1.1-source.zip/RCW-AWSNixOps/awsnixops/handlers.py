"""RCW - AWSNixOps executor: runs parsed commands against AWS with boto3.

Every method returns a list of Msg objects for the GUI chat log.
Destructive operations go through a confirmation callback (GUI dialog), and a
dry-run mode prints the plan without touching AWS.
"""
from __future__ import annotations

import json
import os
import re
import string
import random
import subprocess
import shutil
import webbrowser
from datetime import datetime, timezone, timedelta
from pathlib import Path

from .core import (Msg, info, ok, warn, err, head, mono, AuditLog,
                   KEYS_DIR, region_name_for, REGIONS)
from .parser import ParsedCommand

DESTRUCTIVE = {"delete", "terminate", "stop", "empty", "close", "reboot", "detach"}

# error-code -> human hint
HINTS = {
    "AuthFailure": "Check that your AWS credentials are valid and the account is active.",
    "InvalidClientTokenId": "The Access Key ID is not valid. Re-enter credentials via 'Configure AWS'.",
    "InvalidAccessKeyId": "The Access Key ID does not exist. Re-enter credentials via 'Configure AWS'.",
    "SignatureDoesNotMatch": "The Secret Access Key is wrong. Re-enter credentials via 'Configure AWS'.",
    "AccessDenied": "Your IAM identity lacks permission for this action (aws:iam policies).",
    "UnauthorizedOperation": "Your IAM identity lacks permission for this action.",
    "OptInRequired": "This account/region requires opt-in before use.",
    "InvalidParameterValue": "One of the parameters is invalid - check names/IDs and retry.",
    "MissingCredentials": "No AWS credentials found. Click 'Configure AWS' in the sidebar.",
    "NoCredentials": "No AWS credentials found. Click 'Configure AWS' in the sidebar.",
    "BucketAlreadyExists": "S3 bucket names are globally unique - pick another name.",
    "BucketNotEmpty": "Bucket is not empty. Run: empty bucket <name>  first.",
    "DependencyViolation": "Resource is still in use (e.g. SG attached to an instance).",
    "InvalidInstanceID.NotFound": "Instance ID not found in this region.",
    "ValidationError": "AWS rejected a parameter value - check the syntax of your prompt.",
    "Throttling": "AWS is throttling requests - wait a few seconds and retry.",
}

TABLE_MAX_ROWS = 60


def _ts() -> str:
    return datetime.now().strftime("%H:%M:%S")


def _age(iso: str | None) -> str:
    if not iso:
        return "-"
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        d = datetime.now(timezone.utc) - dt
        days = d.days
        if days:
            return f"{days}d"
        h = d.seconds // 3600
        return f"{h}h" if h else f"{d.seconds // 60}m"
    except Exception:
        return "-"


def _table(headers: list[str], rows: list[list], title: str = "") -> list[Msg]:
    widths = [len(h) for h in headers]
    rows = rows[:TABLE_MAX_ROWS]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = min(max(widths[i], len(str(cell))), 44)
    fmt = "  ".join(f"{{:{w}}}" for w, _ in zip(widths, headers))
    lines = []
    if title:
        lines.append(title)
    lines.append(fmt.format(*[h.upper() for h in headers]))
    lines.append("  ".join("-" * w for w in widths))
    for row in rows:
        cells = [str(c)[:44] for c in row]
        lines.append(fmt.format(*cells))
    if not rows:
        lines.append("(no results)")
    out = [mono("\n".join(lines))]
    return out


def _money(v) -> str:
    return f"${float(v):,.2f}"


def _random_password(n: int = 16) -> str:
    alphabet = string.ascii_letters + string.digits
    pw = [random.choice(string.ascii_uppercase), random.choice(string.ascii_lowercase),
          random.choice(string.digits)]
    pw += [random.choice(alphabet) for _ in range(n - 3)]
    random.shuffle(pw)
    return "".join(pw)


class Executor:
    def __init__(self, mgr, dry_run: bool = False,
                 confirm=None, audit: AuditLog | None = None) -> None:
        self.mgr = mgr
        self.dry_run = dry_run
        self.confirm = confirm or (lambda text: True)
        self.audit = audit or AuditLog()

    # ------------------------------------------------------------------ dispatch
    def execute(self, cmd: ParsedCommand) -> list[Msg]:
        try:
            msgs = self._dispatch(cmd)
        except Exception as e:
            msgs = [self._error_msg(e)]
        summary = f"{len(msgs)} message(s); " + ", ".join(sorted({m.kind for m in msgs}))
        self.audit.log(cmd.raw, self.mgr.profile, self.mgr.region, summary)
        return msgs

    def _dispatch(self, cmd: ParsedCommand) -> list[Msg]:
        if cmd.special:
            return getattr(self, f"_sp_{cmd.special}", lambda c: [err(f"Unknown: {c.special}")])(cmd)
        if cmd.verb in DESTRUCTIVE:
            label = cmd.raw
            if self.dry_run:
                return [head(f"[DRY-RUN] {label}"),
                        info("Nothing was executed (dry-run mode is ON).")]
            if not self.confirm(f"{cmd.verb.upper()} :: {cmd.raw}\n\nProceed?"):
                return [warn("Cancelled by user.")]
        elif self.dry_run and cmd.verb != "list" and cmd.verb != "describe":
            return [head(f"[DRY-RUN] {cmd.raw}"),
                    info("Nothing was executed (dry-run mode is ON).")]
        fn = self.ACTIONS.get((cmd.service, cmd.resource, cmd.verb))
        if not fn:
            close = [k for k in self.ACTIONS if k[0] == cmd.service and k[1] == cmd.resource]
            hint = ""
            if close:
                verbs = sorted({k[2] for k in close})
                hint = f"\nSupported verbs for {cmd.resource}: {', '.join(verbs)}"
            return [err(f"I don't know how to '{cmd.verb}' '{cmd.resource}' yet.{hint}\n"
                        f"Type 'help' to see everything I can do. For anything else: "
                        f"boto3 <service> <operation> {{json args}}")]
        return fn(self, cmd)

    def _error_msg(self, e: Exception) -> Msg:
        name = type(e).__name__
        resp = getattr(e, "response", None)
        if resp:
            code = resp.get("Error", {}).get("Code", name)
            message = resp.get("Error", {}).get("Message", str(e))
            hint = HINTS.get(code, "")
            return err(f"AWS error [{code}]: {message}" + (f"\nHint: {hint}" if hint else ""))
        if name in ("NoCredentialsError", "NoRegionError", "TokenRetrievalError"):
            return err("Not connected to AWS. Click 'Connect' or 'Configure AWS' in the sidebar.")
        if str(e).startswith("Not connected"):
            return warn(str(e))
        if name in ("EndpointConnectionError", "ConnectTimeoutError", "ReadTimeoutError"):
            return err("Could not reach AWS (network/endpoint issue). Check internet/proxy and region.")
        if name == "ProfileNotFound":
            return err("AWS profile not found. Use 'Configure AWS' to enter credentials.")
        if getattr(self.mgr, "demo", False) or "demo" in str(e).lower():
            return warn(f"{e}")
        return err(f"{name}: {e}")

    def c(self, service: str):
        return self.mgr.client(service)

    # ------------------------------------------------------------------ specials
    def _sp_help(self, cmd) -> list[Msg]:
        from .help_text import HELP
        return [mono(HELP)]

    def _sp_whoami(self, cmd) -> list[Msg]:
        if getattr(self.mgr, "demo", False):
            return [info("DEMO MODE - not connected to a real AWS account.\n"
                         "Click 'Disconnect', then 'Configure AWS' to connect for real.")]
        ident = self.c("sts").get_caller_identity()
        arn = ident.get("Arn", "?")
        kind = "user" if ":user/" in arn else ("role" if ":sts/" in arn or ":assumed-role/" in arn else "root")
        return [ok(f"Account : {ident.get('Account')}\nIdentity : {arn}\nType     : {kind}\n"
                   f"Region   : {self.mgr.region} ({region_name_for(self.mgr.region)})\n"
                   f"Profile  : {self.mgr.profile}")]

    def _sp_regions(self, cmd) -> list[Msg]:
        return _table(["region", "name"], [[c, n] for c, n in REGIONS], "AWS REGIONS")

    def _sp_clear(self, cmd) -> list[Msg]:
        return [Msg("clear", "")]

    def _sp_audit(self, cmd) -> list[Msg]:
        entries = self.audit.tail(30)
        if not entries:
            return [info("Audit log is empty (stored in the logs/ folder).")]
        return _table(["when", "profile", "region", "command", "result"],
                      [[e.get("ts"), e.get("profile"), e.get("region"),
                        e.get("command", "")[:40], e.get("result", "")[:40]] for e in entries],
                      "RECENT ACTIONS (audit log)")

    def _sp_connect(self, cmd) -> list[Msg]:
        return self._sp_whoami(cmd)

    def _sp_disconnect(self, cmd) -> list[Msg]:
        self.mgr.disconnect()
        return [info("Disconnected.")]

    def _sp_set_region(self, cmd) -> list[Msg]:
        from .core import region_code_for
        code = region_code_for(cmd.special_arg)
        if not code:
            return [err(f"Unrecognized region '{cmd.special_arg}'. Type 'regions' to list them.")]
        self.mgr.set_region(code)
        return [ok(f"Region switched to {code} ({region_name_for(code)}).")]

    def _sp_set_profile(self, cmd) -> list[Msg]:
        name = cmd.special_arg.strip()
        try:
            self.mgr.connect(profile=name)
            return [ok(f"Connected with profile '{name}' as\n{self.mgr.identity.get('arn')}")]
        except Exception as e:
            return [self._error_msg(e)]

    def _sp_console(self, cmd) -> list[Msg]:
        svc = (cmd.special_arg or "").replace(" ", "-").strip()
        urls = {"ec2": "ec2", "s3": "s3", "lambda": "lambda", "rds": "rds",
                "dynamodb": "dynamodb", "iam": "iam", "cloudwatch": "cloudwatch",
                "ecs": "ecs", "eks": "eks", "route53": "route53", "sqs": "sqs",
                "sns": "sns", "cloudformation": "cloudformation", "ecr": "ecr",
                "elb": "ec2/v2", "vpc": "vpc", "secrets": "secretsmanager",
                "kms": "kms", "cloudfront": "cloudfront", "api": "apigateway"}
        path = urls.get(svc, "console")
        url = f"https://console.aws.amazon.com/{path}/home?region={self.mgr.region}"
        webbrowser.open(url)
        return [ok(f"Opening AWS console ({path}) in your browser...")]

    def _sp_unknown(self, cmd) -> list[Msg]:
        return [err("I couldn't understand that prompt.\nType 'help' to see everything "
                    "I understand - or use raw mode:\n"
                    "  boto3 <service> <operation> {json args}")]

    def _sp_cli(self, cmd) -> list[Msg]:
        if not shutil.which("aws"):
            return [err("The AWS CLI is not installed on this machine.\n"
                        "Use the built-in equivalent instead:\n"
                        "  boto3 <service> <operation> {json args}\n"
                        "Example: boto3 ec2 describe_vpcs {}")]
        r = subprocess.run(["aws"] + cmd.special_arg.split(),
                           capture_output=True, text=True, timeout=120)
        out = (r.stdout or r.stderr).strip()[:6000]
        return [mono(out or "(no output)")]

    def _sp_boto3(self, cmd) -> list[Msg]:
        args = cmd.special_arg.split(None, 2)
        if len(args) < 2:
            return [err("Usage: boto3 <service> <operation> [json args]\n"
                        "Example: boto3 ec2 describe_instances {{\"Filters\":[{{\"Name\":\"instance-state-name\",\"Values\":[\"running\"]}}]}}")]
        service, op = args[0], args[1]
        kwargs = {}
        if len(args) == 3:
            try:
                kwargs = json.loads(args[2])
            except json.JSONDecodeError as e:
                return [err(f"Invalid JSON arguments: {e}")]
        if not self.confirm(f"Run raw API call:\n{service}.{op}({args[2] if len(args) == 3 else ''}) ?"):
            return [warn("Cancelled by user.")]
        resp = getattr(self.c(service), op)(**kwargs)
        return [mono(json.dumps(resp, indent=2, default=str)[:8000])]

    def _sp_cost(self, cmd) -> list[Msg]:
        if getattr(self.mgr, "demo", False):
            from .demo import demo_cost
            return demo_cost()
        days = cmd.params.get("days", 7)
        today = datetime.now().date()
        if cmd.params.get("month"):
            start = today.replace(day=1)
        elif cmd.params.get("today"):
            start = today
        else:
            start = today - timedelta(days=days)
        end = today + timedelta(days=1)
        resp = self.c("ce").get_cost_and_usage(
            TimePeriod={"Start": start.isoformat(), "End": end.isoformat()},
            Granularity="DAILY", Metrics=["UnblendedCost"],
            GroupBy=[{"Type": "DIMENSION", "Key": "SERVICE"}])
        by_service: dict[str, float] = {}
        for g in resp.get("ResultsByTime", []):
            for grp in g.get("Groups", []):
                amt = float(grp["Metrics"]["UnblendedCost"]["Amount"])
                key = grp["Keys"][0].replace("AWS ", "").replace("Amazon ", "")
                if amt:
                    by_service[key] = by_service.get(key, 0.0) + amt
        if not by_service:
            return [ok(f"No cost data for {start} .. {end} "
                       f"(also check Cost Explorer is enabled for your account).")]
        total = sum(by_service.values())
        rows = [[svc, _money(v), f"{v / total * 100:.0f}%"]
                for svc, v in sorted(by_service.items(), key=lambda kv: -kv[1])]
        out = _table(["service", "cost", "share"], rows,
                     f"COST {start} .. {end}")
        out.append(ok(f"TOTAL: {_money(total)}"))
        return out

    # ------------------------------------------------------------------ ec2: instances
    def _ami_for(self, windows: bool, ubuntu: bool) -> tuple[str, str]:
        if windows:
            return self.c("ssm").get_parameter(
                Name="/aws/service/ami-windows-latest/Windows_Server-2022-English-Full-Base"
            )["Parameter"]["Value"], "Windows Server 2022"
        if ubuntu:
            resp = self.c("ec2").describe_images(
                Owners=["099720109477"],
                Filters=[{"Name": "name",
                          "Values": ["ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-*"]}])["Images"]
            latest = sorted(resp, key=lambda x: x["CreationDate"])[-1]
            return latest["ImageId"], "Ubuntu 22.04"
        return self.c("ssm").get_parameter(
            Name="/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64"
        )["Parameter"]["Value"], "Amazon Linux 2023"

    def _ensure_keypair(self, name: str | None) -> tuple[str, Msg | None]:
        ec2 = self.c("ec2")
        existing = {k["KeyName"] for k in ec2.describe_key_pairs().get("KeyPairs", [])}
        if name:
            if name not in existing:
                raise ValueError(f"Key pair '{name}' does not exist. Keys: {sorted(existing) or 'none'}")
            return name, None
        if existing:
            return sorted(existing)[0], None
        kname = "rcw-awsnixops"
        kp = ec2.create_key_pair(KeyName=kname)
        KEYS_DIR.mkdir(exist_ok=True)
        (KEYS_DIR / f"{kname}.pem").write_text(kp["KeyMaterial"], encoding="utf-8")
        return kname, warn(f"Created new key pair '{kname}' - private key saved to "
                           f"keys\\{kname}.pem (keep it safe, needed for SSH/RDP).")

    def _ensure_sg(self, name: str, ports: list[int]) -> tuple[str, list[Msg]]:
        ec2 = self.c("ec2")
        msgs: list[Msg] = []
        vpc_id = self._default_vpc_id()
        sgs = ec2.describe_security_groups(
            Filters=[{"Name": "group-name", "Values": [name]},
                     {"Name": "vpc-id", "Values": [vpc_id]}]).get("SecurityGroups", [])
        if sgs:
            sg_id = sgs[0]["GroupId"]
        else:
            sg = ec2.create_security_group(GroupName=name, Description="Created by RCW-AWSNixOps",
                                           VpcId=vpc_id)
            sg_id = sg["GroupId"]
            msgs.append(info(f"Created security group {name} ({sg_id})."))
        existing = {p["FromPort"] for p in
                    ec2.describe_security_groups(GroupIds=[sg_id])["SecurityGroups"][0]
                    .get("IpPermissions", []) if p.get("FromPort")}
        for port in ports or []:
            if port in existing:
                continue
            ec2.authorize_security_group_ingress(
                GroupId=sg_id, IpProtocol="tcp", FromPort=port, ToPort=port,
                CidrIp="0.0.0.0/0")
            msgs.append(warn(f"Opened TCP port {port} to the internet (0.0.0.0/0) on {name}."))
        return sg_id, msgs

    def _default_vpc_id(self) -> str:
        vpcs = self.c("ec2").describe_vpcs(Filters=[{"Name": "isDefault", "Values": ["true"]}])["Vpcs"]
        if not vpcs:
            raise ValueError("No default VPC found in this region. Create one first: create vpc 10.0.0.0/16")
        return vpcs[0]["VpcId"]

    def _ec2_instance_create(self, cmd) -> list[Msg]:
        p = cmd.params
        name = p.get("name") or "rcw-instance"
        itype = p.get("instance_type", "t3.medium")
        count = int(p.get("count", 1))
        ports = [int(x) for x in (p.get("ports") or [22])]
        if not ports:
            ports = [22]
        ami_id, ami_desc = self._ami_for(p.get("windows"), p.get("ubuntu"))
        key_name, key_msg = self._ensure_keypair(p.get("key_name"))
        sg_name = p.get("sg_name") or "rcw-awsnixops-default"
        sg_id, sg_msgs = self._ensure_sg(sg_name, ports)
        tags = [{"Key": k, "Value": v} for k, v in p.get("tags", {}).items()] if isinstance(p.get("tags"), dict) else []
        tags.append({"Key": "Name", "Value": name})
        tags.append({"Key": "ManagedBy", "Value": "RCW-AWSNixOps"})
        resp = self.c("ec2").run_instances(
            ImageId=ami_id, InstanceType=itype, MinCount=count, MaxCount=count,
            KeyName=key_name, SecurityGroupIds=[sg_id], TagSpecifications=[{
                "ResourceType": "instance", "Tags": tags}])
        ids = [i["InstanceId"] for i in resp["Instances"]]
        msgs = [ok(f"Launched {len(ids)} x {itype} ({ami_desc} {ami_id})"),
                mono("  " + "\n  ".join(ids)),
                info(f"SSH: ssh -i keys/{key_name}.pem ec2-user@<public-ip>   "
                     f"(it takes ~1 min to boot; see: list instances)")]
        msgs.extend(sg_msgs)
        if key_msg:
            msgs.append(key_msg)
        return msgs

    def _instance_rows(self, cmd, states: list[str] | None = None,
                       names: list[str] | None = None) -> list[dict]:
        filters = []
        if states:
            filters.append({"Name": "instance-state-name", "Values": states})
        if names and names != ["*"]:
            filters.append({"Name": "tag:Name", "Values": names})
        insts = []
        token = None
        while True:
            kw = {"Filters": filters} if filters else {}
            if token:
                kw["NextToken"] = token
            resp = self.c("ec2").describe_instances(**kw)
            for r in resp.get("Reservations", []):
                insts.extend(r.get("Instances", []))
            token = resp.get("NextToken")
            if not token:
                break
        return insts

    @staticmethod
    def _iname(inst: dict) -> str:
        for t in inst.get("Tags", []):
            if t["Key"] == "Name":
                return t["Value"]
        return "-"

    def _ec2_instance_list(self, cmd) -> list[Msg]:
        state = cmd.params.get("state")
        states = [state] if state and state != "all" else None
        if states is None and cmd.verb == "list" and not cmd.targets:
            states = None  # show all
        insts = self._instance_rows(cmd, states,
                                    cmd.targets if cmd.targets != ["*"] else None)
        rows = [[i["InstanceId"], self._iname(i), i.get("InstanceType", "-"),
                 i.get("State", {}).get("Name", "-"),
                 (i.get("PublicIpAddress") or "-"),
                 i.get("Placement", {}).get("AvailabilityZone", "-"),
                 _age(i.get("LaunchTime"))] for i in insts]
        return _table(["instance", "name", "type", "state", "public ip", "az", "age"], rows,
                      f"EC2 INSTANCES ({self.mgr.region}) - {len(rows)}")

    def _ec2_instance_describe(self, cmd) -> list[Msg]:
        insts = self._instance_rows(cmd, None, [t for t in cmd.targets if t != "*"] or None)
        if not insts:
            return [warn("No matching instances.")]
        out = []
        for i in insts[:10]:
            lines = [f"{i['InstanceId']}  {self._iname(i)}",
                     f"  state    : {i.get('State', {}).get('Name')}",
                     f"  type     : {i.get('InstanceType')}",
                     f"  ami      : {i.get('ImageId')}",
                     f"  private  : {i.get('PrivateIpAddress', '-')}",
                     f"  public   : {i.get('PublicIpAddress', '-')}",
                     f"  az       : {i.get('Placement', {}).get('AvailabilityZone', '-')}",
                     f"  launched : {i.get('LaunchTime')}",
                     f"  sg       : {', '.join(g.get('GroupName', '?') for g in i.get('SecurityGroups', []))}"]
            out.append(mono("\n".join(lines)))
        return out

    def _ec2_instance_lifecycle(self, cmd, op: str, label: str) -> list[Msg]:
        targets = [t for t in cmd.targets if t != "*"]
        if cmd.targets == ["*"] or (not targets and cmd.params.get("name")):
            states = {"stop": ["running"], "start": ["stopped"],
                      "reboot": ["running"], "terminate": None}.get(op)
            insts = self._instance_rows(cmd, states,
                                        [cmd.params["name"]] if cmd.params.get("name") else None)
            targets = [i["InstanceId"] for i in insts]
            if not targets:
                return [warn("Nothing matched.")]
        if not targets:
            return [err(f"Which instance? Example: {label} i-1234abcd")]
        fn = getattr(self.c("ec2"), op + "_instances")
        fn(InstanceIds=targets)
        return [ok(f"{label} sent for: {', '.join(targets)}")]

    def _ec2_instance_start(self, cmd):  return self._ec2_instance_lifecycle(cmd, "start", "start")
    def _ec2_instance_stop(self, cmd):   return self._ec2_instance_lifecycle(cmd, "stop", "stop")
    def _ec2_instance_reboot(self, cmd): return self._ec2_instance_lifecycle(cmd, "reboot", "reboot")
    def _ec2_instance_terminate(self, cmd):
        return self._ec2_instance_lifecycle(cmd, "terminate", "terminate")

    # ------------------------------------------------------------------ ec2: vpc/sg/keys/ebs
    def _ec2_vpc_list(self, cmd) -> list[Msg]:
        vpcs = self.c("ec2").describe_vpcs().get("Vpcs", [])
        rows = [[v["VpcId"], v.get("CidrBlock", "-"), v.get("IsDefault", False),
                 self._iname_v(v), _age(v.get("CreateTime"))] for v in vpcs]
        return _table(["vpc", "cidr", "default", "name", "age"], rows, "VPCs")

    @staticmethod
    def _iname_v(res: dict) -> str:
        for t in res.get("Tags", []):
            if t["Key"] == "Name":
                return t["Value"]
        return "-"

    def _ec2_vpc_create(self, cmd) -> list[Msg]:
        p = cmd.params
        cidr = next((c for c in p.get("cidrs", []) if c.endswith("/16") or "/" in c), None) \
            or next((c for c in p.get("extra", []) if re.match(r"^\d+\.\d+\.\d+\.\d+/\d+$", c)), None)
        if not cidr:
            return [err("Add a CIDR, e.g.: create vpc 10.0.0.0/16 named prod")]
        vpc = self.c("ec2").create_vpc(CidrBlock=cidr)
        name = p.get("name") or "rcw-vpc"
        self.c("ec2").create_tags(Resources=[vpc["Vpc"]["VpcId"]], Tags=[
            {"Key": "Name", "Value": name}, {"Key": "ManagedBy", "Value": "RCW-AWSNixOps"}])
        return [ok(f"Created VPC {vpc['Vpc']['VpcId']} ({cidr}) named '{name}'.")]

    def _ec2_vpc_delete(self, cmd) -> list[Msg]:
        if not cmd.targets:
            return [err("Which VPC? Example: delete vpc vpc-123")]
        self.c("ec2").delete_vpc(VpcId=cmd.targets[0])
        return [ok(f"Deleted VPC {cmd.targets[0]}")]

    def _ec2_subnet_list(self, cmd) -> list[Msg]:
        subs = self.c("ec2").describe_subnets().get("Subnets", [])
        rows = [[s["SubnetId"], s.get("VpcId", "-"), s.get("CidrBlock", "-"),
                 s.get("AvailabilityZone", "-"), self._iname_v(s),
                 "public" if s.get("MapPublicIpOnLaunch") else "private"] for s in subs]
        return _table(["subnet", "vpc", "cidr", "az", "name", "ips"], rows, "SUBNETS")

    def _ec2_subnet_create(self, cmd) -> list[Msg]:
        p = cmd.params
        cidr = next((c for c in p.get("cidrs", [])) , None) or \
            next((c for c in p.get("extra", []) if re.match(r"^\d+\.\d+\.\d+\.\d+/\d+$", c)), None)
        if not cidr:
            return [err("Add a CIDR, e.g.: create subnet 10.0.1.0/24 in vpc vpc-123 named web-a")]
        vpc_id = p.get("vpc_id") or next(
            (t for t in cmd.targets if t.startswith("vpc-")), None) or self._default_vpc_id()
        sub = self.c("ec2").create_subnet(VpcId=vpc_id, CidrBlock=cidr)
        name = p.get("name") or "rcw-subnet"
        self.c("ec2").create_tags(Resources=[sub["Subnet"]["SubnetId"]],
                                  Tags=[{"Key": "Name", "Value": name}])
        return [ok(f"Created subnet {sub['Subnet']['SubnetId']} ({cidr}) in {vpc_id} named '{name}'")]

    def _sg_by_name_or_id(self, ref: str) -> dict:
        sgs = self.c("ec2").describe_security_groups(
            Filters=[{"Name": "group-name", "Values": [ref]}]).get("SecurityGroups", [])
        if sgs:
            return sgs[0]
        sgs = self.c("ec2").describe_security_groups(GroupIds=[ref]).get("SecurityGroups", [])
        return sgs[0] if sgs else {}

    def _ec2_sg_list(self, cmd) -> list[Msg]:
        sgs = self.c("ec2").describe_security_groups().get("SecurityGroups", [])
        rows = [[g["GroupId"], g["GroupName"], g.get("VpcId", "-"),
                 "; ".join(f"{pp.get('IpProtocol')}"
                           f"{':' + str(pp.get('FromPort')) if pp.get('FromPort') else ''}"
                           f" from {','.join(ip.get('CidrIp', '?') for ip in pp.get('IpRanges', []))}"
                           for pp in g.get("IpPermissions", []))[:60] or "-"] for g in sgs]
        return _table(["group id", "name", "vpc", "inbound"], rows, "SECURITY GROUPS")

    def _ec2_sg_create(self, cmd) -> list[Msg]:
        p = cmd.params
        name = p.get("name")
        if not name:
            return [err("Name it, e.g.: create security group web-sg with ports 80 and 443")]
        desc = f"Created by RCW-AWSNixOps ({datetime.now():%Y-%m-%d})"
        vpc_id = p.get("vpc_id") or self._default_vpc_id()
        sg = self.c("ec2").create_security_group(GroupName=name, Description=desc, VpcId=vpc_id)
        msgs = [ok(f"Created security group '{name}' ({sg['GroupId']}) in {vpc_id}")]
        for port in p.get("ports") or []:
            self.c("ec2").authorize_security_group_ingress(
                GroupId=sg["GroupId"], IpProtocol="tcp", FromPort=port, ToPort=port,
                CidrIp="0.0.0.0/0")
            msgs.append(warn(f"Opened TCP {port} to 0.0.0.0/0."))
        return msgs

    def _ec2_sg_delete(self, cmd) -> list[Msg]:
        ref = cmd.targets[0] if cmd.targets else cmd.params.get("name")
        if not ref:
            return [err("Which security group? e.g. delete sg web-sg")]
        sg = self._sg_by_name_or_id(ref)
        if not sg:
            return [err(f"Security group '{ref}' not found.")]
        self.c("ec2").delete_security_group(GroupId=sg["GroupId"])
        return [ok(f"Deleted security group {sg['GroupName']} ({sg['GroupId']})")]

    def _ec2_sg_open(self, cmd) -> list[Msg]:
        p = cmd.params
        ref = cmd.targets[0] if cmd.targets else None
        if not ref:
            return [err("Which group? e.g. open port 8080 on sg web-sg")]
        sg = self._sg_by_name_or_id(ref)
        if not sg:
            return [err(f"Security group '{ref}' not found.")]
        ports = p.get("ports") or []
        cidrs = p.get("cidrs") or ["0.0.0.0/0"]
        proto = p.get("protocol", "tcp")
        if not ports and not p.get("all_traffic"):
            return [err("Which port? e.g. open port 8080 on sg web-sg")]
        perms = []
        if p.get("all_traffic"):
            perms.append({"IpProtocol": "-1", "IpRanges": [{"CidrIp": c} for c in cidrs]})
        for port in ports:
            perms.append({"IpProtocol": proto, "FromPort": port, "ToPort": port,
                          "IpRanges": [{"CidrIp": c} for c in cidrs]})
        self.c("ec2").authorize_security_group_ingress(GroupId=sg["GroupId"],
                                                       IpPermissions=perms)
        return [ok(f"Opened on {sg['GroupName']}: " +
                   ", ".join(f"{proto}/{pt} from {', '.join(cidrs)}" for pt in ports) +
                   (" all traffic" if p.get("all_traffic") else ""))]

    def _ec2_sg_close(self, cmd) -> list[Msg]:
        p = cmd.params
        ref = cmd.targets[0] if cmd.targets else None
        if not ref:
            return [err("Which group? e.g. close port 22 on sg web-sg")]
        sg = self._sg_by_name_or_id(ref)
        if not sg:
            return [err(f"Security group '{ref}' not found.")]
        ports = p.get("ports") or []
        cidrs = p.get("cidrs") or ["0.0.0.0/0"]
        proto = p.get("protocol", "tcp")
        if not ports and not p.get("all_traffic"):
            return [err("Which port? e.g. close port 22 on sg web-sg")]
        perms = []
        if p.get("all_traffic"):
            perms.append({"IpProtocol": "-1", "IpRanges": [{"CidrIp": c} for c in cidrs]})
        for port in ports:
            perms.append({"IpProtocol": proto, "FromPort": port, "ToPort": port,
                          "IpRanges": [{"CidrIp": c} for c in cidrs]})
        try:
            self.c("ec2").revoke_security_group_ingress(GroupId=sg["GroupId"],
                                                        IpPermissions=perms)
        except Exception as e:
            if "InvalidPermission.NotFound" in str(e):
                return [warn("That rule did not exist - nothing to remove.")]
            raise
        return [ok(f"Closed on {sg['GroupName']}: " + ", ".join(f"{proto}/{pt}" for pt in ports))]

    def _ec2_keypair_create(self, cmd) -> list[Msg]:
        name = cmd.params.get("name") or f"rcw-key-{datetime.now():%Y%m%d%H%M}"
        if cmd.params.get("name") and any(k["KeyName"] == name for k in
                                          self.c("ec2").describe_key_pairs().get("KeyPairs", [])):
            return [warn(f"Key pair '{name}' already exists.")]
        kp = self.c("ec2").create_key_pair(KeyName=name)
        KEYS_DIR.mkdir(exist_ok=True)
        path = KEYS_DIR / f"{name}.pem"
        path.write_text(kp["KeyMaterial"], encoding="utf-8")
        return [ok(f"Created key pair '{name}'.\nPrivate key saved to: {path}\n"
                   f"Move it somewhere safe - AWS never shows it again.")]

    def _ec2_keypair_list(self, cmd) -> list[Msg]:
        keys = self.c("ec2").describe_key_pairs().get("KeyPairs", [])
        return _table(["key name", "type", "fingerprint"],
                      [[k["KeyName"], k.get("KeyType", "-"), k.get("KeyFingerprint", "-")[:24]]
                       for k in keys], "EC2 KEY PAIRS")

    def _ec2_keypair_delete(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which key pair? e.g. delete keypair my-key")]
        self.c("ec2").delete_key_pair(KeyName=name)
        return [ok(f"Deleted key pair '{name}'.")]

    def _ec2_volume_list(self, cmd) -> list[Msg]:
        vols = self.c("ec2").describe_volumes().get("Volumes", [])
        rows = [[v["VolumeId"], v.get("Size"), v.get("VolumeType", "-"), v.get("State"),
                 v.get("AvailabilityZone", "-"),
                 ", ".join(a.get("InstanceId", "?") for a in v.get("Attachments", [])) or "-",
                 _age(v.get("CreateTime"))] for v in vols]
        return _table(["volume", "gb", "type", "state", "az", "attached", "age"], rows, "EBS VOLUMES")

    def _ec2_volume_create(self, cmd) -> list[Msg]:
        p = cmd.params
        size = p.get("size_gb") or 8
        vtype = p.get("volume_type", "gp3")
        vol = self.c("ec2").create_volume(Size=int(size), VolumeType=vtype,
                                          AvailabilityZone=p.get("az") or f"{self.mgr.region}a")
        return [ok(f"Created volume {vol['VolumeId']} ({size} GB {vtype}). "
                   f"Attach with: attach volume <id> to instance <id>")]

    def _ec2_volume_delete(self, cmd) -> list[Msg]:
        if not cmd.targets:
            return [err("Which volume? e.g. delete volume vol-123")]
        self.c("ec2").delete_volume(VolumeId=cmd.targets[0])
        return [ok(f"Deleted volume {cmd.targets[0]}")]

    def _ec2_volume_attach(self, cmd) -> list[Msg]:
        ids = [t for t in cmd.targets if t != "*"]
        if len(ids) < 2:
            return [err("Usage: attach volume vol-123 to instance i-456")]
        vol = next((t for t in ids if t.startswith("vol-")), ids[0])
        inst = next((t for t in ids if t.startswith("i-")), ids[1])
        self.c("ec2").attach_volume(VolumeId=vol, InstanceId=inst, Device="/dev/sdf")
        return [ok(f"Attaching {vol} to {inst} as /dev/sdf.")]

    def _ec2_snapshot_list(self, cmd) -> list[Msg]:
        snaps = self.c("ec2").describe_snapshots(OwnerIds=["self"]).get("Snapshots", [])
        snaps = sorted(snaps, key=lambda s: s.get("StartTime", ""), reverse=True)
        rows = [[s["SnapshotId"], s.get("VolumeId", "-"), s.get("State"),
                 (s.get("Description") or "-")[:40], _age(str(s.get("StartTime")))]
                for s in snaps[:TABLE_MAX_ROWS]]
        return _table(["snapshot", "volume", "state", "description", "age"], rows, "SNAPSHOTS")

    def _ec2_snapshot_create(self, cmd) -> list[Msg]:
        vol = next((t for t in cmd.targets if t.startswith("vol-")), None)
        if not vol:
            return [err("Which volume? e.g. create snapshot of volume vol-123")]
        snap = self.c("ec2").create_snapshot(VolumeId=vol, Description="RCW-AWSNixOps snapshot")
        return [ok(f"Snapshot {snap['SnapshotId']} started for {vol}.")]

    def _ec2_snapshot_delete(self, cmd) -> list[Msg]:
        snap = next((t for t in cmd.targets if t.startswith("snap-")), None)
        if not snap:
            return [err("Which snapshot? e.g. delete snapshot snap-123")]
        self.c("ec2").delete_snapshot(SnapshotId=snap)
        return [ok(f"Deleted snapshot {snap}")]

    def _ec2_eip_list(self, cmd) -> list[Msg]:
        addrs = self.c("ec2").describe_addresses().get("Addresses", [])
        rows = [[a.get("PublicIp", "-"), a.get("AllocationId", "-"),
                 a.get("AssociationId") and a.get("InstanceId", "-") or "-",
                 a.get("Domain", "-")] for a in addrs]
        return _table(["public ip", "allocation", "instance", "scope"], rows, "ELASTIC IPs")

    def _ec2_eip_create(self, cmd) -> list[Msg]:
        resp = self.c("ec2").allocate_address(Domain="vpc")
        return [ok(f"Allocated Elastic IP {resp.get('PublicIp')} ({resp.get('AllocationId')}).\n"
                   f"Assign it: associate eip {resp.get('AllocationId')} with instance i-123")]

    def _ec2_eip_delete(self, cmd) -> list[Msg]:
        ref = cmd.targets[0] if cmd.targets else None
        if not ref:
            return [err("Which EIP? e.g. release eip eipalloc-123 (or the IP itself)")]
        if not ref.startswith("eipalloc-"):
            found = [a for a in self.c("ec2").describe_addresses().get("Addresses", [])
                     if a.get("PublicIp") == ref]
            if not found:
                return [err(f"EIP '{ref}' not found.")]
            ref = found[0]["AllocationId"]
        self.c("ec2").release_address(AllocationId=ref)
        return [ok(f"Released {ref}")]

    def _ec2_eip_associate(self, cmd) -> list[Msg]:
        ids = [t for t in cmd.targets if t != "*"]
        alloc = next((t for t in ids if t.startswith("eipalloc-") or IP_RE_like(t)), None)
        inst = next((t for t in ids if t.startswith("i-")), None)
        if not inst:
            return [err("Which instance? e.g. associate eip 3.1.2.3 with instance i-123")]
        if alloc and not alloc.startswith("eipalloc-"):
            alloc = next((a["AllocationId"] for a in self.c("ec2").describe_addresses()
                          .get("Addresses", []) if a.get("PublicIp") == alloc), alloc)
        if not alloc or not alloc.startswith("eipalloc-"):
            free = [a for a in self.c("ec2").describe_addresses().get("Addresses", [])
                    if not a.get("AssociationId")]
            if not free:
                return [err("No free Elastic IP. Allocate one first: create eip")]
            alloc = free[0]["AllocationId"]
        self.c("ec2").associate_address(AllocationId=alloc, InstanceId=inst)
        return [ok(f"Associating {alloc} with {inst}.")]

    def _ec2_image_list(self, cmd) -> list[Msg]:
        amis = self.c("ec2").describe_images(Owners=["self"]).get("Images", [])
        amis = sorted(amis, key=lambda a: a.get("CreationDate", ""), reverse=True)
        rows = [[a["ImageId"], a.get("Name", "-")[:34], a.get("State", "-"),
                 a.get("CreationDate", "-")[:10]] for a in amis[:TABLE_MAX_ROWS]]
        return _table(["ami", "name", "state", "created"], rows, "YOUR AMIS")

    def _ec2_image_describe(self, cmd) -> list[Msg]:
        ami = cmd.targets[0] if cmd.targets else None
        if not ami:
            return [err("Which AMI? e.g. describe ami ami-123")]
        a = self.c("ec2").describe_images(ImageIds=[ami])["Images"][0]
        return [mono("\n".join([f"{a['ImageId']}  {a.get('Name', '-')}",
                                f"  state  : {a.get('State')}",
                                f"  owner  : {a.get('OwnerId')}",
                                f"  size   : {a.get('RootDeviceType')} / {a.get('Architecture')}",
                                f"  created: {a.get('CreationDate')}"]))]

    # ------------------------------------------------------------------ s3
    def _s3_bucket_create(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else cmd.params.get("name")
        if not name:
            return [err("Name the bucket: create bucket my-unique-name-123")]
        if not re.match(r"^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$", name):
            return [err(f"'{name}' is not a valid S3 bucket name (lowercase letters, digits, "
                        "dots/hyphens only, 3-63 chars, globally unique).")]
        kw = {"Bucket": name}
        if self.mgr.region != "us-east-1":
            kw["CreateBucketConfiguration"] = {"LocationConstraint": self.mgr.region}
        self.c("s3").create_bucket(**kw)
        try:
            self.c("s3").put_public_access_block(Bucket=name, PublicAccessBlockConfiguration={
                "BlockPublicAcls": True, "IgnorePublicAcls": True,
                "BlockPublicPolicy": True, "RestrictPublicBuckets": True})
        except Exception:
            pass
        return [ok(f"Created bucket s3://{name} (region {self.mgr.region}, public access blocked).")]

    def _s3_bucket_list(self, cmd) -> list[Msg]:
        buckets = self.c("s3").list_buckets().get("Buckets", [])
        rows = [[b["Name"], str(b.get("CreationDate", ""))[:10]] for b in buckets]
        return _table(["bucket", "created"], rows, f"S3 BUCKETS - {len(rows)}")

    def _s3_bucket_describe(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which bucket? e.g. describe bucket my-bucket")]
        s3 = self.c("s3")
        loc = s3.get_bucket_location(Bucket=name).get("LocationConstraint") or "us-east-1"
        n = obj_n = size = 0
        pg = s3.get_paginator("list_objects_v2")
        for page in pg.paginate(Bucket=name):
            n += page.get("KeyCount", 0)
            for o in page.get("Contents", []):
                size += o["Size"]
                obj_n += 1
        return [info(f"Bucket      : s3://{name}\nRegion      : {loc}\n"
                     f"Objects     : {obj_n}\nTotal size  : {size / 1e6:,.1f} MB")]

    def _s3_bucket_empty(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which bucket? e.g. empty bucket my-bucket")]
        s3 = self.c("s3")
        deleted = 0
        pg = s3.get_paginator("list_objects_v2")
        for page in pg.paginate(Bucket=name):
            objs = [{"Key": o["Key"]} for o in page.get("Contents", [])]
            if objs:
                s3.delete_objects(Bucket=name, Delete={"Objects": objs})
                deleted += len(objs)
        return [ok(f"Deleted {deleted} object(s) from s3://{name}. "
                   f"(Versioned objects, if any, are kept - delete via console or boto3.)")]

    def _s3_bucket_delete(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which bucket? e.g. delete bucket my-bucket")]
        try:
            self.c("s3").delete_bucket(Bucket=name)
        except Exception as e:
            if "BucketNotEmpty" in str(e):
                return [err("Bucket not empty. Run: empty bucket " + name + " then delete bucket " + name)]
            raise
        return [ok(f"Deleted bucket s3://{name}")]

    def _s3_object_list(self, cmd) -> list[Msg]:
        bucket = cmd.targets[0] if cmd.targets and cmd.targets[0] != "*" else cmd.params.get("bucket")
        if not bucket:
            cand = [t for t in cmd.params.get("extra", []) if re.match(r"^[a-z0-9][a-z0-9.-]{2,}$", t)]
            bucket = cand[0] if cand else None
        if not bucket:
            return [err("Which bucket? e.g. list objects in bucket my-data")]
        prefix = cmd.params.get("prefix", "")
        resp = self.c("s3").list_objects_v2(Bucket=bucket, Prefix=prefix, MaxKeys=50)
        rows = [[o["Key"], f"{o['Size'] / 1024:,.1f} KB", str(o.get("LastModified", ""))[:16]]
                for o in resp.get("Contents", [])]
        return _table(["key", "size", "modified"], rows,
                      f"s3://{bucket}/{prefix} - {resp.get('KeyCount', 0)} of "
                      f"{resp.get('KeyCount')} shown")

    def _s3_object_upload(self, cmd) -> list[Msg]:
        extra = cmd.params.get("extra", [])
        bucket = cmd.targets[0] if cmd.targets else None
        if bucket and bucket.startswith(("i-", "s3://")):
            bucket = bucket.replace("s3://", "")
        path = next((t for t in extra if PATH_hint(t)), None) or cmd.params.get("path")
        if not bucket or not path:
            return [err("Usage: upload <file-path> to bucket <name> [as prefix/name.ext]")]
        p = Path(path).expanduser()
        if not p.is_file():
            return [err(f"File not found: {p}")]
        key = cmd.params.get("as_key") or p.name
        self.c("s3").upload_file(str(p), bucket, key)
        return [ok(f"Uploaded {p.name} ({p.stat().st_size / 1024:,.1f} KB) -> s3://{bucket}/{key}")]

    def _s3_object_download(self, cmd) -> list[Msg]:
        return self._s3_download(cmd)

    def _s3_download(self, cmd) -> list[Msg]:
        extra = cmd.params.get("extra", [])
        bucket = cmd.targets[0] if cmd.targets else None
        if bucket and bucket.startswith("s3://"):
            bucket = bucket.replace("s3://", "")
        key = None
        dest = None
        for t in extra:
            if PATH_hint(t):
                dest = t
            elif t and t not in bucket and "/" in t or t.endswith((".pdf", ".zip", ".txt", ".csv", ".json")):
                key = t.lstrip("/")
        key = key or cmd.params.get("as_key")
        if not bucket or not key:
            return [err("Usage: download bucket <name> <key/path> to <local-folder>")]
        dest_dir = Path(dest or "~/Downloads").expanduser()
        dest_dir.mkdir(parents=True, exist_ok=True)
        out = dest_dir / Path(key).name
        self.c("s3").download_file(bucket, key, str(out))
        return [ok(f"Downloaded s3://{bucket}/{key} -> {out}")]

    def _s3_object_delete(self, cmd) -> list[Msg]:
        bucket = cmd.targets[0] if cmd.targets else None
        key = cmd.params.get("as_key") or next(
            (t for t in cmd.params.get("extra", []) if "/" in t and not PATH_hint(t)), None)
        if not bucket or not key:
            return [err("Usage: delete object <bucket>/<key>")]
        if not key and bucket and "/" in bucket:
            bucket, key = bucket.split("/", 1)
        self.c("s3").delete_object(Bucket=bucket, Key=key)
        return [ok(f"Deleted s3://{bucket}/{key}")]

    # ------------------------------------------------------------------ lambda
    def _lambda_function_list(self, cmd) -> list[Msg]:
        fns = self.c("lambda").list_functions().get("Functions", [])
        rows = [[f["FunctionName"], f.get("Runtime", "-"), f.get("Handler", "-"),
                 f.get("Timeout"), f.get("LastModified", "-")[:10], _age(f.get("LastModified"))]
                for f in fns]
        return _table(["function", "runtime", "handler", "timeout", "modified", "age"], rows,
                      "LAMBDA FUNCTIONS")

    def _lambda_function_describe(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which function? e.g. describe function my-fn")]
        f = self.c("lambda").get_function(FunctionName=name)
        cfg = f["Configuration"]
        return [mono("\n".join([
            f"{cfg['FunctionName']}  ({cfg.get('Runtime')})",
            f"  role     : {cfg.get('Role')}",
            f"  handler  : {cfg.get('Handler')}",
            f"  memory   : {cfg.get('MemorySize')} MB   timeout: {cfg.get('Timeout')}s",
            f"  modified : {cfg.get('LastModified')}",
            f"  code size: {cfg.get('CodeSize', 0) / 1024:,.0f} KB"]))]

    def _lambda_function_invoke(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which function? e.g. invoke function my-fn with payload {\"k\":1}")]
        payload = cmd.params.get("payload") or "{}"
        try:
            json.loads(payload)
        except Exception:
            payload = json.dumps({"message": payload})
        resp = self.c("lambda").invoke(FunctionName=name, Payload=payload)
        body = resp["Payload"].read().decode("utf-8", "replace")[:3000]
        return [ok(f"{name} -> status {resp['StatusCode']}"),
                mono("RESPONSE:\n" + body)]

    def _lambda_function_delete(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which function? e.g. delete function my-fn")]
        self.c("lambda").delete_function(FunctionName=name)
        return [ok(f"Deleted Lambda function '{name}'")]

    def _lambda_function_create(self, cmd) -> list[Msg]:
        p = cmd.params
        name = p.get("name")
        zipp = next((t for t in p.get("extra", []) if t.endswith(".zip")), None) or \
            next((t for t in [p.get("template")] if t), None)
        if not name or not zipp:
            return [err("Usage: create function my-fn from C:\\path\\code.zip "
                        "with role myLambdaRole runtime python3.12")]
        zp = Path(zipp).expanduser()
        if not zp.is_file():
            return [err(f"Zip not found: {zp}")]
        role_name = p.get("role_name") or "lambda-execute"
        try:
            role_arn = self.c("iam").get_role(RoleName=role_name)["Role"]["Arn"]
        except Exception:
            try:
                trust = json.dumps({"Version": "2012-10-17", "Statement": [{"Effect": "Allow",
                        "Principal": {"Service": "lambda.amazonaws.com"}, "Action": "sts:AssumeRole"}]})
                role_arn = self.c("iam").create_role(RoleName=role_name,
                        AssumeRolePolicyDocument=trust)["Role"]["Arn"]
                self.c("iam").attach_role_policy(RoleName=role_name,
                        PolicyArn="arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole")
            except Exception as e:
                return [err(f"Could not find/create role '{role_name}': {e}")]
        runtime = p.get("runtime", "python3.12")
        self.c("lambda").create_function(
            FunctionName=name, Runtime=runtime, Role=role_arn,
            Handler=p.get("handler", "lambda_function.lambda_handler"),
            Code={"ZipFile": zp.read_bytes()}, Timeout=int(p.get("timeout", 30)))
        return [ok(f"Created Lambda '{name}' ({runtime}, role {role_name}).\n"
                   f"Test it: invoke function {name} with payload {{}}")]

    # ------------------------------------------------------------------ rds
    def _rds_db_list(self, cmd) -> list[Msg]:
        dbs = self.c("rds").describe_db_instances().get("DBInstances", [])
        rows = [[d["DBInstanceIdentifier"], d.get("Engine", "-"),
                 d.get("DBInstanceClass", "-"), d.get("DBInstanceStatus"),
                 d.get("Endpoint", {}).get("Address", "-"),
                 d.get("StorageAllocated", "-")] for d in dbs]
        return _table(["identifier", "engine", "class", "status", "endpoint", "gb"], rows,
                      "RDS INSTANCES")

    def _rds_db_describe(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which DB? e.g. describe db mydb")]
        d = self.c("rds").describe_db_instances(DBInstanceIdentifier=name)["DBInstances"][0]
        return [mono("\n".join([
            d["DBInstanceIdentifier"],
            f"  engine   : {d.get('Engine')} {d.get('EngineVersion', '')}",
            f"  class    : {d.get('DBInstanceClass')}",
            f"  status   : {d.get('DBInstanceStatus')}",
            f"  endpoint : {d.get('Endpoint', {}).get('Address', '-')}"
                         f":{d.get('Endpoint', {}).get('Port', '-')}",
            f"  storage  : {d.get('StorageAllocated')} GB",
            f"  multi-az : {d.get('MultiAZ')}"]))]

    def _rds_db_create(self, cmd) -> list[Msg]:
        p = cmd.params
        ident = (p.get("name") or "rcw-db").lower().replace("_", "-")
        engine = p.get("engine", "mysql")
        if engine == "postgres":
            engine = "postgres"
        itype = p.get("instance_type") or "db.t3.micro"
        if not itype.startswith("db."):
            itype = "db.t3.micro"
        passwd = _random_password()
        kw = dict(DBInstanceIdentifier=ident, Engine=engine, DBInstanceClass=itype,
                  AllocatedStorage=int(p.get("size_gb", 20)), MasterUsername="admin",
                  MasterUserPassword=passwd, PubliclyAccessible=True,
                  BackupRetentionPeriod=0, StorageType="gp2")
        if engine == "mysql":
            kw["DBName"] = "appdb"
        self.c("rds").create_db_instance(**kw)
        return [ok(f"Creating RDS '{ident}' ({engine} {itype}) - takes 5-10 minutes.\n"
                   f"  master user: admin\n  master pass: {passwd}\n"
                   f"  (save this password now - shown only once)"),
                info("Check progress: list dbs")]

    def _rds_db_delete(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which DB? e.g. delete db mydb")]
        self.c("rds").delete_db_instance(DBInstanceIdentifier=name,
                                         SkipFinalSnapshot=True)
        return [ok(f"Deleting RDS '{name}' (final snapshot skipped) - takes several minutes.")]

    def _rds_db_stop(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which DB? e.g. stop db mydb")]
        self.c("rds").stop_db_instance(DBInstanceIdentifier=name)
        return [ok(f"Stopping RDS '{name}'.")]

    def _rds_db_start(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which DB? e.g. start db mydb")]
        self.c("rds").start_db_instance(DBInstanceIdentifier=name)
        return [ok(f"Starting RDS '{name}'.")]

    # ------------------------------------------------------------------ dynamodb
    def _dynamodb_table_list(self, cmd) -> list[Msg]:
        names = self.c("dynamodb").list_tables().get("TableNames", [])
        return _table(["table"], [[n] for n in names], "DYNAMODB TABLES")

    def _dynamodb_table_create(self, cmd) -> list[Msg]:
        p = cmd.params
        name = p.get("name")
        if not name:
            return [err("Name it: create table orders with key order_id")]
        pk = p.get("dynamo_key") or next(
            (t for t in p.get("extra", []) if not PATH_hint(t) and t != name), None) or "id"
        sk = p.get("dynamo_sort_key")
        kf = [{"AttributeName": pk, "AttributeType": "S"}]
        defs = list(kf)
        schema = [{"AttributeName": pk, "KeyType": "HASH"}]
        if sk and sk != pk:
            defs.append({"AttributeName": sk, "AttributeType": "S"})
            schema.append({"AttributeName": sk, "KeyType": "RANGE"})
        self.c("dynamodb").create_table(TableName=name, KeySchema=schema,
                                        AttributeDefinitions=defs,
                                        BillingMode="PAY_PER_REQUEST")
        return [ok(f"Created DynamoDB table '{name}' (pk: {pk}"
                   + (f", sk: {sk}" if sk and sk != pk else "")
                   + ", pay-per-request).")]

    def _dynamodb_table_describe(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which table? e.g. describe table orders")]
        d = self.c("dynamodb").describe_table(TableName=name)["Table"]
        return [info(f"Table       : {d['TableName']}\nStatus      : {d['TableStatus']}\n"
                     f"Items       : {d.get('ItemCount', 0)}\nSize        : {d.get('TableSizeBytes', 0) / 1e6:,.1f} MB\n"
                     f"Key schema  : " + ", ".join(f"{k['AttributeName']}({k['KeyType']})" for k in d["KeySchema"]))]

    def _dynamodb_table_delete(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which table? e.g. delete table orders")]
        self.c("dynamodb").delete_table(TableName=name)
        return [ok(f"Deleted table '{name}'")]

    def _dynamodb_item_list(self, cmd) -> list[Msg]:
        p = cmd.params
        table = cmd.targets[0] if cmd.targets else next(
            (t for t in p.get("extra", []) if not PATH_hint(t)), None)
        if not table:
            return [err("Which table? e.g. list items in table orders")]
        resp = self.c("dynamodb").scan(TableName=table, Limit=int(p.get("limit", 20)))
        rows = [[json.dumps(it, default=str)[:100]] for it in resp.get("Items", [])]
        return _table(["item (json)"], rows, f"ITEMS in '{table}' (first {len(rows)})")

    def _dynamodb_item_upload(self, cmd) -> list[Msg]:
        payload = cmd.params.get("payload")
        table = cmd.targets[0] if cmd.targets else None
        if not table or not payload:
            return [err('Usage: put item {"id":"1","name":"x"} into table orders')]
        try:
            item = json.loads(payload)
        except Exception as e:
            return [err(f"Invalid JSON: {e}")]
        from decimal import Decimal
        def dec(o):
            if isinstance(o, float):
                return Decimal(str(o))
            if isinstance(o, dict):
                return {k: dec(v) for k, v in o.items()}
            if isinstance(o, list):
                return [dec(v) for v in o]
            return o
        self.c("dynamodb").put_item(TableName=table, Item=dec(item))
        return [ok(f"Put item into '{table}'.")]

    # ------------------------------------------------------------------ iam
    def _iam_user_list(self, cmd) -> list[Msg]:
        users = self.c("iam").list_users().get("Users", [])
        rows = [[u["UserName"], str(u.get("CreateDate", ""))[:10],
                 u.get("PasswordLastUsed") and str(u["PasswordLastUsed"])[:10] or "-"]
                for u in users]
        return _table(["user", "created", "last login"], rows, "IAM USERS")

    def _iam_user_create(self, cmd) -> list[Msg]:
        name = cmd.params.get("name") or (cmd.targets[0] if cmd.targets else None)
        if not name:
            return [err("Name the user: create user alice")]
        self.c("iam").create_user(UserName=name)
        return [ok(f"Created IAM user '{name}'."),
                info(f"Give access: attach policy AdministratorAccess to user {name}  "
                     f"(or create access key for user {name})")]

    def _iam_user_delete(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which user? e.g. delete user alice")]
        iam = self.c("iam")
        keys = iam.list_access_keys(UserName=name).get("AccessKeyMetadata", [])
        for k in keys:
            iam.delete_access_key(UserName=name, AccessKeyId=k["AccessKeyId"])
        iam.delete_user(UserName=name)
        return [ok(f"Deleted IAM user '{name}' (and {len(keys)} access key(s)).")]

    def _iam_role_list(self, cmd) -> list[Msg]:
        roles = self.c("iam").list_roles().get("Roles", [])
        rows = [[r["RoleName"], str(r.get("CreateDate", ""))[:10]] for r in roles]
        return _table(["role", "created"], rows, "IAM ROLES")

    def _iam_policy_list(self, cmd) -> list[Msg]:
        pols = self.c("iam").list_policies(Scope="Local").get("Policies", [])
        rows = [[p["PolicyName"], str(p.get("CreateDate", ""))[:10], p.get("Arn").split(":")[-1]]
                for p in pols]
        out = _table(["policy (customer managed)", "created", "path"], rows, "IAM POLICIES")
        out.append(info("AWS-managed policies (e.g. AdministratorAccess, AmazonS3FullAccess) "
                        "are attached by name - see 'attach policy'."))
        return out

    def _policy_arn(self, name: str) -> str | None:
        try:
            return self.c("iam").get_policy(PolicyArn=name)["Policy"]["Arn"]
        except Exception:
            pass
        for scope in ("AWS", "Local"):
            p = self.c("iam").get_paginator("list_policies")
            for page in p.paginate(Scope=scope):
                for pol in page.get("Policies", []):
                    if pol["PolicyName"] == name:
                        return pol["Arn"]
        return None

    def _iam_policy_attach(self, cmd) -> list[Msg]:
        p = cmd.params
        pol = p.get("name") or (cmd.targets[0] if cmd.targets else None)
        user = p.get("user")
        role = p.get("role_name")
        if not pol or not (user or role):
            return [err("Usage: attach policy AmazonS3FullAccess to user alice "
                        "(or 'to role myRole')")]
        arn = self._policy_arn(pol)
        if not arn:
            return [err(f"Policy '{pol}' not found (AWS-managed or customer-managed).")]
        if user:
            self.c("iam").attach_user_policy(UserName=user, PolicyArn=arn)
            return [ok(f"Attached '{pol}' to user '{user}'.")]
        self.c("iam").attach_role_policy(RoleName=role, PolicyArn=arn)
        return [ok(f"Attached '{pol}' to role '{role}'.")]

    def _iam_policy_detach(self, cmd) -> list[Msg]:
        p = cmd.params
        pol = p.get("name") or (cmd.targets[0] if cmd.targets else None)
        user = p.get("user")
        role = p.get("role_name")
        if not pol or not (user or role):
            return [err("Usage: detach policy <name> from user <user>")]
        arn = self._policy_arn(pol)
        if not arn:
            return [err(f"Policy '{pol}' not found.")]
        if user:
            self.c("iam").detach_user_policy(UserName=user, PolicyArn=arn)
            return [ok(f"Detached '{pol}' from user '{user}'.")]
        self.c("iam").detach_role_policy(RoleName=role, PolicyArn=arn)
        return [ok(f"Detached '{pol}' from role '{role}'.")]

    def _iam_accesskey_create(self, cmd) -> list[Msg]:
        user = cmd.params.get("user")
        if not user:
            return [err("Which user? e.g. create access key for user alice")]
        resp = self.c("iam").create_access_key(UserName=user)["AccessKey"]
        return [warn(f"Access key for '{user}' (shown ONCE, store safely):\n"
                     f"  AccessKeyId     : {resp['AccessKeyId']}\n"
                     f"  SecretAccessKey : {resp['SecretAccessKey']}")]

    # ------------------------------------------------------------------ cloudwatch
    def _cw_alarm_list(self, cmd) -> list[Msg]:
        alarms = self.c("cloudwatch").describe_alarms().get("MetricAlarms", [])
        rows = [[a["AlarmName"], a.get("StateValue"), a.get("MetricName"),
                 str(a.get("Threshold")) + " " + str(a.get("ComparisonOperator")),
                 a.get("Dimensions")[0].get("Value", "-") if a.get("Dimensions") else "-"]
                for a in alarms]
        return _table(["alarm", "state", "metric", "trigger", "resource"], rows, "CLOUDWATCH ALARMS")

    def _cw_alarm_describe(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which alarm? e.g. describe alarm high-cpu")]
        a = self.c("cloudwatch").describe_alarms(AlarmNames=[name]).get("MetricAlarms", [])
        if not a:
            return [warn("No such alarm.")]
        a = a[0]
        return [info(f"{a['AlarmName']}\n  state    : {a.get('StateValue')} "
                     f"(since {str(a.get('StateUpdatedTimestamp'))[:19]})\n"
                     f"  metric   : {a.get('Namespace')}/{a.get('MetricName')}\n"
                     f"  trigger  : {a.get('ComparisonOperator')} {a.get('Threshold')} "
                     f"for {a.get('EvaluationPeriods')} x {a.get('Period', 300)}s")]

    def _cw_alarm_create(self, cmd) -> list[Msg]:
        p = cmd.params
        name = p.get("name") or "rcw-high-cpu"
        inst = next((t for t in cmd.targets if t.startswith("i-")), None)
        threshold = float(p.get("threshold", 80))
        period = int(p.get("period", 300))
        if not inst:
            return [err("Which instance? e.g. create alarm high-cpu for instance i-123 at 80")]
        self.c("cloudwatch").put_metric_alarm(
            AlarmName=name, Namespace="AWS/EC2", MetricName="CPUUtilization",
            Statistic="Average", Period=period, EvaluationPeriods=2,
            Threshold=threshold, ComparisonOperator="GreaterThanThreshold",
            TreatMissingData="notBreaching", AlarmActions=[],
            Dimensions=[{"Name": "InstanceId", "Value": inst}])
        return [ok(f"Alarm '{name}' created: CPU > {threshold}% for "
                   f"{2 * period // 60} min on {inst}.\n"
                   f"(No SNS notification attached - create a topic then ask me to add it)")]

    def _cw_alarm_delete(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which alarm? e.g. delete alarm high-cpu")]
        self.c("cloudwatch").delete_alarms(AlarmNames=[name])
        return [ok(f"Deleted alarm '{name}'")]

    def _logs_loggroup_list(self, cmd) -> list[Msg]:
        groups = self.c("logs").describe_log_groups().get("logGroups", [])
        rows = [[g["logGroupName"], g.get("retentionInDays", "-"),
                 f"{g.get('storedBytes', 0) / 1e6:,.1f} MB"] for g in groups]
        return _table(["log group", "retention", "size"], rows, "CLOUDWATCH LOG GROUPS")

    def _logs_tail(self, cmd) -> list[Msg]:
        group = cmd.targets[0] if cmd.targets else cmd.params.get("name")
        if not group or group == "*":
            return [err("Which log group? e.g. logs /aws/lambda/my-fn")]
        logs = self.c("logs")
        streams = logs.describe_log_streams(logGroupName=group,
                                            orderBy="LastEventTime", descending=True,
                                            limit=1).get("logStreams", [])
        if not streams:
            return [warn(f"No log streams in '{group}' yet.")]
        ev = logs.get_log_events(logGroupName=group,
                                 logStreamName=streams[0]["logStreamName"], limit=30)
        lines = [f"{e['timestamp']}  {e['message']}".rstrip() for e in ev.get("events", [])]
        return [mono(f"TAIL {group} (latest {len(lines)} lines):\n" +
                     ("\n".join(lines) or "(empty)"))]

    # ------------------------------------------------------------------ containers
    def _ecs_cluster_list(self, cmd) -> list[Msg]:
        arns = self.c("ecs").list_clusters().get("clusterArns", [])
        rows = [[a.split("/")[-1]] for a in arns]
        return _table(["ecs cluster"], rows, "ECS CLUSTERS")

    def _ecs_service_list(self, cmd) -> list[Msg]:
        cluster = cmd.params.get("cluster") or "default"
        svcs = self.c("ecs").list_services(cluster=cluster).get("serviceArns", [])
        rows = [[s.split("/")[-1]] for s in svcs]
        return _table([f"service (cluster {cluster})"], rows, "ECS SERVICES")

    def _ecs_taskdef_list(self, cmd) -> list[Msg]:
        fams = self.c("ecs").list_task_definitions().get("taskDefinitionArns", [])
        rows = [[f.split("/")[-1]] for f in fams[:TABLE_MAX_ROWS]]
        return _table(["task definition"], rows, "ECS TASK DEFINITIONS")

    def _ecr_repo_list(self, cmd) -> list[Msg]:
        repos = self.c("ecr").describe_repositories().get("repositories", [])
        rows = [[r["repositoryName"], r.get("repositoryUri", "-")] for r in repos]
        return _table(["repository", "uri"], rows, "ECR REPOSITORIES")

    def _ecr_repo_create(self, cmd) -> list[Msg]:
        name = cmd.params.get("name") or (cmd.targets[0] if cmd.targets else None)
        if not name:
            return [err("Name it: create repo my-app")]
        self.c("ecr").create_repository(repositoryName=name)
        return [ok(f"Created ECR repository '{name}'.")]

    def _ecr_repo_delete(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which repo? e.g. delete repo my-app")]
        self.c("ecr").delete_repository(repositoryName=name, force=True)
        return [ok(f"Deleted ECR repository '{name}' (images force-deleted).")]

    def _eks_cluster_list(self, cmd) -> list[Msg]:
        clusters = self.c("eks").list_clusters().get("clusters", [])
        return _table(["eks cluster"], [[c] for c in clusters], "EKS CLUSTERS")

    def _eks_cluster_describe(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which cluster? e.g. describe cluster my-eks")]
        c = self.c("eks").describe_cluster(name=name)["cluster"]
        return [info(f"{c['name']}\n  status : {c['status']}\n  version: {c.get('version')}\n"
                     f"  endpoint: {c.get('endpoint', '-')}")]

    # ------------------------------------------------------------------ elb / route53 / cfn
    def _elb_lb_list(self, cmd) -> list[Msg]:
        lbs = self.c("elbv2").describe_load_balancers().get("LoadBalancers", [])
        rows = [[l["LoadBalancerName"], l.get("Type"), l.get("State", {}).get("Code"),
                 l.get("DNSName"), _age(l.get("CreatedTime"))] for l in lbs]
        return _table(["load balancer", "type", "state", "dns", "age"], rows, "LOAD BALANCERS")

    def _elb_tg_list(self, cmd) -> list[Msg]:
        tgs = self.c("elbv2").describe_target_groups().get("TargetGroups", [])
        rows = [[t["TargetGroupName"], t.get("Protocol"), t.get("Port"),
                 t.get("TargetType")] for t in tgs]
        return _table(["target group", "proto", "port", "type"], rows, "TARGET GROUPS")

    def _r53_zone_list(self, cmd) -> list[Msg]:
        zones = self.c("route53").list_hosted_zones().get("HostedZones", [])
        rows = [[z["Id"].split("/")[-1], z["Name"], z.get("Config", {}).get("PrivateZone", False)]
                for z in zones]
        return _table(["zone id", "name", "private"], rows, "ROUTE53 HOSTED ZONES")

    def _r53_record_list(self, cmd) -> list[Msg]:
        zone = (cmd.targets[0] if cmd.targets else None) or cmd.params.get("zone")
        if not zone:
            return [err("Which zone? e.g. list records in zone example.com (or Z123...)")]
        if not zone.startswith("Z"):
            zones = self.c("route53").list_hosted_zones().get("HostedZones", [])
            zone = next((z["Id"].split("/")[-1] for z in zones if z["Name"].rstrip(".") == zone
                         or z["Id"].split("/")[-1] == zone), None)
            if not zone:
                return [err("Zone not found. Try: list zones")]
        recs = self.c("route53").list_resource_record_sets(HostedZoneId=zone
                ).get("ResourceRecordSets", [])
        rows = [[r["Name"], r["Type"], r.get("TTL", "-"),
                 ",".join(v["Value"] for v in r.get("ResourceRecords", []))[:40]]
                for r in recs]
        return _table(["record", "type", "ttl", "value"], rows, f"RECORDS ({zone})")

    def _r53_record_create(self, cmd) -> list[Msg]:
        p = cmd.params
        name = p.get("name")
        if not name or not name.endswith("."):
            if not name:
                return [err("Name the record: create record api.example.com -> 1.2.3.4 in zone example.com")]
            name = name + "."
        value = next((c for c in p.get("cidrs", [])), None) or \
            next((t for t in p.get("extra", []) if IP_RE_like(t) or "." in t and t != name), None)
        zone = next((t for t in cmd.targets if t.startswith("Z")), None) or p.get("zone")
        rtype = "A" if value and re.match(r"^\d+\.\d+\.\d+\.\d+$", value) else "CNAME"
        if not zone:
            zones = self.c("route53").list_hosted_zones().get("HostedZones", [])
            match = next((z for z in zones if name.endswith(z["Name"]) or
                          name.rstrip(".") in z["Name"]), None)
            if not match:
                return [err("Couldn't guess the hosted zone. Add: in zone <zone-name>")]
            zone = match["Id"].split("/")[-1]
        change = {"Comment": "RCW-AWSNixOps", "Changes": [{"Action": "CREATE",
            "ResourceRecordSet": {"Name": name, "Type": rtype, "TTL": 300,
                                  "ResourceRecords": [{"Value": value}]}}]}
        self.c("route53").change_resource_record_sets(HostedZoneId=zone, ChangeBatch=change)
        return [ok(f"Created {rtype} record {name} -> {value} (zone {zone}).")]

    def _r53_record_delete(self, cmd) -> list[Msg]:
        p = cmd.params
        name = (p.get("name") or (cmd.targets[0] if cmd.targets else None))
        if not name:
            return [err("Which record? e.g. delete record api.example.com in zone example.com")]
        if not name.endswith("."):
            name += "."
        zone = next((t for t in cmd.targets if t.startswith("Z")), None) or p.get("zone")
        if not zone:
            zones = self.c("route53").list_hosted_zones().get("HostedZones", [])
            match = next((z for z in zones if name.endswith(z["Name"])), None)
            if not match:
                return [err("Couldn't guess zone; add: in zone <name>")]
            zone = match["Id"].split("/")[-1]
        recs = self.c("route53").list_resource_record_sets(HostedZoneId=zone
                ).get("ResourceRecordSets", [])
        rec = next((r for r in recs if r["Name"] == name and r["Type"] in ("A", "CNAME", "TXT")), None)
        if not rec:
            return [warn(f"Record {name} not found in {zone}.")]
        change = {"Comment": "RCW-AWSNixOps", "Changes": [{"Action": "DELETE",
            "ResourceRecordSet": rec}]}
        self.c("route53").change_resource_record_sets(HostedZoneId=zone, ChangeBatch=change)
        return [ok(f"Deleted record {name} ({rec['Type']}).")]

    def _cfn_stack_list(self, cmd) -> list[Msg]:
        stacks = self.c("cloudformation").list_stacks(
            StackStatusFilter=["CREATE_COMPLETE", "UPDATE_COMPLETE", "CREATE_IN_PROGRESS",
                               "UPDATE_IN_PROGRESS", "UPDATE_FAILED", "ROLLBACK_FAILED",
                               "ROLLBACK_COMPLETE", "DELETE_IN_PROGRESS"]
        ).get("StackSummaries", [])
        rows = [[s["Id"].split("/")[-2] if False else s["StackName"], s.get("StackStatus"),
                 str(s.get("CreationTime", ""))[:10]] for s in stacks[:TABLE_MAX_ROWS]]
        return _table(["stack", "status", "created"], rows, "CLOUDFORMATION STACKS")

    def _cfn_stack_create(self, cmd) -> list[Msg]:
        p = cmd.params
        name = p.get("name")
        tpl = p.get("template")
        if not name or not tpl:
            return [err("Usage: deploy stack my-stack from C:\\path\\template.yaml [with iam]")]
        tf = Path(tpl).expanduser()
        if not tf.is_file():
            return [err(f"Template not found: {tf}")]
        body = tf.read_text(encoding="utf-8")
        caps = ["CAPABILITY_NAMED_IAM"] if "iam" in cmd.raw.lower() else []
        cfn = self.c("cloudformation")
        exists = any(s["StackName"] == name and s["StackStatus"] != "DELETE_COMPLETE"
                     for s in cfn.list_stacks().get("StackSummaries", []))
        if exists:
            cfn.update_stack(StackName=name, TemplateBody=body, Capabilities=caps)
            return [ok(f"Updating stack '{name}'... watch it: stack events {name}")]
        cfn.create_stack(StackName=name, TemplateBody=body, Capabilities=caps,
                         OnFailure="DELETE")
        return [ok(f"Creating stack '{name}'... watch it: stack events {name}")]

    def _cfn_stack_describe(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which stack? e.g. describe stack my-stack")]
        s = self.c("cloudformation").describe_stacks(StackName=name)["Stacks"][0]
        outs = "\n".join(f"  {o['OutputKey']} = {o['OutputValue']}"
                         for o in s.get("Outputs", [])) or "  (none)"
        return [info(f"{s['StackName']}\n  status: {s.get('StackStatus')}\n"
                     f"  outputs:\n{outs}")]

    def _cfn_stack_delete(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which stack? e.g. delete stack my-stack")]
        self.c("cloudformation").delete_stack(StackName=name)
        return [ok(f"Deleting stack '{name}'...")]

    def _cfn_stack_tail(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which stack? e.g. stack events my-stack")]
        evs = self.c("cloudformation").describe_stack_events(StackName=name
                ).get("StackEvents", [])[:15]
        rows = [[str(e.get("Timestamp", ""))[11:19], e.get("ResourceStatus"),
                 e.get("LogicalResourceId"), (e.get("ResourceStatusReason") or "")[:30]]
                for e in evs]
        return _table(["time", "status", "resource", "reason"], rows, f"STACK EVENTS - {name}")

    # ------------------------------------------------------------------ messaging / misc
    def _sns_topic_list(self, cmd) -> list[Msg]:
        topics = self.c("sns").list_topics().get("Topics", [])
        rows = [[t["TopicArn"].split(":")[-1], t["TopicArn"]] for t in topics]
        return _table(["topic", "arn"], rows, "SNS TOPICS")

    def _sns_topic_create(self, cmd) -> list[Msg]:
        name = cmd.params.get("name") or (cmd.targets[0] if cmd.targets else None)
        if not name:
            return [err("Name it: create topic alerts")]
        arn = self.c("sns").create_topic(Name=name)["TopicArn"]
        return [ok(f"Created SNS topic '{name}'\n  {arn}")]

    def _sns_topic_delete(self, cmd) -> list[Msg]:
        t = cmd.targets[0] if cmd.targets else None
        if not t:
            return [err("Which topic? e.g. delete topic alerts")]
        if not t.startswith("arn:"):
            t = self.c("sns").create_topic(Name=t)["TopicArn"]  # idempotent lookup
        self.c("sns").delete_topic(TopicArn=t)
        return [ok(f"Deleted topic {t.split(':')[-1]}")]

    def _sns_topic_send(self, cmd) -> list[Msg]:
        p = cmd.params
        topic = p.get("topic") or (cmd.targets[0] if cmd.targets else None)
        message = p.get("message")
        if not topic or not message:
            return [err('Usage: publish message "hello team" to topic alerts')]
        if not topic.startswith("arn:"):
            topics = [t["TopicArn"] for t in self.c("sns").list_topics().get("Topics", [])
                      if t["TopicArn"].split(":")[-1] == topic]
            if not topics:
                return [err(f"Topic '{topic}' not found.")]
            topic = topics[0]
        self.c("sns").publish(TopicArn=topic, Message=message)
        return [ok(f"Published to {topic.split(':')[-1]}: \"{message}\"")]

    def _sqs_queue_list(self, cmd) -> list[Msg]:
        urls = self.c("sqs").list_queues().get("QueueUrls", [])
        rows = [[u.split("/")[-1], u] for u in urls]
        return _table(["queue", "url"], rows, "SQS QUEUES")

    def _sqs_queue_create(self, cmd) -> list[Msg]:
        name = cmd.params.get("name") or (cmd.targets[0] if cmd.targets else None)
        if not name:
            return [err("Name it: create queue jobs")]
        url = self.c("sqs").create_queue(QueueName=name)["QueueUrl"]
        return [ok(f"Created SQS queue '{name}'\n  {url}")]

    def _sqs_queue_delete(self, cmd) -> list[Msg]:
        t = cmd.targets[0] if cmd.targets else None
        if not t:
            return [err("Which queue? e.g. delete queue jobs")]
        url = self._queue_url(t)
        self.c("sqs").delete_queue(QueueUrl=url)
        return [ok(f"Deleted queue {t}")]

    def _queue_url(self, name_or_url: str) -> str:
        if name_or_url.startswith("http"):
            return name_or_url
        urls = self.c("sqs").list_queues().get("QueueUrls", [])
        for u in urls:
            if u.split("/")[-1] == name_or_url:
                return u
        raise ValueError(f"Queue '{name_or_url}' not found.")

    def _sqs_queue_send(self, cmd) -> list[Msg]:
        p = cmd.params
        q = p.get("queue") or (cmd.targets[0] if cmd.targets else None)
        message = p.get("message")
        if not q or not message:
            return [err('Usage: send message "job 42" to queue jobs')]
        self.c("sqs").send_message(QueueUrl=self._queue_url(q), MessageBody=message)
        return [ok(f"Sent to queue {q}: \"{message}\"")]

    def _kms_key_list(self, cmd) -> list[Msg]:
        keys = self.c("kms").list_keys().get("Keys", [])
        rows = [[k["KeyId"], k["KeyArn"]] for k in keys]
        return _table(["key id", "arn"], rows, "KMS KEYS")

    def _secrets_secret_list(self, cmd) -> list[Msg]:
        secrets = self.c("secretsmanager").list_secrets().get("SecretList", [])
        rows = [[s["Name"], str(s.get("LastChangedAt", ""))[:10]] for s in secrets]
        return _table(["secret", "changed"], rows, "SECRETS MANAGER")

    def _secrets_secret_create(self, cmd) -> list[Msg]:
        p = cmd.params
        name = p.get("name")
        value = p.get("value")
        if not name or not value:
            return [err("Usage: create secret my-api-key with value abcd1234")]
        self.c("secretsmanager").create_secret(Name=name, SecretString=value)
        return [ok(f"Created secret '{name}'.")]

    def _secrets_secret_describe(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which secret? e.g. describe secret my-api-key")]
        if not self.confirm(f"Reveal the value of secret '{name}'?"):
            return [warn("Cancelled.")]
        v = self.c("secretsmanager").get_secret_value(SecretId=name).get("SecretString", "")
        return [warn(f"{name} = {v[:200]}")]

    def _secrets_secret_delete(self, cmd) -> list[Msg]:
        name = cmd.targets[0] if cmd.targets else None
        if not name:
            return [err("Which secret? e.g. delete secret my-api-key")]
        self.c("secretsmanager").delete_secret(SecretId=name, ForceDeleteWithoutRecovery=True)
        return [ok(f"Deleted secret '{name}' (forced, no recovery window).")]

    def _cf_distribution_list(self, cmd) -> list[Msg]:
        dists = self.c("cloudfront").list_distributions().get("DistributionList", {})
        items = dists.get("Items", [])
        rows = [[d["Id"], d.get("DomainName", "-"), d.get("Status"),
                 d.get("DistributionConfig", {}).get("Comment", "-")[:30]] for d in items]
        return _table(["distribution", "domain", "status", "comment"], rows, "CLOUDFRONT")

    def _asg_asg_list(self, cmd) -> list[Msg]:
        asgs = self.c("autoscaling").describe_auto_scaling_groups().get("AutoScalingGroups", [])
        rows = [[a["AutoScalingGroupName"], len(a.get("Instances", [])),
                 a.get("MinSize"), a.get("MaxSize"), a.get("DesiredCapacity")]
                for a in asgs]
        return _table(["auto scaling group", "instances", "min", "max", "desired"], rows,
                      "AUTO SCALING GROUPS")

    def _cache_cache_list(self, cmd) -> list[Msg]:
        c = self.c("elasticache").describe_cache_clusters(ShowCacheNodeInfo=True
                ).get("CacheClusters", [])
        rows = [[x["CacheClusterId"], x.get("Engine", "-"), x.get("CacheNodeType", "-"),
                 x.get("CacheClusterStatus"), (x.get("ConfigurationEndpoint") or {}).get("Address", "-")]
                for x in c]
        return _table(["cluster", "engine", "node", "status", "endpoint"], rows, "ELASTICACHE")

    def _apigw_api_list(self, cmd) -> list[Msg]:
        apis = self.c("apigateway").get_rest_apis().get("items", [])
        rows = [[a["id"], a.get("name"), a.get("createdDate", "-")] for a in apis]
        return _table(["api id", "name", "created"], rows, "API GATEWAY (REST) APIS")


def IP_RE_like(s: str) -> bool:
    return bool(re.match(r"^\d{1,3}(\.\d{1,3}){3}$", s or ""))


def PATH_hint(s: str) -> bool:
    s = s or ""
    return bool(re.match(r"^([A-Za-z]:[\\/]|[.~][/\\]|\\\\|\\S+\\)", s)
                or re.search(r"\.(zip|yaml|yml|json|txt|pem|csv|pdf|png|jpg|log|py|js|ts|sql|exe|msi|tar|gz|ini|cfg|env|xml|html|doc|docx|xls|xlsx|ppt|pptx|mp4|mov|wav)$", s, re.I))


Executor.ACTIONS = {
    ("ec2", "instance", "create"): Executor._ec2_instance_create,
    ("ec2", "instance", "list"): Executor._ec2_instance_list,
    ("ec2", "instance", "describe"): Executor._ec2_instance_describe,
    ("ec2", "instance", "start"): Executor._ec2_instance_start,
    ("ec2", "instance", "stop"): Executor._ec2_instance_stop,
    ("ec2", "instance", "reboot"): Executor._ec2_instance_reboot,
    ("ec2", "instance", "terminate"): Executor._ec2_instance_terminate,
    ("ec2", "vpc", "list"): Executor._ec2_vpc_list,
    ("ec2", "vpc", "create"): Executor._ec2_vpc_create,
    ("ec2", "vpc", "delete"): Executor._ec2_vpc_delete,
    ("ec2", "subnet", "list"): Executor._ec2_subnet_list,
    ("ec2", "subnet", "create"): Executor._ec2_subnet_create,
    ("ec2", "sg", "list"): Executor._ec2_sg_list,
    ("ec2", "sg", "create"): Executor._ec2_sg_create,
    ("ec2", "sg", "delete"): Executor._ec2_sg_delete,
    ("ec2", "sg", "open"): Executor._ec2_sg_open,
    ("ec2", "sg", "close"): Executor._ec2_sg_close,
    ("ec2", "keypair", "create"): Executor._ec2_keypair_create,
    ("ec2", "keypair", "list"): Executor._ec2_keypair_list,
    ("ec2", "keypair", "delete"): Executor._ec2_keypair_delete,
    ("ec2", "volume", "list"): Executor._ec2_volume_list,
    ("ec2", "volume", "create"): Executor._ec2_volume_create,
    ("ec2", "volume", "delete"): Executor._ec2_volume_delete,
    ("ec2", "volume", "attach"): Executor._ec2_volume_attach,
    ("ec2", "snapshot", "list"): Executor._ec2_snapshot_list,
    ("ec2", "snapshot", "create"): Executor._ec2_snapshot_create,
    ("ec2", "snapshot", "delete"): Executor._ec2_snapshot_delete,
    ("ec2", "eip", "list"): Executor._ec2_eip_list,
    ("ec2", "eip", "create"): Executor._ec2_eip_create,
    ("ec2", "eip", "delete"): Executor._ec2_eip_delete,
    ("ec2", "eip", "associate"): Executor._ec2_eip_associate,
    ("ec2", "image", "list"): Executor._ec2_image_list,
    ("ec2", "image", "describe"): Executor._ec2_image_describe,
    ("s3", "bucket", "create"): Executor._s3_bucket_create,
    ("s3", "bucket", "list"): Executor._s3_bucket_list,
    ("s3", "bucket", "describe"): Executor._s3_bucket_describe,
    ("s3", "bucket", "empty"): Executor._s3_bucket_empty,
    ("s3", "bucket", "delete"): Executor._s3_bucket_delete,
    ("s3", "object", "list"): Executor._s3_object_list,
    ("s3", "object", "upload"): Executor._s3_object_upload,
    ("s3", "object", "download"): Executor._s3_object_download,
    ("s3", "object", "delete"): Executor._s3_object_delete,
    ("lambda", "function", "list"): Executor._lambda_function_list,
    ("lambda", "function", "describe"): Executor._lambda_function_describe,
    ("lambda", "function", "invoke"): Executor._lambda_function_invoke,
    ("lambda", "function", "delete"): Executor._lambda_function_delete,
    ("lambda", "function", "create"): Executor._lambda_function_create,
    ("rds", "db", "list"): Executor._rds_db_list,
    ("rds", "db", "describe"): Executor._rds_db_describe,
    ("rds", "db", "create"): Executor._rds_db_create,
    ("rds", "db", "delete"): Executor._rds_db_delete,
    ("rds", "db", "stop"): Executor._rds_db_stop,
    ("rds", "db", "start"): Executor._rds_db_start,
    ("dynamodb", "table", "list"): Executor._dynamodb_table_list,
    ("dynamodb", "table", "create"): Executor._dynamodb_table_create,
    ("dynamodb", "table", "describe"): Executor._dynamodb_table_describe,
    ("dynamodb", "table", "delete"): Executor._dynamodb_table_delete,
    ("dynamodb", "item", "list"): Executor._dynamodb_item_list,
    ("dynamodb", "item", "upload"): Executor._dynamodb_item_upload,
    ("iam", "user", "list"): Executor._iam_user_list,
    ("iam", "user", "create"): Executor._iam_user_create,
    ("iam", "user", "delete"): Executor._iam_user_delete,
    ("iam", "role", "list"): Executor._iam_role_list,
    ("iam", "policy", "list"): Executor._iam_policy_list,
    ("iam", "policy", "attach"): Executor._iam_policy_attach,
    ("iam", "policy", "detach"): Executor._iam_policy_detach,
    ("iam", "accesskey", "create"): Executor._iam_accesskey_create,
    ("cw", "alarm", "list"): Executor._cw_alarm_list,
    ("cw", "alarm", "describe"): Executor._cw_alarm_describe,
    ("cw", "alarm", "create"): Executor._cw_alarm_create,
    ("cw", "alarm", "delete"): Executor._cw_alarm_delete,
    ("logs", "loggroup", "list"): Executor._logs_loggroup_list,
    ("logs", "loggroup", "tail"): Executor._logs_tail,
    ("ecs", "cluster", "list"): Executor._ecs_cluster_list,
    ("ecs", "service", "list"): Executor._ecs_service_list,
    ("ecs", "taskdef", "list"): Executor._ecs_taskdef_list,
    ("ecr", "repo", "list"): Executor._ecr_repo_list,
    ("ecr", "repo", "create"): Executor._ecr_repo_create,
    ("ecr", "repo", "delete"): Executor._ecr_repo_delete,
    ("eks", "cluster", "list"): Executor._eks_cluster_list,
    ("eks", "cluster", "describe"): Executor._eks_cluster_describe,
    ("elb", "lb", "list"): Executor._elb_lb_list,
    ("elb", "tg", "list"): Executor._elb_tg_list,
    ("r53", "zone", "list"): Executor._r53_zone_list,
    ("r53", "record", "list"): Executor._r53_record_list,
    ("r53", "record", "create"): Executor._r53_record_create,
    ("r53", "record", "delete"): Executor._r53_record_delete,
    ("cfn", "stack", "list"): Executor._cfn_stack_list,
    ("cfn", "stack", "create"): Executor._cfn_stack_create,
    ("cfn", "stack", "describe"): Executor._cfn_stack_describe,
    ("cfn", "stack", "delete"): Executor._cfn_stack_delete,
    ("cfn", "stack", "tail"): Executor._cfn_stack_tail,
    ("sns", "topic", "list"): Executor._sns_topic_list,
    ("sns", "topic", "create"): Executor._sns_topic_create,
    ("sns", "topic", "delete"): Executor._sns_topic_delete,
    ("sns", "topic", "send"): Executor._sns_topic_send,
    ("sqs", "queue", "list"): Executor._sqs_queue_list,
    ("sqs", "queue", "create"): Executor._sqs_queue_create,
    ("sqs", "queue", "delete"): Executor._sqs_queue_delete,
    ("sqs", "queue", "send"): Executor._sqs_queue_send,
    ("kms", "key", "list"): Executor._kms_key_list,
    ("secrets", "secret", "list"): Executor._secrets_secret_list,
    ("secrets", "secret", "create"): Executor._secrets_secret_create,
    ("secrets", "secret", "describe"): Executor._secrets_secret_describe,
    ("secrets", "secret", "delete"): Executor._secrets_secret_delete,
    ("cf", "distribution", "list"): Executor._cf_distribution_list,
    ("asg", "asg", "list"): Executor._asg_asg_list,
    ("cache", "cache", "list"): Executor._cache_cache_list,
    ("apigw", "api", "list"): Executor._apigw_api_list,
}
