"""Demo mode: a fake AWS account so the GUI can be explored with zero setup
and zero risk. DemoManager mimics the AwsManager interface used by Executor."""
from __future__ import annotations

from datetime import datetime, timedelta


class DemoError(Exception):
    pass


def _now_minus(**kw):
    return (datetime.utcnow() - timedelta(**kw)).isoformat() + "Z"


CANNED: dict[tuple[str, str], dict] = {
    ("sts", "get_caller_identity"): {
        "Account": "123456789012",
        "Arn": "arn:aws:iam::123456789012:user/rcw-demo-admin",
    },
    ("ec2", "describe_instances"): {"Reservations": [{"Instances": [
        {"InstanceId": "i-0demo111111aaaaa1",
         "InstanceType": "t3.medium",
         "State": {"Name": "running"},
         "PublicIpAddress": "3.109.204.11",
         "Placement": {"AvailabilityZone": "ap-south-1a"},
         "LaunchTime": _now_minus(days=3),
         "ImageId": "ami-0demoal2023",
         "PrivateIpAddress": "172.31.12.5",
         "Tags": [{"Key": "Name", "Value": "web-1"},
                  {"Key": "ManagedBy", "Value": "RCW-AWSNixOps"}],
         "SecurityGroups": [{"GroupName": "rcw-awsnixops-default"}]},
        {"InstanceId": "i-0demo222222bbbb2",
         "InstanceType": "t3.medium",
         "State": {"Name": "stopped"},
         "Placement": {"AvailabilityZone": "ap-south-1a"},
         "LaunchTime": _now_minus(days=10),
         "Tags": [{"Key": "Name", "Value": "web-2"}],
         "SecurityGroups": [{"GroupName": "rcw-awsnixops-default"}]},
        {"InstanceId": "i-0demo333333cccc3",
         "InstanceType": "m5.large",
         "State": {"Name": "running"},
         "PublicIpAddress": "65.2.91.40",
         "Placement": {"AvailabilityZone": "ap-south-1b"},
         "LaunchTime": _now_minus(hours=9),
         "Tags": [{"Key": "Name", "Value": "db-1"}],
         "SecurityGroups": [{"GroupName": "default"}]},
    ]}]},
    ("ec2", "run_instances"): {"Instances": [{"InstanceId": "i-0demo444444dddd4"}]},
    ("ec2", "stop_instances"): {"StoppingInstances": [{"InstanceId": "i-0demo111111aaaaa1"}]},
    ("ec2", "start_instances"): {"StartingInstances": [{"InstanceId": "i-0demo222222bbbb2"}]},
    ("ec2", "reboot_instances"): {},
    ("ec2", "terminate_instances"): {"TerminatingInstances": [{"InstanceId": "i-0demo111111aaaaa1"}]},
    ("ec2", "describe_vpcs"): {"Vpcs": [
        {"VpcId": "vpc-0demo900111aaaaa", "CidrBlock": "172.31.0.0/16", "IsDefault": True,
         "Tags": [{"Key": "Name", "Value": "-"}]},
        {"VpcId": "vpc-0demo900222bbbb", "CidrBlock": "10.20.0.0/16", "IsDefault": False,
         "CreateTime": _now_minus(days=40),
         "Tags": [{"Key": "Name", "Value": "prod"}]}]},
    ("ec2", "describe_subnets"): {"Subnets": [
        {"SubnetId": "subnet-0demo0111", "VpcId": "vpc-0demo900111aaaaa",
         "CidrBlock": "172.31.16.0/20", "AvailabilityZone": "ap-south-1a",
         "MapPublicIpOnLaunch": True, "Tags": [{"Key": "Name", "Value": "public-a"}]},
        {"SubnetId": "subnet-0demo0222", "VpcId": "vpc-0demo900111aaaaa",
         "CidrBlock": "172.31.32.0/20", "AvailabilityZone": "ap-south-1b",
         "MapPublicIpOnLaunch": False, "Tags": [{"Key": "Name", "Value": "private-b"}]}]},
    ("ec2", "describe_security_groups"): {"SecurityGroups": [
        {"GroupId": "sg-0demo1111", "GroupName": "default", "VpcId": "vpc-0demo900111aaaaa",
         "IpPermissions": []},
        {"GroupId": "sg-0demo2222", "GroupName": "rcw-awsnixops-default",
         "VpcId": "vpc-0demo900111aaaaa",
         "IpPermissions": [{"IpProtocol": "tcp", "FromPort": 22, "ToPort": 22,
                            "IpRanges": [{"CidrIp": "0.0.0.0/0"}]},
                           {"IpProtocol": "tcp", "FromPort": 80, "ToPort": 80,
                            "IpRanges": [{"CidrIp": "0.0.0.0/0"}]}]}]},
    ("ec2", "describe_key_pairs"): {"KeyPairs": [{"KeyName": "rcw-awsnixops",
                                                  "KeyFingerprint": "1a:2b:3c:4d:5e:6f"}]},
    ("ec2", "describe_volumes"): {"Volumes": [
        {"VolumeId": "vol-0demo1111", "Size": 30, "VolumeType": "gp3", "State": "in-use",
         "AvailabilityZone": "ap-south-1a",
         "Attachments": [{"InstanceId": "i-0demo111111aaaaa1"}], "CreateTime": _now_minus(days=3)},
        {"VolumeId": "vol-0demo2222", "Size": 100, "VolumeType": "gp2", "State": "available",
         "AvailabilityZone": "ap-south-1a", "CreateTime": _now_minus(days=60)}]},
    ("ec2", "describe_snapshots"): {"Snapshots": [
        {"SnapshotId": "snap-0demo1111", "VolumeId": "vol-0demo1111", "State": "completed",
         "StartTime": _now_minus(days=1), "Description": "RCW-AWSNixOps snapshot"}]},
    ("ec2", "describe_addresses"): {"Addresses": [
        {"PublicIp": "3.109.204.99", "AllocationId": "eipalloc-0demo1111",
         "InstanceId": "i-0demo111111aaaaa1", "Domain": "vpc"}]},
    ("ec2", "describe_images"): {"Images": [
        {"ImageId": "ami-0mygolden", "Name": "web-golden-2026-08", "State": "available",
         "CreationDate": "2026-08-20T10:00:00.000Z", "OwnerId": "123456789012"}]},
    ("ec2", "create_key_pair"): {"KeyName": "rcw-demo-key", "KeyMaterial": "-----DEMO KEY-----"},
    ("ec2", "create_security_group"): {"GroupId": "sg-0demonew"},
    ("ec2", "create_vpc"): {"Vpc": {"VpcId": "vpc-0demonew"}},
    ("ec2", "create_subnet"): {"Subnet": {"SubnetId": "subnet-0demonew"}},
    ("ec2", "create_volume"): {"VolumeId": "vol-0demonew"},
    ("ec2", "create_snapshot"): {"SnapshotId": "snap-0demonew"},
    ("ec2", "allocate_address"): {"PublicIp": "3.7.190.21", "AllocationId": "eipalloc-0demonew"},
    ("ec2", "authorize_security_group_ingress"): {},
    ("ec2", "revoke_security_group_ingress"): {},
    ("ec2", "create_tags"): {},
    ("ec2", "delete_vpc"): {}, ("ec2", "delete_security_group"): {},
    ("ec2", "delete_key_pair"): {}, ("ec2", "delete_volume"): {},
    ("ec2", "delete_snapshot"): {}, ("ec2", "release_address"): {},
    ("ec2", "attach_volume"): {}, ("ec2", "associate_address"): {},
    ("ssm", "get_parameter"): {"Parameter": {"Value": "ami-0demoal2023"}},
    ("s3", "list_buckets"): {"Buckets": [
        {"Name": "rcw-demo-assets", "CreationDate": _now_minus(days=30)},
        {"Name": "rcw-demo-logs", "CreationDate": _now_minus(days=12)}]},
    ("s3", "create_bucket"): {},
    ("s3", "delete_bucket"): {},
    ("s3", "put_public_access_block"): {},
    ("s3", "get_bucket_location"): {"LocationConstraint": "ap-south-1"},
    ("s3", "list_objects_v2"): {"KeyCount": 3, "Contents": [
        {"Key": "reports/2026-08.csv", "Size": 4231, "LastModified": _now_minus(days=1)},
        {"Key": "logo.png", "Size": 84213, "LastModified": _now_minus(days=5)},
        {"Key": "backup/db-dump.sql.gz", "Size": 52_400_000,
         "LastModified": _now_minus(hours=20)}]},
    ("s3", "upload_file"): None, ("s3", "download_file"): None, ("s3", "delete_object"): {},
    ("s3", "delete_objects"): {},
    ("lambda", "list_functions"): {"Functions": [
        {"FunctionName": "demo-thumbnailer", "Runtime": "python3.12",
         "Handler": "lambda_function.lambda_handler", "Timeout": 30,
         "LastModified": _now_minus(days=6)},
        {"FunctionName": "demo-webhook", "Runtime": "nodejs20.x",
         "Handler": "index.handler", "Timeout": 10,
         "LastModified": _now_minus(days=19)}]},
    ("lambda", "get_function"): {"Configuration": {
        "FunctionName": "demo-thumbnailer", "Runtime": "python3.12",
        "Handler": "lambda_function.lambda_handler", "MemorySize": 512, "Timeout": 30,
        "LastModified": _now_minus(days=6), "CodeSize": 245_760,
        "Role": "arn:aws:iam::123456789012:role/lambda-execute"}},
    ("lambda", "invoke"): None,  # handled specially
    ("lambda", "delete_function"): {}, ("lambda", "create_function"): {},
    ("rds", "describe_db_instances"): {"DBInstances": [
        {"DBInstanceIdentifier": "demo-mysql", "Engine": "mysql", "DBInstanceClass": "db.t3.micro",
         "DBInstanceStatus": "available", "StorageAllocated": 20,
         "Endpoint": {"Address": "demo-mysql.abc.ap-south-1.rds.amazonaws.com", "Port": 3306}}]},
    ("rds", "create_db_instance"): {}, ("rds", "delete_db_instance"): {},
    ("rds", "stop_db_instance"): {}, ("rds", "start_db_instance"): {},
    ("dynamodb", "list_tables"): {"TableNames": ["orders", "users"]},
    ("dynamodb", "describe_table"): {"Table": {
        "TableName": "orders", "TableStatus": "ACTIVE", "ItemCount": 1284,
        "TableSizeBytes": 246_000,
        "KeySchema": [{"AttributeName": "order_id", "KeyType": "HASH"}]}},
    ("dynamodb", "scan"): {"Items": [
        {"order_id": {"S": "1001"}, "total": {"N": "49.99"}},
        {"order_id": {"S": "1002"}, "total": {"N": "12.50"}}]},
    ("dynamodb", "create_table"): {}, ("dynamodb", "delete_table"): {},
    ("dynamodb", "put_item"): {},
    ("iam", "list_users"): {"Users": [
        {"UserName": "rcw-demo-admin", "CreateDate": _now_minus(days=90)},
        {"UserName": "deploy-bot", "CreateDate": _now_minus(days=14)}]},
    ("iam", "create_user"): {}, ("iam", "delete_user"): {},
    ("iam", "list_access_keys"): {"AccessKeyMetadata": []},
    ("iam", "delete_access_key"): {},
    ("iam", "list_roles"): {"Roles": [
        {"RoleName": "lambda-execute", "CreateDate": _now_minus(days=30)},
        {"RoleName": "ecs-task-role", "CreateDate": _now_minus(days=21)}]},
    ("iam", "list_policies"): {"Policies": [
        {"PolicyName": "demo-s3-write", "Arn": "arn:aws:iam::123456789012:policy/demo-s3-write",
         "CreateDate": _now_minus(days=25)}]},
    ("iam", "attach_user_policy"): {}, ("iam", "detach_user_policy"): {},
    ("iam", "attach_role_policy"): {}, ("iam", "detach_role_policy"): {},
    ("iam", "create_access_key"): {"AccessKey": {
        "AccessKeyId": "AKIADEMODOOREDGE", "SecretAccessKey": "demo-secret-not-real"}},
    ("iam", "get_role"): None,  # handled specially
    ("iam", "create_role"): None,
    ("cloudwatch", "describe_alarms"): {"MetricAlarms": [
        {"AlarmName": "web-1-high-cpu", "StateValue": "OK", "MetricName": "CPUUtilization",
         "ComparisonOperator": "GreaterThanThreshold", "Threshold": 80.0,
         "Dimensions": [{"Name": "InstanceId", "Value": "i-0demo111111aaaaa1"}]}]},
    ("cloudwatch", "put_metric_alarm"): {}, ("cloudwatch", "delete_alarms"): {},
    ("logs", "describe_log_groups"): {"logGroups": [
        {"logGroupName": "/aws/lambda/demo-thumbnailer", "storedBytes": 1_500_000},
        {"logGroupName": "/aws/lambda/demo-webhook", "storedBytes": 300_000}]},
    ("logs", "describe_log_streams"): {"logStreams": [
        {"logStreamName": "2026/08/26/[$LATEST]abc123"}]},
    ("logs", "get_log_events"): {"events": [
        {"timestamp": "2026-08-26 09:00:01", "message": "START RequestId: demo-1"},
        {"timestamp": "2026-08-26 09:00:01", "message": "processing s3://rcw-demo-assets/photo.jpg"},
        {"timestamp": "2026-08-26 09:00:02", "message": "END RequestId: demo-1"}]},
    ("ecs", "list_clusters"): {"clusterArns": [
        "arn:aws:ecs:ap-south-1:123456789012:cluster/demo-app"]},
    ("ecs", "list_services"): {"serviceArns": [
        "arn:aws:ecs:ap-south-1:123456789012:service/demo-app/api"]},
    ("ecs", "list_task_definitions"): {"taskDefinitionArns": [
        "arn:aws:ecs:ap-south-1:123456789012:task-definition/demo-api:7"]},
    ("ecr", "describe_repositories"): {"repositories": [
        {"repositoryName": "demo-api", "repositoryUri": "123456789012.dkr.ecr.ap-south-1.amazonaws.com/demo-api"}]},
    ("ecr", "create_repository"): {}, ("ecr", "delete_repository"): {},
    ("eks", "list_clusters"): {"clusters": ["demo-eks"]},
    ("eks", "describe_cluster"): {"cluster": {"name": "demo-eks", "status": "ACTIVE",
                                              "version": "1.30", "endpoint": "https://EKS.demo"}},
    ("elbv2", "describe_load_balancers"): {"LoadBalancers": [
        {"LoadBalancerName": "demo-alb", "Type": "application", "State": {"Code": "active"},
         "DNSName": "demo-alb-123.ap-south-1.elb.amazonaws.com",
         "CreatedTime": _now_minus(days=45)}]},
    ("elbv2", "describe_target_groups"): {"TargetGroups": [
        {"TargetGroupName": "demo-tg-80", "Protocol": "HTTP", "Port": 80, "TargetType": "instance"}]},
    ("route53", "list_hosted_zones"): {"HostedZones": [
        {"Id": "/hostedzone/ZDEMOZONE111", "Name": "example-demo.com.",
         "Config": {"PrivateZone": False}}]},
    ("route53", "list_resource_record_sets"): {"ResourceRecordSets": [
        {"Name": "example-demo.com.", "Type": "NS", "TTL": 172800, "ResourceRecords": [{"Value": "ns-1.awsdns.com"}]},
        {"Name": "www.example-demo.com.", "Type": "A", "TTL": 300, "ResourceRecords": [{"Value": "3.109.204.11"}]}]},
    ("route53", "change_resource_record_sets"): {"ChangeInfo": {"Status": "PENDING"}},
    ("cloudformation", "list_stacks"): {"StackSummaries": [
        {"StackName": "demo-vpc", "StackStatus": "CREATE_COMPLETE",
         "CreationTime": _now_minus(days=50)}]},
    ("cloudformation", "create_stack"): {}, ("cloudformation", "update_stack"): {},
    ("cloudformation", "delete_stack"): {},
    ("cloudformation", "describe_stacks"): {"Stacks": [
        {"StackName": "demo-vpc", "StackStatus": "CREATE_COMPLETE",
         "Outputs": [{"OutputKey": "VpcId", "OutputValue": "vpc-0demo900222bbbb"}]}]},
    ("cloudformation", "describe_stack_events"): {"StackEvents": [
        {"Timestamp": "2026-08-20T10:03:00Z", "ResourceStatus": "CREATE_COMPLETE",
         "LogicalResourceId": "VPC"}]},
    ("sns", "list_topics"): {"Topics": [
        {"TopicArn": "arn:aws:sns:ap-south-1:123456789012:deploy-alerts"}]},
    ("sns", "create_topic"): {"TopicArn": "arn:aws:sns:ap-south-1:123456789012:demo-topic"},
    ("sns", "delete_topic"): {}, ("sns", "publish"): {},
    ("sqs", "list_queues"): {"QueueUrls": [
        "https://sqs.ap-south-1.amazonaws.com/123456789012/demo-jobs"]},
    ("sqs", "create_queue"): {"QueueUrl": "https://sqs.ap-south-1.amazonaws.com/123456789012/demo-new"},
    ("sqs", "delete_queue"): {}, ("sqs", "send_message"): {},
    ("kms", "list_keys"): {"Keys": [{"KeyId": "demo-key-1",
                                     "KeyArn": "arn:aws:kms:ap-south-1:123456789012:key/demo-key-1"}]},
    ("secretsmanager", "list_secrets"): {"SecretList": [
        {"Name": "demo/db-password", "LastChangedAt": _now_minus(days=8)}]},
    ("secretsmanager", "create_secret"): {},
    ("secretsmanager", "get_secret_value"): {"SecretString": "demo-password-123"},
    ("secretsmanager", "delete_secret"): {},
    ("cloudfront", "list_distributions"): {"DistributionList": {"Items": [
        {"Id": "ED1MODIST", "DomainName": "d111demo.cloudfront.net", "Status": "Deployed",
         "DistributionConfig": {"Comment": "demo site"}}]}},
    ("autoscaling", "describe_auto_scaling_groups"): {"AutoScalingGroups": [
        {"AutoScalingGroupName": "demo-asg", "Instances": [{"InstanceId": "i-0demo111111aaaaa1"}],
         "MinSize": 1, "MaxSize": 4, "DesiredCapacity": 2}]},
    ("elasticache", "describe_cache_clusters"): {"CacheClusters": [
        {"CacheClusterId": "demo-redis", "Engine": "redis", "CacheNodeType": "cache.t3.micro",
         "CacheClusterStatus": "available",
         "ConfigurationEndpoint": {"Address": "demo-redis.abc.ngn.0001.aps1.cache.amazonaws.com"}}]},
    ("apigateway", "get_rest_apis"): {"items": [
        {"id": "demo1api2", "name": "demo-orders-api", "createdDate": "2026-08-01"}]},
}

DEMO_MUTATION_OK = {"create", "delete", "stop", "start", "reboot", "terminate", "empty",
                    "open", "close", "tag", "upload", "download", "send", "attach",
                    "detach", "associate", "put", "invoke", "deploy", "update"}


class DemoClient:
    def __init__(self, service: str) -> None:
        self._service = service

    def __getattr__(self, op: str):
        def call(**kwargs):
            key = (self._service, op)
            if key == ("lambda", "invoke"):
                class _P:
                    def read(self):
                        return b'{"statusCode": 200, "body": "{\\"demo\\": true}"}'
                return {"StatusCode": 200, "Payload": _P()}
            if key in CANNED:
                v = CANNED[key]
                if v is None:
                    return {}
                return v
            if op.startswith(("create_", "delete_", "run_", "stop_", "start_", "put_",
                              "delete", "authorize", "revoke", "attach", "detach",
                              "associate", "release", "empty", "send", "publish",
                              "reboot", "terminate", "allocate", "upload", "download")):
                return {}
            raise DemoError(
                f"'{self._service}.{op}' is not available in DEMO mode.\n"
                "Demo mode includes: EC2, S3, Lambda, RDS, DynamoDB, IAM, CloudWatch,\n"
                "ECS/ECR/EKS, ELB, Route53, CloudFormation, SNS, SQS, KMS, Secrets,\n"
                "CloudFront, ASG, ElastiCache, API Gateway and the cost report.\n"
                "Disconnect and connect with real credentials for full access.")
        return call


class DemoManager:
    def __init__(self) -> None:
        self.profile = "demo"
        self.region = "ap-south-1"
        self.identity = {"account": "123456789012",
                         "arn": "arn:aws:iam::123456789012:user/rcw-demo-admin",
                         "user": "rcw-demo-admin"}
        self.demo = True
        self._clients: dict = {}

    @property
    def connected(self) -> bool:
        return True

    def disconnect(self) -> None:
        pass

    def set_region(self, region: str) -> None:
        self.region = region

    def connect(self, profile=None, region=None, keys=None) -> dict:
        self.identity = {"account": "123456789012",
                         "arn": "arn:aws:iam::123456789012:user/rcw-demo-admin",
                         "user": "rcw-demo-admin"}
        return self.identity

    def client(self, service: str):
        if service not in self._clients:
            self._clients[service] = DemoClient(service)
        return self._clients[service]


def demo_cost() -> list:
    from .core import ok as _ok, mono as _mono
    rows = [
        ("EC2 - Instance hours", 41.87),
        ("RDS hours", 12.04),
        ("S3 storage+requests", 3.41),
        ("CloudWatch", 1.92),
        ("NAT Gateway", 9.55),
        ("Lambda", 0.18),
        ("Route 53", 0.62),
    ]
    total = sum(v for _, v in rows)
    lines = ["COST 2026-08-19 .. 2026-08-26 (DEMO DATA)", "",
             "SERVICE                      COST   SHARE",
             "----------------------------------------"]
    for name, v in rows:
        lines.append(f"{name:<28} ${v:>6.2f}   {v / total * 100:>3.0f}%")
    lines.append("----------------------------------------")
    return [_mono("\n".join(lines)), _ok(f"TOTAL: ${total:,.2f}")]
