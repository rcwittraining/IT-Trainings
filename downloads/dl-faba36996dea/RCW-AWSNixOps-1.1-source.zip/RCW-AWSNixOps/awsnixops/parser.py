"""RCW - AWSNixOps rule-based natural language parser.

Turns plain-English prompts like:

    create ec2 instance web1 t3.medium with ports 22 and 80 in mumbai
    stop all running instances
    empty bucket my-data then delete bucket my-data
    cost last 7 days

into structured ParsedCommand objects the executor can run with boto3.
No API keys, no cloud calls - fully offline rule engine.
"""
from __future__ import annotations

import re
import shlex
from dataclasses import dataclass, field

from .core import region_code_for

# --------------------------------------------------------------------------- vocabulary

VERBS: dict[str, str] = {
    # create
    "create": "create", "make": "create", "new": "create", "add": "create",
    "provision": "create", "spin": "create", "launch": "create", "setup": "create",
    "deploy": "create", "allocate": "create", "generate": "create",
    # read
    "list": "list", "ls": "list", "show": "list", "view": "list",
    "display": "list", "enumerate": "list", "find": "list",
    "describe": "describe", "info": "describe", "details": "describe",
    "status": "describe", "inspect": "describe",
    # lifecycle
    "start": "start", "boot": "start", "poweron": "start", "resume": "start",
    "stop": "stop", "shutdown": "stop", "halt": "stop", "poweroff": "stop",
    "reboot": "reboot", "restart": "reboot",
    # delete
    "delete": "delete", "remove": "delete", "rm": "delete", "del": "delete",
    "drop": "delete", "destroy": "delete", "kill": "delete", "decommission": "delete",
    "release": "delete", "retire": "delete", "terminate": "terminate",
    # security groups
    "open": "open", "allow": "open", "enable": "open", "expose": "open",
    "close": "close", "block": "close", "deny": "close", "revoke": "close",
    # misc verbs
    "empty": "empty", "clear": "empty", "purge": "empty", "wipe": "empty",
    "tag": "tag", "label": "tag", "untag": "untag",
    "upload": "upload", "put": "upload", "push": "upload",
    "download": "download", "fetch": "download", "save": "download", "get": "download",
    "invoke": "invoke", "call": "invoke", "execute": "invoke", "run": "invoke",
    "test": "invoke",
    "send": "send", "publish": "send", "notify": "send", "emit": "send",
    "logs": "tail", "log": "tail", "tail": "tail",
    "attach": "attach", "connect": "attach", "detach": "detach", "disconnect": "detach",
    "associate": "associate", "assign": "associate", "bind": "associate",
    "scale": "scale", "update": "update", "modify": "update", "set": "update",
}

# noun phrase -> (service, resource). Longer phrases must be matched first.
RESOURCE_PHRASES: list[tuple[tuple[str, ...], str, str]] = [
    (("ec2", "instances"), "ec2", "instance"), (("ec2", "instance"), "ec2", "instance"),
    (("ec2", "vms"), "ec2", "instance"), (("ec2", "vm"), "ec2", "instance"),
    (("instances",), "ec2", "instance"), (("instance",), "ec2", "instance"),
    (("vms",), "ec2", "instance"), (("vm",), "ec2", "instance"),
    (("servers",), "ec2", "instance"), (("server",), "ec2", "instance"),
    (("machines",), "ec2", "instance"), (("machine",), "ec2", "instance"),
    (("boxes",), "ec2", "instance"), (("box",), "ec2", "instance"),
    (("s3", "buckets"), "s3", "bucket"), (("s3", "bucket"), "s3", "bucket"),
    (("buckets",), "s3", "bucket"), (("bucket",), "s3", "bucket"),
    (("objects",), "s3", "object"), (("object",), "s3", "object"),
    (("files",), "s3", "object"), (("file",), "s3", "object"),
    (("vpcs",), "ec2", "vpc"), (("vpc",), "ec2", "vpc"),
    (("networks",), "ec2", "vpc"), (("network",), "ec2", "vpc"),
    (("subnets",), "ec2", "subnet"), (("subnet",), "ec2", "subnet"),
    (("security", "groups"), "ec2", "sg"), (("security", "group"), "ec2", "sg"),
    (("firewall", "rules"), "ec2", "sg"), (("sgs",), "ec2", "sg"), (("sg",), "ec2", "sg"),
    (("key", "pairs"), "ec2", "keypair"), (("key", "pair"), "ec2", "keypair"),
    (("keypairs",), "ec2", "keypair"), (("keypair",), "ec2", "keypair"),
    (("keys",), "ec2", "keypair"), (("key",), "ec2", "keypair"),
    (("volumes",), "ec2", "volume"), (("volume",), "ec2", "volume"),
    (("disks",), "ec2", "volume"), (("disk",), "ec2", "volume"),
    (("ebs",), "ec2", "volume"),
    (("snapshots",), "ec2", "snapshot"), (("snapshot",), "ec2", "snapshot"),
    (("backups",), "ec2", "snapshot"), (("backup",), "ec2", "snapshot"),
    (("elastic", "ips"), "ec2", "eip"), (("elastic", "ip"), "ec2", "eip"),
    (("eips",), "ec2", "eip"), (("eip",), "ec2", "eip"),
    (("amis",), "ec2", "image"), (("ami",), "ec2", "image"),
    (("images",), "ec2", "image"), (("image",), "ec2", "image"),
    (("lambda", "functions"), "lambda", "function"),
    (("lambda", "function"), "lambda", "function"),
    (("functions",), "lambda", "function"), (("function",), "lambda", "function"),
    (("lambdas",), "lambda", "function"), (("lambda",), "lambda", "function"),
    (("db", "instances"), "rds", "db"), (("db", "instance"), "rds", "db"),
    (("db", "instances"), "rds", "db"), (("dbs",), "rds", "db"), (("db",), "rds", "db"),
    (("databases",), "rds", "db"), (("database",), "rds", "db"),
    (("rds", "instances"), "rds", "db"), (("rds", "instance"), "rds", "db"),
    (("rds",), "rds", "db"), (("mysql",), "rds", "db"), (("postgres",), "rds", "db"),
    (("postgresql",), "rds", "db"), (("aurora",), "rds", "db"),
    (("mariadb",), "rds", "db"), (("sqlserver",), "rds", "db"),
    (("dynamo", "tables"), "dynamodb", "table"), (("dynamo", "table"), "dynamodb", "table"),
    (("dynamodb", "tables"), "dynamodb", "table"), (("dynamodb", "table"), "dynamodb", "table"),
    (("tables",), "dynamodb", "table"), (("table",), "dynamodb", "table"),
    (("items",), "dynamodb", "item"), (("item",), "dynamodb", "item"),
    (("iam", "users"), "iam", "user"), (("iam", "user"), "iam", "user"),
    (("users",), "iam", "user"), (("user",), "iam", "user"),
    (("roles",), "iam", "role"), (("role",), "iam", "role"),
    (("policies",), "iam", "policy"), (("policy",), "iam", "policy"),
    (("access", "keys"), "iam", "accesskey"), (("access", "key"), "iam", "accesskey"),
    (("alarms",), "cw", "alarm"), (("alarm",), "cw", "alarm"),
    (("alerts",), "cw", "alarm"), (("alert",), "cw", "alarm"),
    (("cloudwatch", "alarms"), "cw", "alarm"),
    (("log", "groups"), "logs", "loggroup"), (("log", "group"), "logs", "loggroup"),
    (("loggroups",), "logs", "loggroup"), (("loggroup",), "logs", "loggroup"),
    (("cloudwatch",), "cw", "alarm"),
    (("ecs", "clusters"), "ecs", "cluster"), (("ecs", "cluster"), "ecs", "cluster"),
    (("clusters",), "ecs", "cluster"), (("cluster",), "ecs", "cluster"),
    (("ecs",), "ecs", "cluster"),
    (("ecs", "services"), "ecs", "service"), (("ecs", "service"), "ecs", "service"),
    (("services",), "ecs", "service"), (("service",), "ecs", "service"),
    (("task", "definitions"), "ecs", "taskdef"), (("taskdefs",), "ecs", "taskdef"),
    (("ecr", "repositories"), "ecr", "repo"), (("ecr", "repository"), "ecr", "repo"),
    (("ecr", "repos"), "ecr", "repo"), (("ecr", "repo"), "ecr", "repo"),
    (("repositories",), "ecr", "repo"), (("repository",), "ecr", "repo"),
    (("repos",), "ecr", "repo"), (("repo",), "ecr", "repo"),
    (("ecr",), "ecr", "repo"),
    (("load", "balancers"), "elb", "lb"), (("load", "balancer"), "elb", "lb"),
    (("loadbalancers",), "elb", "lb"), (("loadbalancer",), "elb", "lb"),
    (("elbs",), "elb", "lb"), (("elb",), "elb", "lb"), (("albs",), "elb", "lb"),
    (("alb",), "elb", "lb"), (("nlbs",), "elb", "lb"), (("nlb",), "elb", "lb"),
    (("target", "groups"), "elb", "tg"), (("target", "group"), "elb", "tg"),
    (("hosted", "zones"), "r53", "zone"), (("hosted", "zone"), "r53", "zone"),
    (("zones",), "r53", "zone"), (("zone",), "r53", "zone"),
    (("dns",), "r53", "zone"), (("route53",), "r53", "zone"),
    (("records",), "r53", "record"), (("record",), "r53", "record"),
    (("cloudformation", "stacks"), "cfn", "stack"),
    (("cloudformation", "stack"), "cfn", "stack"),
    (("cf", "stacks"), "cfn", "stack"), (("stacks",), "cfn", "stack"),
    (("stack",), "cfn", "stack"), (("cloudformation",), "cfn", "stack"),
    (("cfn",), "cfn", "stack"),
    (("sns", "topics"), "sns", "topic"), (("topics",), "sns", "topic"),
    (("topic",), "sns", "topic"), (("sns",), "sns", "topic"),
    (("sqs", "queues"), "sqs", "queue"), (("queues",), "sqs", "queue"),
    (("queue",), "sqs", "queue"), (("sqs",), "sqs", "queue"),
    (("eks", "clusters"), "eks", "cluster"), (("eks",), "eks", "cluster"),
    (("kubernetes",), "eks", "cluster"), (("k8s",), "eks", "cluster"),
    (("kms", "keys"), "kms", "key"), (("kms",), "kms", "key"),
    (("secrets",), "secrets", "secret"), (("secret",), "secrets", "secret"),
    (("secretsmanager",), "secrets", "secret"),
    (("cloudfront", "distributions"), "cf", "distribution"),
    (("distribution",), "cf", "distribution"), (("distributions",), "cf", "distribution"),
    (("cloudfront",), "cf", "distribution"), (("cdn",), "cf", "distribution"),
    (("auto", "scaling", "groups"), "asg", "asg"),
    (("autoscaling", "groups"), "asg", "asg"), (("asgs",), "asg", "asg"),
    (("asg",), "asg", "asg"), (("autoscaling",), "asg", "asg"),
    (("elasticache", "clusters"), "cache", "cache"),
    (("elasticache",), "cache", "cache"), (("redis",), "cache", "cache"),
    (("memcached",), "cache", "cache"), (("cache",), "cache", "cache"),
    (("api", "gateways"), "apigw", "api"), (("apigateway",), "apigw", "api"),
    (("apigw",), "apigw", "api"), (("apis",), "apigw", "api"), (("api",), "apigw", "api"),
    # bare service aliases
    (("ec2",), "ec2", "instance"), (("s3",), "s3", "bucket"),
    (("dynamodb",), "dynamodb", "table"), (("iam",), "iam", "user"),
    (("logs",), "logs", "loggroup"),
]

SERVICE_ALIASES = {  # service words that are not resources themselves
    "aws": None, "the": None, "a": None, "an": None, "my": None, "please": None,
    "me": None, "for": None, "all": "ALL", "of": None,
}

ID_RE = re.compile(
    r"^(i|vol|snap|sg|vpc|subnet|eni|ami|eipalloc|igw|nat|pcx|rtb|ltv|dopt|acl)-[0-9a-zA-Z]{6,}$")
ZONE_ID_RE = re.compile(r"^Z[0-9A-Z]{8,}$")
ARN_RE = re.compile(r"^arn:aws:")
URL_RE = re.compile(r"^https?://")
TYPE_RE = re.compile(r"^[a-z0-9]+\.(micro|small|medium|large|xlarge|2xlarge|3xlarge|"
                     r"4xlarge|6xlarge|8xlarge|10xlarge|12xlarge|16xlarge|22xlarge|24xlarge|32xlarge|metal[a-z0-9.-]*)$")
SIZE_WORDS = {"nano", "micro", "small", "medium", "large", "xlarge", "2xlarge",
              "3xlarge", "4xlarge", "6xlarge", "8xlarge", "metal"}
IP_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}(?:/\d{1,2})?$")
IDENT_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
PATH_HINT_RE = re.compile(r"^([A-Za-z]:[\\/]|[.~][/\\]|\\\\|.*\.(zip|yaml|yml|json|txt|pem|csv|pdf|png|jpg|log|py|js|ts|sql|exe|msi|tar|gz|csv))", re.I)
ENGINE_MAP = {"mysql": "mysql", "mariadb": "mariadb", "postgres": "postgres",
              "postgresql": "postgres", "aurora-mysql": "aurora-mysql",
              "aurora-postgres": "aurora-postgres", "aurora": "aurora-mysql",
              "sqlserver": "sqlserver-ex", "oracle": "oracle-se2"}
PORT_HINTS = {"ssh": 22, "http": 80, "https": 443, "postgres": 5432,
              "postgresql": 5432, "mysql": 3306, "mssql": 1433, "redis": 6379,
              "node": 3000, "flask": 5000, "django": 8000}
STOPWORDS = {"in", "on", "to", "with", "and", "for", "from", "as", "at", "by", "of",
             "the", "a", "an", "my", "please", "using", "use", "named", "called",
             "name", "then", "when", "that", "this", "it", "into", "onto", "about",
             "via", "region", "port", "ports", "open", "all", "any"}

# --------------------------------------------------------------------------- dataclass

@dataclass
class ParsedCommand:
    verb: str = ""
    service: str = ""
    resource: str = ""
    targets: list = field(default_factory=list)
    params: dict = field(default_factory=dict)
    raw: str = ""
    special: str = ""      # help | whoami | regions | clear | audit | connect | disconnect |
                           # set_region | set_profile | console | cli | boto3 | cost | unknown
    special_arg: str = ""


# --------------------------------------------------------------------------- helpers

def _tokenize(text: str) -> list[tuple[str, str, bool]]:
    """Return (original, lower, was_quoted) tokens."""
    try:
        raw_toks = shlex.split(text, posix=False)
    except ValueError:
        raw_toks = text.split()
    out = []
    for tok in raw_toks:
        quoted = len(tok) >= 2 and tok[0] == tok[-1] and tok[0] in "\"'"
        if quoted:
            tok = tok[1:-1]
        tok = tok.strip().strip(",").strip()
        if not tok:
            continue
        out.append((tok, tok.lower(), quoted))
    return out


def _region_from_tokens(low: list[str], used: list[bool]) -> str | None:
    """Find and consume a region mention. Checks bigrams then unigrams."""
    n = len(low)
    # explicit code first
    for i, w in enumerate(low):
        if not used[i] and re.match(r"^[a-z]{2}-(gov-)?[a-z]+-\d$", w):
            used[i] = True
            if i > 0 and low[i - 1] in ("region", "in", "to"):
                used[i - 1] = True
            return region_code_for(w)
    for i in range(n - 1):
        if used[i] or used[i + 1]:
            continue
        bigram = f"{low[i]} {low[i+1]}"
        code = region_code_for(bigram)
        if code:
            used[i] = used[i + 1] = True
            if i > 0 and low[i - 1] in ("region", "in", "to"):
                used[i - 1] = True
            return code
    for i, w in enumerate(low):
        if used[i]:
            continue
        code = region_code_for(w)
        if code and (w not in ("name", "key") and len(w) > 3 or w in ("uk", "uae")):
            used[i] = True
            if i > 0 and low[i - 1] in ("region", "in", "to"):
                used[i - 1] = True
            return code
    return None


# --------------------------------------------------------------------------- main parse

def parse(text: str) -> list[ParsedCommand]:
    text = (text or "").strip()
    if not text:
        return []
    commands: list[ParsedCommand] = []
    for part in re.split(r"\s*(?:;|\bthen\s+|\band then\s+)", text):
        part = part.strip()
        if part:
            cmd = parse_one(part)
            if cmd:
                commands.append(cmd)
    return commands


def parse_one(raw: str) -> ParsedCommand:
    low_raw = " ".join(raw.lower().split())

    # ---- special commands (checked before the general grammar) --------------
    if low_raw in ("help", "?", "commands", "usage", "examples", "what can you do"):
        return ParsedCommand(raw=raw, special="help")
    if low_raw in ("whoami", "who am i", "identity", "me", "my account", "account"):
        return ParsedCommand(raw=raw, special="whoami")
    if low_raw in ("regions", "list regions", "region list", "show regions"):
        return ParsedCommand(raw=raw, special="regions")
    if low_raw in ("clear", "cls", "clear screen", "clear log"):
        return ParsedCommand(raw=raw, special="clear")
    if low_raw in ("audit", "audit log", "history", "show history", "show audit"):
        return ParsedCommand(raw=raw, special="audit")
    if low_raw in ("connect", "login", "log in", "reconnect"):
        return ParsedCommand(raw=raw, special="connect")
    if low_raw in ("disconnect", "logout", "log out"):
        return ParsedCommand(raw=raw, special="disconnect")
    if low_raw in ("console", "open console", "aws console", "web console", "open aws console"):
        return ParsedCommand(raw=raw, special="console", special_arg="")
    m = re.match(r"^(?:open|show|launch)\s+(?:the\s+)?([a-z0-9 -]+?)\s+console$", low_raw)
    if m:
        return ParsedCommand(raw=raw, special="console", special_arg=m.group(1).strip())
    m = re.match(r"^(?:use|switch|set|change|go)\s+(?:to\s+)?region\s+(.+)$", low_raw)
    if not m:
        m = re.match(r"^(?:region|switch\s+region)\s+(.+)$", low_raw)
    if m:
        return ParsedCommand(raw=raw, special="set_region", special_arg=m.group(1).strip())
    m = re.match(r"^(?:use|switch|set|change)\s+(?:to\s+)?profile\s+(.+)$", low_raw)
    if m:
        return ParsedCommand(raw=raw, special="set_profile", special_arg=m.group(1).strip())
    m = re.match(r"^stack\s+events\s+(\S+)$", low_raw)
    if m:
        return ParsedCommand(verb="tail", service="cfn", resource="stack",
                             targets=[m.group(1)], raw=raw)
    if low_raw.startswith("aws "):
        return ParsedCommand(raw=raw, special="cli", special_arg=raw[4:].strip())
    if low_raw.startswith("boto3 "):
        return ParsedCommand(raw=raw, special="boto3", special_arg=raw[6:].strip())
    m = re.match(r"^cost\s+(?:for\s+)?(?:the\s+)?(?:last|past)\s+(\d+)\s*(?:d|day|days)?$", low_raw)
    if m:
        return ParsedCommand(raw=raw, special="cost", params={"days": int(m.group(1))})
    if re.match(r"^cost\s+(?:this|the)\s+month$", low_raw):
        return ParsedCommand(raw=raw, special="cost", params={"month": True})
    if re.match(r"^cost\s+(?:today|yesterday)", low_raw):
        return ParsedCommand(raw=raw, special="cost",
                             params={"days": 1, "today": "today" in low_raw})
    if re.match(r"^(cost|spend|billing|bill|how much.*)", low_raw) and "cost" not in low_raw.split()[:1]:
        pass  # fall through to general grammar (e.g. 'spend last 10 days' below)
    m = re.match(r"^(?:spend|billing|bill|how much (?:did i|have i|do i))\s+.*?(?:last|past)\s+(\d+)\s*(?:d|day|days)?.*$", low_raw)
    if m:
        return ParsedCommand(raw=raw, special="cost", params={"days": int(m.group(1))})
    if low_raw in ("cost", "spend", "cost report", "billing"):
        return ParsedCommand(raw=raw, special="cost", params={"days": 7})

    # ---- general grammar -----------------------------------------------------
    toks = _tokenize(raw)
    if not toks:
        return ParsedCommand(raw=raw, special="unknown")
    orig = [t[0] for t in toks]
    low = [t[1] for t in toks]
    quoted = [t[2] for t in toks]
    used = [False] * len(toks)
    params: dict = {}
    targets: list = []

    # 1. region
    region = _region_from_tokens(low, used)
    if region:
        params["region"] = region

    # 1b. payload (rest of line) and message (quoted or until a preposition)
    for i, w in enumerate(low):
        if used[i]:
            continue
        if w == "with" and i + 1 < len(low) and low[i + 1] == "payload":
            params["payload"] = " ".join(orig[j] for j in range(i + 2, len(low)))
            for j in range(i, len(low)):
                used[j] = True
            break
        if w == "payload":
            params["payload"] = " ".join(orig[j] for j in range(i + 1, len(low)))
            for j in range(i, len(low)):
                used[j] = True
            break
    for i, w in enumerate(low):
        if used[i]:
            continue
        if w in ("message", "msg", "text", "saying"):
            picked, j = [], i + 1
            while j < len(low) and low[j] not in ("to", "into", "on", "in", "for",
                                                  "with", "and", "then"):
                picked.append(orig[j])
                used[j] = True
                j += 1
            if picked:
                m = " ".join(picked)
                if len(m) >= 2 and m[0] == m[-1] and m[0] in "\"'":
                    m = m[1:-1]
                params["message"] = m
                used[i] = True
            break

    # 2. key=value pairs -> tags (and known param keys)
    tags: dict = {}
    for i, w in enumerate(low):
        if used[i]:
            continue
        if "=" in w and not IP_RE.match(w) and TYPE_RE.match(w) is None:
            k, _, v = w.partition("=")
            if k in ("prefix", "key", "value", "count", "limit", "size", "timeout", "message"):
                params[k] = v
            else:
                tags[k] = v
            used[i] = True

    # 3. resource noun phrase: collect ALL candidates, then prefer the earliest
    #    noun that is NOT preceded by a preposition ("attach volume X to instance Y"
    #    -> the object is 'volume'; 'instance' is just where it goes).
    service = resource = ""
    res_idx = -1
    PREPS = {"in", "on", "of", "for", "with", "to", "at", "from", "into", "using",
             "under", "about"}
    candidates = []
    for phrase, svc, res in sorted(RESOURCE_PHRASES, key=lambda p: -len(p[0])):
        L = len(phrase)
        for i in range(len(low) - L + 1):
            if all(not used[i + j] and low[i + j] == phrase[j] for j in range(L)):
                candidates.append((phrase, svc, res, i, L))
                break
    if candidates:
        def _rank(c):
            _ph, _svc, _res, i, L = c
            prep = i > 0 and low[i - 1] in PREPS
            return (i, prep, -L)  # earliest noun wins; preposition flags only break ties
        phrase, service, resource, res_idx, L = min(candidates, key=_rank)
        for j in range(L):
            used[res_idx + j] = True
        if service == "rds" and phrase[0] in ENGINE_MAP and "engine" not in params:
            params["engine"] = ENGINE_MAP[phrase[0]]

    # 4. ids / arns / urls / template files / zone ids / path-like names
    for i, w in enumerate(low):
        if used[i]:
            continue
        if (ID_RE.match(w) or ARN_RE.match(w) or URL_RE.match(w) or ZONE_ID_RE.match(w)
                or w.startswith("/") or w.endswith((".yaml", ".yml", ".json", ".template"))):
            targets.append(orig[i])
            used[i] = True

    # 5. instance type / size (single token, or family + size pair)
    for i, w in enumerate(low):
        if used[i] and TYPE_RE.match(w) is None:
            continue
        if TYPE_RE.match(w):
            params["instance_type"] = w
            used[i] = True
            break
        if (w in ("db",) or TYPE_RE.match(w) is None) and w in SIZE_WORDS:
            fam = "t3" if service != "rds" else "db.t3"
            params["instance_type"] = f"{fam}.{w}"
            used[i] = True
            break
        if (i + 1 < len(low) and not used[i + 1] and low[i + 1] in SIZE_WORDS
                and re.match(r"^[a-z0-9]{2,6}$", w) and w not in STOPWORDS
                and w in ("t2", "t3", "t3a", "m5", "m5a", "m6i", "m6g", "c5", "c6i", "c6g",
                          "r5", "r6i", "r6g", "x1", "x2", "i3", "i4i", "g4", "g5", "p3",
                          "p4", "inf1", "a1", "mac1", "mac2", "db.t3", "db.t4g", "db.m5",
                          "db.r5", "db.r6g", "db.m6g")):
            params["instance_type"] = f"{w}.{low[i+1]}"
            used[i] = used[i + 1] = True
            break

    # 6. engine / runtime / windows / ubuntu
    for i, w in enumerate(low):
        if used[i]:
            continue
        if w in ENGINE_MAP:
            params["engine"] = ENGINE_MAP[w]
            if w in PORT_HINTS and service in ("ec2", ""):
                params.setdefault("ports", set()).add(PORT_HINTS[w])
            used[i] = True
        if w == "windows":
            params["windows"] = True
            used[i] = True
        if w == "ubuntu":
            params["ubuntu"] = True
            used[i] = True
        if re.match(r"^(python|nodejs|java|dotnet|ruby|go|provided)\d*[a-z0-9.]*$", w) and len(w) > 5:
            params["runtime"] = w
            used[i] = True
        if w in ("gp2", "gp3", "io1", "io2", "st1", "sc1"):
            params["volume_type"] = w
            used[i] = True

    # 7. cidrs / ips / anywhere
    for i, w in enumerate(low):
        if used[i]:
            continue
        if IP_RE.match(w):
            cidr = w if "/" in w else w + "/32"
            params.setdefault("cidrs", []).append(cidr)
            used[i] = True
        if w in ("anywhere", "world", "everywhere", "internet", "public"):
            params.setdefault("cidrs", []).append("0.0.0.0/0")
            used[i] = True
        if w in ("all",) and service == "ec2" and resource in ("sg", "") and not targets:
            params["all_traffic"] = True
            used[i] = True

    # 8. ports after 'port/ports', or port-hint words
    ports: list[int] = params.get("ports", [])
    if isinstance(ports, set):
        ports = sorted(ports)
    i = 0
    while i < len(low):
        if not used[i] and low[i] in ("port", "ports"):
            used[i] = True
            j = i + 1
            while j < len(low):
                if not used[j] and re.match(r"^\d{1,5}$", low[j]) and 1 <= int(low[j]) <= 65535:
                    if int(low[j]) not in ports:
                        ports.append(int(low[j]))
                    used[j] = True
                elif low[j] in ("and", ",", "or"):
                    used[j] = True
                else:
                    break
                j += 1
            i = j
        else:
            i += 1
    for i, w in enumerate(low):
        if not used[i] and w in PORT_HINTS and service in ("ec2", ""):
            if PORT_HINTS[w] not in ports:
                ports.append(PORT_HINTS[w])
            used[i] = True
        if not used[i] and low[i] in ("tcp", "udp", "icmp"):
            params["protocol"] = w
            used[i] = True
    if ports:
        params["ports"] = ports

    # 9. count (x3 / 3 instances / count 3)
    for i, w in enumerate(low):
        if used[i]:
            continue
        m = re.match(r"^x(\d+)$", w)
        if m:
            params["count"] = int(m.group(1)); used[i] = True; break
        if (re.match(r"^\d+$", w) and ((i + 1 < len(low) and low[i + 1] in
                ("instances", "vms", "servers", "buckets", "queues", "topics", "users", "keys"))
                or (i > 0 and low[i - 1] in ("count", "times")))):
            params["count"] = int(w); used[i] = True
            if i > 0 and low[i - 1] == "count":
                used[i - 1] = True
            break
    # volume/db size "100 gb" / "100gb"
    for i, w in enumerate(low):
        if used[i]:
            continue
        m = re.match(r"^(\d+)gb$", w)
        if m:
            params["size_gb"] = int(m.group(1)); used[i] = True; continue
        if re.match(r"^\d+$", w) and i + 1 < len(low) and low[i + 1] in ("gb", "gigabytes"):
            params["size_gb"] = int(w); used[i] = used[i + 1] = True

    # 10. threshold (for alarms): 'at 80' 'over 80' '> 80' '80 percent'
    for i, w in enumerate(low):
        if used[i]:
            continue
        if re.match(r"^\d+(\.\d+)?$", w) and ((i > 0 and low[i - 1] in ("at", "over", "above", ">", "threshold", "than"))):
            params["threshold"] = float(w); used[i] = True
        if re.match(r"^(\d+)m(in|inutes)?$", w) and i > 0 and low[i - 1] == "for":
            params["period"] = int(re.match(r"^(\d+)", w).group(1)) * 60
            used[i] = True
        if re.match(r"^\d+m$", w) and i > 0 and low[i - 1] == "for":
            params["period"] = int(w[:-1]) * 60; used[i] = True
    if "period" not in params:
        for i, w in enumerate(low):
            if not used[i] and re.match(r"^\d+$", w) and i + 1 < len(low) and low[i + 1].startswith("minute"):
                params["period"] = int(w) * 60; used[i] = used[i + 1] = True

    # 11. verb (first verb-ish token)
    verb = ""
    for i, w in enumerate(low):
        if w in VERBS:
            verb = VERBS[w]
            used[i] = True
            break

    # 12. name: quoted / after named|called|name / token after resource noun
    #     (runs BEFORE container markers so "create queue jobs" keeps its name)
    name = None
    for i, w in enumerate(low):
        if not used[i] and w in ("named", "called", "name") and i + 1 < len(low):
            cand = orig[i + 1]
            if IDENT_RE.match(cand) or quoted[i + 1]:
                name = cand; used[i] = used[i + 1] = True
            break
    if name is None:
        for i, q in enumerate(quoted):
            if q and not used[i] and IDENT_RE.match(orig[i]):
                name = orig[i]; used[i] = True
                break
    if name is None and res_idx >= 0:
        j = res_idx + 1
        while j < len(low) and used[j]:
            j += 1
        if j < len(low) and IDENT_RE.match(orig[j]) and low[j] not in VERBS \
                and low[j] not in STOPWORDS and not re.match(r"^\d+$", low[j]):
            name = orig[j]; used[j] = True
    if name:
        params["name"] = name
        if not targets and verb in ("create", "delete", "describe", "empty", "invoke",
                                    "start", "stop", "reboot", "open", "close", "tail",
                                    "upload", "download", "send", "terminate", "describe"):
            targets.append(name)

    # 13. container markers: value / as / user / vpc / subnet / role / queue / topic ...
    def grab_after(marker_words: list[str], allow_multi: bool = False) -> str | None:
        for i, w in enumerate(low):
            if w in marker_words and i + 1 < len(low) and not used[i] and not used[i + 1]:
                if allow_multi:
                    picked, j = [], i + 1
                    while j < len(low) and low[j] not in STOPWORDS:
                        picked.append(orig[j])
                        used[j] = True
                        j += 1
                    if picked:
                        used[i] = True
                        return " ".join(picked)
                else:
                    used[i] = True
                    used[i + 1] = True
                    return orig[i + 1]
        return None

    for marker, pkey in ((["payload"], "payload"),
                         (["value"], "value"), (["as"], "as_key"),
                         (["user"], "user"), (["role"], "role_name"),
                         (["vpc"], "vpc_id"), (["subnet"], "subnet_id"),
                         (["cluster"], "cluster"), (["family"], "family"),
                         (["queue"], "queue"), (["topic"], "topic"),
                         (["key"], "dynamo_key"), (["timeout"], "timeout"),
                         (["limit"], "limit"), (["handler"], "handler"),
                         (["engine"], "engine"), (["zone"], "zone"),
                         (["bucket"], "bucket")):
        if marker[0] == resource or (marker == ["key"] and resource == "keypair"):
            continue  # the object noun itself, not a container reference
        val = grab_after(marker)
        if val is not None and pkey not in params:
            params[pkey] = val

    # payload as raw json token(s)
    m = re.search(r"\{.*\}", raw)
    if m and "payload" not in params:
        params["payload"] = m.group(0)

    # template file for cloudformation
    m = re.search(r"from\s+(\S+\.(?:yaml|yml|json|template))", raw, re.I)
    if m:
        params["template"] = m.group(1)
        for i, w in enumerate(low):
            if orig[i] == m.group(1):
                used[i] = True

    # 14. leftover numbers as ports when verb is open/close; capture state filters
    for i, w in enumerate(low):
        if not used[i] and re.match(r"^\d+$", w) and verb in ("open", "close"):
            if int(w) not in ports and 1 <= int(w) <= 65535:
                ports.append(int(w)); used[i] = True
    if ports:
        params["ports"] = ports
    for i, w in enumerate(low):
        if not used[i] and w in ("running", "stopped", "stopping", "pending", "terminated",
                                 "available", "in-use", "healthy", "critical", "ok", "alarm"):
            params["state"] = w; used[i] = True

    # 15. 'all' wildcard for bulk actions
    for i, w in enumerate(low):
        if not used[i] and w == "all":
            targets.insert(0, "*"); used[i] = True

    # 15b. post-processing fixes
    if service == "rds" and "instance_type" in params \
            and not params["instance_type"].startswith("db."):
        params["instance_type"] = "db." + params["instance_type"]
    if service == "s3" and resource == "bucket" and verb in ("upload", "download"):
        resource = "object"
    if not resource and targets:
        t0 = targets[0]
        for prefix, svc, res in (("i-", "ec2", "instance"), ("vol-", "ec2", "volume"),
                                 ("sg-", "ec2", "sg"), ("subnet-", "ec2", "subnet"),
                                 ("vpc-", "ec2", "vpc"), ("snap-", "ec2", "snapshot"),
                                 ("ami-", "ec2", "image"), ("eipalloc-", "ec2", "eip"),
                                 ("arn:aws:sns", "sns", "topic"),
                                 ("arn:aws:sqs", "sqs", "queue"),
                                 ("arn:aws:lambda", "lambda", "function"),
                                 ("arn:aws:iam", "iam", "user")):
            if t0.startswith(prefix):
                service, resource = svc, res
                break
        else:
            if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", t0):
                service, resource = "ec2", "eip"
            elif ZONE_ID_RE.match(t0):
                service, resource = "r53", "zone"
            elif t0.startswith("/"):
                service, resource = "logs", "loggroup"

    # 15c. last-resort name from leftover identifiers
    if not targets and not params.get("name") and resource:
        PHRASE_HEADS = {p[0] for p, _, _ in RESOURCE_PHRASES}
        for i, w in enumerate(low):
            if not used[i] and IDENT_RE.match(orig[i]) and w not in VERBS \
                    and w not in STOPWORDS and w not in PHRASE_HEADS \
                    and w not in SERVICE_ALIASES and not re.match(r"^\d+$", w):
                params["name"] = orig[i]
                targets.append(orig[i])
                used[i] = True
                break

    # 16. remaining unconsumed tokens kept for upload/download src/dst & fallbacks
    leftovers = [orig[i] for i in range(len(low)) if not used[i]]
    if leftovers:
        params["extra"] = leftovers

    if not verb:
        verb = "list" if resource else ""
    if not verb and not resource and not targets:
        return ParsedCommand(raw=raw, special="unknown")
    if not resource and not service and verb in ("upload", "download") and "extra" in params:
        service, resource = "s3", "object"

    return ParsedCommand(verb=verb, service=service or "ec2", resource=resource,
                         targets=targets, params=params, raw=raw)
