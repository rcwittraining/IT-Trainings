"""RCW - AWSNixOps GUI (Tkinter).

A single-window app: sidebar for connection/quick-actions/safety, a chat log
for results, and a prompt box where you type plain English to deploy & manage
AWS. All AWS calls run in background threads; the window never freezes.
"""
from __future__ import annotations

import queue
import threading
import webbrowser
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox, font as tkfont

from .core import (AwsManager, Msg, load_config, save_config,
                   available_profiles, REGIONS, region_name_for, VERSION, APP_NAME,
                   save_credentials_profile, AuditLog)
from .demo import DemoManager
from .parser import parse
from .handlers import Executor

# ------------------------------------------------------------------ palette
C_BG      = "#0b1220"
C_PANEL   = "#101a2e"
C_PANEL2  = "#0d1626"
C_CHAT    = "#0a111e"
C_ENTRY   = "#13203a"
C_FG      = "#dbe4f3"
C_DIM     = "#8fa3c0"
C_ACCENT  = "#22d3ee"
C_OK      = "#4ade80"
C_WARN    = "#fbbf24"
C_ERR     = "#f87171"
C_USER    = "#67e8f9"
C_HEAD    = "#f1f5f9"
C_BORDER  = "#1e2c47"

UI_FONT   = ("Segoe UI", 10)
UI_FONT_B = ("Segoe UI", 10, "bold")
TITLE_F   = ("Segoe UI", 15, "bold")
MONO_F    = ("Consolas", 10)


def _pick(candidates, default):
    try:
        fams = set(tkfont.families())
        for c in candidates:
            if c in fams:
                return c
    except Exception:
        pass
    return default


class ConfirmBridge:
    """Worker threads ask the GUI for confirmation (thread-safe via queue+Event)."""

    def __init__(self, q: queue.Queue):
        self.q = q

    def __call__(self, text: str) -> bool:
        ev = threading.Event()
        holder: dict = {}
        self.q.put(("confirm", text, ev, holder))
        ev.wait(300)
        return bool(holder.get("ans"))


class App:
    def __init__(self, root: tk.Tk, demo: bool = False, autoshot: list | None = None):
        self.root = root
        self.cfg = load_config()
        self.mgr = DemoManager() if demo else AwsManager()
        self.audit = AuditLog()
        self.q: queue.Queue = queue.Queue()
        self.confirm_bridge = ConfirmBridge(self.q)
        self.history: list[str] = []
        self.hist_idx = -1
        self.busy = False

        mono_family = _pick(["Cascadia Mono", "Consolas", "DejaVu Sans Mono"], "Courier New")
        self.mono = (mono_family, 10)
        ui_family = _pick(["Segoe UI", "Noto Sans", "DejaVu Sans"], "Helvetica")
        self.ui = (ui_family, 10)
        self.ui_b = (ui_family, 10, "bold")
        self.title_f = (ui_family, 16, "bold")

        self._style()
        self._build()
        self._banner(demo)
        if demo:
            self._show_identity(self.mgr.identity)
        root.after(80, self._poll)
        if autoshot:
            root.after(1200, lambda: self._autoshot(list(autoshot)))

    # ---------------------------------------------------------------- style
    def _style(self):
        self.root.title(f"{APP_NAME}  v{VERSION}" + ("  [DEMO]" if getattr(self.mgr, 'demo', False) else ""))
        self.root.geometry("1240x780")
        self.root.minsize(1000, 640)
        self.root.configure(bg=C_BG)
        try:
            self.root.state("zoomed")
        except Exception:
            pass
        try:
            from pathlib import Path
            logo = Path(__file__).resolve().parent.parent / "assets" / "logo.png"
            if logo.exists():
                img = tk.PhotoImage(file=str(logo))
                img = img.subsample(2, 2)
                self.root.iconphoto(True, img)
                self._logo_img = img
        except Exception:
            pass
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("TCombobox", fieldbackground=C_ENTRY, background=C_PANEL,
                        foreground=C_FG, arrowcolor=C_ACCENT, bordercolor=C_BORDER,
                        lightcolor=C_BORDER, darkcolor=C_BORDER)
        self.root.option_add("*TCombobox*Listbox.background", C_PANEL)
        self.root.option_add("*TCombobox*Listbox.foreground", C_FG)
        self.root.option_add("*TCombobox*Listbox.selectBackground", C_ACCENT)
        self.root.option_add("*TCombobox*Listbox.selectForeground", C_BG)
        style.configure("Vertical.TScrollbar", background=C_PANEL, troughcolor=C_CHAT,
                        bordercolor=C_CHAT, arrowcolor=C_DIM)

    # ---------------------------------------------------------------- widgets
    def _btn(self, parent, text, cmd, primary=False, small=False):
        bg = C_ACCENT if primary else C_PANEL
        fg = "#06202b" if primary else C_FG
        b = tk.Button(parent, text=text, command=cmd, bg=bg, fg=fg, relief="flat",
                      font=self.ui_b if primary else self.ui,
                      activebackground="#67e8f9" if primary else C_BORDER,
                      activeforeground=fg if primary else C_FG, cursor="hand2",
                      bd=0, padx=10, pady=4 if small else 6)
        b.bind("<Enter>", lambda e, w=b, p=primary: w.configure(
            bg="#67e8f9" if p else C_BORDER))
        b.bind("<Leave>", lambda e, w=b, p=primary: w.configure(
            bg=C_ACCENT if p else C_PANEL))
        return b

    def _build(self):
        # ---- menu
        menubar = tk.Menu(self.root, bg=C_PANEL, fg=C_FG, activebackground=C_BORDER,
                          activeforeground=C_FG, bd=0)
        m_file = tk.Menu(menubar, tearoff=0, bg=C_PANEL, fg=C_FG,
                         activebackground=C_BORDER, activeforeground=C_FG)
        m_file.add_command(label="Exit", command=self.root.destroy)
        menubar.add_cascade(label="File", menu=m_file)
        m_sess = tk.Menu(menubar, tearoff=0, bg=C_PANEL, fg=C_FG,
                         activebackground=C_BORDER, activeforeground=C_FG)
        m_sess.add_command(label="Connect", command=self._connect_clicked)
        m_sess.add_command(label="Configure AWS credentials...", command=self._cred_dialog)
        m_sess.add_command(label="Disconnect", command=lambda: self._run_now("disconnect"))
        menubar.add_cascade(label="Session", menu=m_sess)
        m_view = tk.Menu(menubar, tearoff=0, bg=C_PANEL, fg=C_FG,
                         activebackground=C_BORDER, activeforeground=C_FG)
        m_view.add_command(label="Command reference  (F1)", command=self._help_window)
        m_view.add_command(label="Audit log", command=self._audit_window)
        m_view.add_command(label="Clear chat", command=lambda: self._run_now("clear"))
        menubar.add_cascade(label="View", menu=m_view)
        m_help = tk.Menu(menubar, tearoff=0, bg=C_PANEL, fg=C_FG,
                         activebackground=C_BORDER, activeforeground=C_FG)
        m_help.add_command(label="AWS setup guide", command=self._setup_guide)
        m_help.add_command(label="About", command=self._about)
        menubar.add_cascade(label="Help", menu=m_help)
        self.root.config(menu=menubar)
        self.root.bind("<F1>", lambda e: self._help_window())

        # ---- layout
        body = tk.Frame(self.root, bg=C_BG)
        body.pack(fill="both", expand=True)

        self.sidebar = tk.Frame(body, bg=C_PANEL2, width=300, bd=0,
                                highlightbackground=C_BORDER, highlightthickness=1)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        main = tk.Frame(body, bg=C_BG)
        main.pack(side="left", fill="both", expand=True, padx=10, pady=10)

        # ---- sidebar content
        top = tk.Frame(self.sidebar, bg=C_PANEL2)
        top.pack(fill="x", padx=14, pady=(14, 6))
        tk.Label(top, text="RCW", font=self.title_f, bg=C_PANEL2, fg=C_ACCENT).pack(anchor="w")
        tk.Label(top, text="AWSNixOps", font=(self.ui[0], 11, "bold"), bg=C_PANEL2,
                 fg=C_FG).pack(anchor="w")
        tk.Label(top, text="Deploy & manage AWS\nby typing English", font=self.ui,
                 bg=C_PANEL2, fg=C_DIM, justify="left").pack(anchor="w", pady=(2, 0))

        card = tk.Frame(self.sidebar, bg=C_PANEL, bd=0, highlightbackground=C_BORDER,
                        highlightthickness=1)
        card.pack(fill="x", padx=12, pady=8)
        tk.Label(card, text="CONNECTION", font=self.ui_b, bg=C_PANEL, fg=C_ACCENT
                 ).pack(anchor="w", padx=10, pady=(8, 2))

        tk.Label(card, text="AWS profile", font=self.ui, bg=C_PANEL, fg=C_DIM
                 ).pack(anchor="w", padx=10)
        self.profile_var = tk.StringVar()
        self.profile_combo = ttk.Combobox(card, textvariable=self.profile_var, state="readonly",
                                          font=self.ui, width=26)
        self.profile_combo.pack(fill="x", padx=10, pady=(0, 6))
        self._refresh_profiles()

        tk.Label(card, text="Region", font=self.ui, bg=C_PANEL, fg=C_DIM).pack(anchor="w", padx=10)
        region_vals = [f"{code}  ({name})" for code, name in REGIONS]
        cur = self.cfg.get("region", self.mgr.region)
        self.region_var = tk.StringVar(
            value=next((v for v in region_vals if v.startswith(cur)), region_vals[0]))
        rc = ttk.Combobox(card, textvariable=self.region_var, values=region_vals,
                          font=self.ui, width=26)
        rc.pack(fill="x", padx=10, pady=(0, 6))
        self.region_combo = rc

        row = tk.Frame(card, bg=C_PANEL)
        row.pack(fill="x", padx=10, pady=(0, 8))
        self._btn(row, "Connect", self._connect_clicked, primary=True).pack(
            side="left", expand=True, fill="x", padx=(0, 4))
        self._btn(row, "Configure AWS...", self._cred_dialog, small=True).pack(
            side="left", expand=True, fill="x")

        self.demo_btn = self._btn(card, "Try Demo Mode (no AWS needed)",
                                  self._toggle_demo)
        self.demo_btn.pack(fill="x", padx=10, pady=(0, 8))

        self.identity_lbl = tk.Label(card, text="not connected", font=("Consolas", 9),
                                     bg=C_PANEL, fg=C_DIM, justify="left", wraplength=250)
        self.identity_lbl.pack(anchor="w", padx=10, pady=(0, 10))

        # quick actions
        qa = tk.Frame(self.sidebar, bg=C_PANEL, bd=0, highlightbackground=C_BORDER,
                      highlightthickness=1)
        qa.pack(fill="x", padx=12, pady=8)
        tk.Label(qa, text="QUICK ACTIONS", font=self.ui_b, bg=C_PANEL, fg=C_ACCENT
                 ).pack(anchor="w", padx=10, pady=(8, 4))
        for label, cmd in (("List instances", "list instances"),
                           ("List S3 buckets", "list buckets"),
                           ("Spend this month", "cost this month"),
                           ("Alarms", "list alarms"),
                           ("Who am I?", "whoami"),
                           ("Command reference", "help"),
                           ("Open AWS console", "open console")):
            b = tk.Label(qa, text="›  " + label, font=self.ui, bg=C_PANEL, fg=C_FG,
                         cursor="hand2", anchor="w")
            b.pack(fill="x", padx=10, pady=1)
            b.bind("<Button-1>", lambda e, c=cmd: self._run_now(c))
            b.bind("<Enter>", lambda e, w=b: w.configure(fg=C_ACCENT))
            b.bind("<Leave>", lambda e, w=b: w.configure(fg=C_FG))

        # safety card
        sf = tk.Frame(self.sidebar, bg=C_PANEL, bd=0, highlightbackground=C_BORDER,
                      highlightthickness=1)
        sf.pack(fill="x", padx=12, pady=8)
        tk.Label(sf, text="SAFETY", font=self.ui_b, bg=C_PANEL, fg=C_ACCENT
                 ).pack(anchor="w", padx=10, pady=(8, 4))
        self.confirm_var = tk.BooleanVar(value=self.cfg.get("confirm", True))
        cb1 = tk.Checkbutton(sf, text="Confirm before destructive actions", variable=self.confirm_var,
                             font=self.ui, bg=C_PANEL, fg=C_FG, selectcolor=C_ENTRY,
                             activebackground=C_PANEL, activeforeground=C_FG,
                             highlightthickness=0, anchor="w")
        cb1.pack(fill="x", padx=10)
        self.dry_var = tk.BooleanVar(value=False)
        cb2 = tk.Checkbutton(sf, text="Dry run (preview only, no changes)", variable=self.dry_var,
                             font=self.ui, bg=C_PANEL, fg=C_FG, selectcolor=C_ENTRY,
                             activebackground=C_PANEL, activeforeground=C_FG,
                             highlightthickness=0, anchor="w",
                             command=lambda: self._run_now("help") if False else None)
        cb2.pack(fill="x", padx=10, pady=(0, 8))
        cb2.bind("<Button-1>", lambda e: self._after_say(
            "Dry-run mode ON - commands will only be previewed." if not self.dry_var.get()
            else "Dry-run mode OFF."))

        tk.Label(self.sidebar, text=f"v{VERSION} · audit log in logs/ folder",
                 font=self.ui, bg=C_PANEL2, fg=C_DIM).pack(side="bottom", pady=8)

        # ---- chat area
        chat_frame = tk.Frame(main, bg=C_BORDER, bd=0, highlightbackground=C_BORDER,
                              highlightthickness=1)
        chat_frame.pack(fill="both", expand=True)
        self.chat = tk.Text(chat_frame, bg=C_CHAT, fg=C_FG, font=self.ui, wrap="word",
                            relief="flat", state="disabled", padx=14, pady=10,
                            insertbackground=C_FG, selectbackground=C_BORDER)
        sb = ttk.Scrollbar(chat_frame, command=self.chat.yview)
        self.chat.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.chat.pack(fill="both", expand=True)
        for tag, fg, fnt in (("user", C_USER, self.ui_b), ("info", C_FG, self.ui),
                             ("ok", C_OK, self.ui), ("warn", C_WARN, self.ui),
                             ("err", C_ERR, self.ui), ("head", C_HEAD, self.ui_b),
                             ("mono", "#a9bcd6", self.mono), ("dim", C_DIM, self.ui)):
            self.chat.tag_configure(tag, foreground=fg, font=fnt)

        # ---- prompt bar
        bar = tk.Frame(main, bg=C_BG)
        bar.pack(fill="x", pady=(10, 0))
        self.entry_var = tk.StringVar()
        self.entry = tk.Entry(bar, textvariable=self.entry_var, font=(self.ui[0], 12),
                              bg=C_ENTRY, fg=C_FG, relief="flat", insertbackground=C_ACCENT,
                              bd=0)
        self.entry.pack(side="left", fill="x", expand=True, ipady=9, padx=(8, 8))
        self.entry.bind("<Return>", lambda e: self._send())
        self.entry.bind("<Up>", self._hist_up)
        self.entry.bind("<Down>", self._hist_down)
        self.send_btn = self._btn(bar, "SEND ⏎", self._send, primary=True)
        self.send_btn.pack(side="right")

        # ---- status bar
        self.status_var = tk.StringVar(value="Ready.")
        st = tk.Label(self.root, textvariable=self.status_var, font=("Consolas", 9),
                      bg=C_PANEL, fg=C_DIM, anchor="w")
        st.pack(fill="x", side="bottom")

        self._set_status()

    # ---------------------------------------------------------------- helpers
    def _set_status(self, extra: str = ""):
        mode = "DEMO" if getattr(self.mgr, "demo", False) else (
            "connected" if self.mgr.connected else "not connected")
        self.status_var.set(
            f" {mode}  ·  {self.mgr.profile}  ·  {self.mgr.region} "
            f"({region_name_for(self.mgr.region)})   {extra}")

    def _refresh_profiles(self):
        profiles = available_profiles() or ["default"]
        self.profile_combo["values"] = profiles + ["+ new (paste access key)..."]
        if self.cfg.get("profile") in profiles:
            self.profile_var.set(self.cfg["profile"])
        else:
            self.profile_var.set(profiles[0])

    def _append(self, kind: str, text: str):
        self.chat.configure(state="normal")
        stamp = datetime.now().strftime("%H:%M:%S ")
        if kind == "user":
            self.chat.insert("end", "\n" + stamp + "› ", "dim")
            self.chat.insert("end", text + "\n", "user")
        elif kind == "clear":
            self.chat.delete("1.0", "end")
        else:
            prefix = {"ok": "✔ ", "err": "✖ ", "warn": "▲ ", "head": ""}.get(kind, "")
            self.chat.insert("end", f"{stamp}{prefix}", "dim")
            self.chat.insert("end", text + "\n", kind)
        self.chat.configure(state="disabled")
        self.chat.see("end")

    def _banner(self, demo: bool):
        if demo:
            self._append("ok", "DEMO MODE - exploring a simulated AWS account. "
                               "Nothing here touches real AWS.")
        else:
            self._append("info",
                         "Welcome to RCW - AWSNixOps.\n"
                         "Deploy and manage AWS services by typing plain English below.")
        if not self.mgr.connected and not demo:
            self._append("warn",
                         "Not connected yet. Click 'Connect' (uses your saved AWS profile) or "
                         "'Configure AWS...' to paste an access key.\n"
                         "Just exploring? Click 'Try Demo Mode'.")
        self._append("dim", "Type 'help' for the full command reference. "
                            "Try: list instances   ·   create bucket my-test-2026   ·   "
                            "cost last 7 days")

    # ---------------------------------------------------------------- queue polling
    def _poll(self):
        try:
            while True:
                item = self.q.get_nowait()
                kind = item[0]
                if kind == "msgs":
                    for m in item[1]:
                        self._append(m.kind, m.text)
                    self.busy = False
                    self.send_btn.configure(text="SEND ⏎", state="normal")
                    self._set_status()
                elif kind == "confirm":
                    _, text, ev, holder = item
                    ans = messagebox.askyesno("Confirm action",
                                              text, parent=self.root, icon="warning")
                    holder["ans"] = ans
                    ev.set()
                elif kind == "status":
                    self._set_status(item[1])
                elif kind == "identity":
                    self._show_identity(item[1])
        except queue.Empty:
            pass
        self.root.after(80, self._poll)

    def _show_identity(self, ident: dict | None):
        if not ident:
            self.identity_lbl.configure(text="not connected", fg=C_DIM)
            return
        self.identity_lbl.configure(
            text=f"acct {ident.get('account')}\n{ident.get('user')}",
            fg=C_OK)

    # ---------------------------------------------------------------- command flow
    def _send(self):
        raw = self.entry_var.get().strip()
        if not raw:
            return
        self.entry_var.set("")
        self._dispatch(raw)

    def _run_now(self, cmd: str):
        self._dispatch(cmd)

    def _after_say(self, text: str):
        self._append("dim", text)

    def _dispatch(self, raw: str):
        if self.busy:
            self._append("warn", "Still working on the previous command - one moment.")
            return
        self.busy = True
        self.send_btn.configure(text="...", state="disabled")
        self.history.append(raw)
        self.hist_idx = len(self.history)
        self._append("user", raw)
        self._set_status("working...")
        if raw.strip().lower() == "clear":
            self._append("clear", "")
            self.busy = False
            self.send_btn.configure(text="SEND ⏎", state="normal")
            return
        threading.Thread(target=self._worker, args=(raw,), daemon=True).start()

    def _worker(self, raw: str):
        try:
            cmds = parse(raw)
            if not cmds:
                self.q.put(("msgs", [Msg("warn", "Empty command.")]))
                return
            ex = Executor(self.mgr, dry_run=self.dry_var.get(),
                          confirm=self.confirm_bridge if self.confirm_var.get()
                          else (lambda t: True),
                          audit=self.audit)
            out = []
            for c in cmds:
                out.extend(ex.execute(c))
            self.q.put(("msgs", out))
            if self.mgr.connected and not getattr(self.mgr, "demo", False):
                self.q.put(("identity", self.mgr.identity))
        except Exception as e:
            self.q.put(("msgs", [Msg("err", f"Internal error: {e}")]))
            self.q.put(("msgs", []))

    # ---------------------------------------------------------------- history
    def _hist_up(self, _e):
        if self.hist_idx > 0:
            self.hist_idx -= 1
            self.entry_var.set(self.history[self.hist_idx])
        return "break"

    def _hist_down(self, _e):
        if self.hist_idx < len(self.history) - 1:
            self.hist_idx += 1
            self.entry_var.set(self.history[self.hist_idx])
        else:
            self.hist_idx = len(self.history)
            self.entry_var.set("")
        return "break"

    # ---------------------------------------------------------------- connection
    def _region_selected(self) -> str:
        return self.region_var.get().split(" ")[0]

    def _connect_clicked(self):
        prof = self.profile_var.get()
        if prof.startswith("+"):
            self._cred_dialog()
            return
        region = self._region_selected()
        self._append("dim", f"Connecting with profile '{prof}' in {region}...")
        threading.Thread(target=self._connect_worker, args=(prof, region), daemon=True).start()

    def _connect_worker(self, prof: str, region: str, keys: dict | None = None):
        try:
            ident = self.mgr.connect(profile=prof, region=region, keys=keys)
            self.cfg.update({"profile": prof, "region": region})
            save_config(self.cfg)
            self.q.put(("msgs", [Msg("ok", f"Connected to AWS.\nAccount : {ident.get('account')}\n"
                                           f"Identity: {ident.get('arn')}\n"
                                           f"Region  : {region}")]))
            self.q.put(("identity", ident))
        except Exception as e:
            hint = ""
            s = str(e)
            if "credentials" in s.lower() or "ExpiredToken" in s or "Token" in s:
                hint = "\nHint: click 'Configure AWS...' to paste a valid access key."
            elif "profile" in s.lower() or "ProfileNotFound" in type(e).__name__:
                hint = "\nHint: that profile does not exist in ~/.aws/credentials."
            self.q.put(("msgs", [Msg("err", f"Could not connect: {e}{hint}")]))
            self.q.put(("msgs", []))

    def _toggle_demo(self):
        if getattr(self.mgr, "demo", False):
            self.mgr = AwsManager()
            self.mgr.region = self._region_selected()
            self.demo_btn.configure(text="Try Demo Mode (no AWS needed)")
            self._append("info", "Left demo mode. Click 'Connect' to use real AWS credentials.")
            self._show_identity(None)
        else:
            self.mgr = DemoManager()
            self.demo_btn.configure(text="Exit demo mode")
            self._append("ok", "DEMO MODE ON - a simulated AWS account. "
                               "Try: list instances  ·  cost last 7 days  ·  help")
            self._show_identity(self.mgr.identity)
        self._set_status()

    # ---------------------------------------------------------------- dialogs & windows
    def _cred_dialog(self):
        win = tk.Toplevel(self.root)
        win.title("Configure AWS credentials")
        win.configure(bg=C_PANEL, bd=0, highlightbackground=C_BORDER, highlightthickness=1)
        win.geometry("520x430")
        win.transient(self.root)
        win.grab_set()

        tk.Label(win, text="Connect to AWS", font=(self.ui[0], 13, "bold"), bg=C_PANEL,
                 fg=C_ACCENT).pack(anchor="w", padx=18, pady=(16, 2))
        tk.Label(win, text="Paste an IAM access key. It is stored only in the standard\n"
                           "~/.aws/credentials file on this computer.",
                 font=self.ui, bg=C_PANEL, fg=C_DIM, justify="left").pack(anchor="w", padx=18)

        def field(label, show=""):
            tk.Label(win, text=label, font=self.ui, bg=C_PANEL, fg=C_DIM
                     ).pack(anchor="w", padx=18, pady=(8, 0))
            var = tk.StringVar()
            e = tk.Entry(win, textvariable=var, show=show, font=("Consolas", 10),
                         bg=C_ENTRY, fg=C_FG, relief="flat", insertbackground=C_ACCENT,
                         bd=0, width=46)
            e.pack(anchor="w", padx=18, ipady=5)
            return var

        ak = field("AWS Access Key ID  (e.g. AKIA...)")
        sk = field("AWS Secret Access Key", show="•")
        pk = field("Profile name (save as)", )
        pk.set(self.profile_var.get() if not self.profile_var.get().startswith("+") else "default")
        tk.Label(win, text="Region", font=self.ui, bg=C_PANEL, fg=C_DIM
                 ).pack(anchor="w", padx=18, pady=(8, 0))
        rvar = tk.StringVar(value=self.region_var.get())
        ttk.Combobox(win, textvariable=rvar, values=[f"{c}  ({n})" for c, n in REGIONS],
                     font=self.ui, width=44).pack(anchor="w", padx=18)
        save_var = tk.BooleanVar(value=True)
        tk.Checkbutton(win, text="Save to ~/.aws/credentials (standard AWS file, reusable by "
                                 "other AWS tools)", variable=save_var, font=self.ui,
                       bg=C_PANEL, fg=C_FG, selectcolor=C_ENTRY, activebackground=C_PANEL,
                       activeforeground=C_FG, highlightthickness=0, anchor="w",
                       justify="left", wraplength=470).pack(anchor="w", padx=18, pady=(10, 4))

        def do_connect():
            access, secret = ak.get().strip(), sk.get().strip()
            if not access or not secret:
                messagebox.showwarning("Missing", "Both the Access Key ID and Secret Key are "
                                                  "required.", parent=win)
                return
            region = rvar.get().split(" ")[0]
            prof = pk.get().strip() or "default"
            if save_var.get():
                try:
                    save_credentials_profile(prof, access, secret, region)
                except Exception as e:
                    self._append("warn", f"Could not save credentials file: {e}")
            win.destroy()
            if getattr(self.mgr, "demo", False):
                self.mgr = AwsManager()
                self.demo_btn.configure(text="Try Demo Mode (no AWS needed)")
            self._refresh_profiles()
            self.profile_var.set(prof)
            self.region_var.set(next((f"{c}  ({n})" for c, n in REGIONS if c == region),
                                     self.region_var.get()))
            self.busy = False
            self._append("dim", f"Connecting with profile '{prof}' in {region}...")
            keys = {"access_key": access, "secret_key": secret}
            threading.Thread(target=self._connect_worker, args=(prof, region, keys),
                             daemon=True).start()

        btns = tk.Frame(win, bg=C_PANEL)
        btns.pack(fill="x", padx=18, pady=12)
        self._btn(btns, "Save & Connect", do_connect, primary=True).pack(side="right")
        self._btn(btns, "Cancel", win.destroy).pack(side="right", padx=6)

    def _help_window(self):
        win = tk.Toplevel(self.root)
        win.title("RCW - AWSNixOps · Command reference")
        win.geometry("860x640")
        win.configure(bg=C_CHAT)
        t = tk.Text(win, bg=C_CHAT, fg="#a9bcd6", font=self.mono, wrap="word",
                    relief="flat", padx=14, pady=12)
        sb = ttk.Scrollbar(win, command=t.yview)
        t.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        t.pack(fill="both", expand=True)
        from .help_text import HELP
        t.insert("1.0", HELP)
        t.configure(state="disabled")

    def _audit_window(self):
        entries = self.audit.tail(100)
        win = tk.Toplevel(self.root)
        win.title("RCW - AWSNixOps · Audit log (last 100 actions)")
        win.geometry("980x560")
        win.configure(bg=C_CHAT)
        t = tk.Text(win, bg=C_CHAT, fg="#a9bcd6", font=self.mono, wrap="none",
                    relief="flat", padx=14, pady=12)
        sb = ttk.Scrollbar(win, command=t.yview)
        t.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        t.pack(fill="both", expand=True)
        if not entries:
            t.insert("1.0", "(audit log empty - it fills up as you run commands)")
        for e in reversed(entries):
            t.insert("end", f"{e.get('ts')}  [{e.get('profile')}@{e.get('region')}]  "
                            f"{e.get('command')}\n")
        t.configure(state="disabled")

    def _setup_guide(self):
        win = tk.Toplevel(self.root)
        win.title("AWS setup guide")
        win.geometry("720x560")
        win.configure(bg=C_CHAT)
        t = tk.Text(win, bg=C_CHAT, fg=C_FG, font=self.ui, wrap="word", relief="flat",
                    padx=16, pady=14)
        sb = ttk.Scrollbar(win, command=t.yview)
        t.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        t.pack(fill="both", expand=True)
        t.insert("1.0", """HOW TO GET AWS CREDENTIALS (2 minutes)
=====================================

1. Sign in to the AWS console (https://console.aws.amazon.com).

2. Create an IAM user for yourself (or ask your admin):
   IAM -> Users -> Create user -> e.g. 'rcw-ops' -> allow console access if wanted.

3. Attach permissions:
   For full control: attach policy 'AdministratorAccess'
   (safer: PowerUserAccess + IAM read, or scope policies per service)

4. Create the access key:
   IAM -> Users -> your user -> Security credentials -> Create access key
   -> choose 'Local code / CLI' use case -> copy the Access Key ID and Secret.

5. Back here: click 'Configure AWS...' and paste both values, pick a region
   (e.g. ap-south-1 Mumbai) and press 'Save & Connect'.

NOTES
-----
* Keys are stored ONLY in the standard ~/.aws/credentials file on this PC.
* Never share the secret key or commit it to git.
* If a key leaks: make it inactive in IAM immediately and create a new one.
* The tool logs every action it takes into the logs/ folder (audit trail).
""")
        t.configure(state="disabled")

    def _about(self):
        messagebox.showinfo(
            "About", f"{APP_NAME} v{VERSION}\n\nDeploy & manage AWS services through "
                     f"plain-English prompts.\nBuilt with Python + Tkinter + boto3.\n\n"
                     f"Rule-based NLU - no external API calls, works offline for parsing.\n"
                     f"Destructive actions always require confirmation.\n"
                     f"Every action is audited to logs/.", parent=self.root)

    # ---------------------------------------------------------------- autoshot (screenshots)
    def _autoshot(self, cmds: list):
        if not cmds:
            return
        nxt = cmds.pop(0)
        self._dispatch(nxt)
        if cmds:
            self.root.after(1400, lambda: self._autoshot(cmds))


def launch(demo: bool = False, autoshot: list | None = None):
    root = tk.Tk()
    App(root, demo=demo, autoshot=autoshot)
    root.mainloop()
