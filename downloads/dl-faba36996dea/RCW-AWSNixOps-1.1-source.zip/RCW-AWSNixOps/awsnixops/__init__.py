"""RCW - AWSNixOps :: Deploy & manage AWS services through plain-English prompts (GUI only)."""

__version__ = "1.1.0"
APP_NAME = "RCW - AWSNixOps"
