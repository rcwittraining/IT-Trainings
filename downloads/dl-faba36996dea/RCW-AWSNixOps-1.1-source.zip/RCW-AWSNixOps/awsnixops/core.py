"""RCW - AWSNixOps core: app metadata, config, regions, audit log, AWS session manager.

No boto3 import at module level - everything is imported lazily so the GUI
(including Demo mode) starts even before dependencies are installed.
"""
from __future__ import annotations

import json
import os
import threading
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

APP_NAME = "RCW - AWSNixOps"
VERSION = "1.1.0"

APP_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = APP_DIR / "config.json"
LOG_DIR = APP_DIR / "logs"
KEYS_DIR = APP_DIR / "keys"

# ----------------------------------------------------------------------------- messages

@dataclass
class Msg:
    """A message rendered in the GUI chat log."""
    kind: str  # head | info | ok | warn | err | mono | clear
    text: str


def info(text: str) -> Msg:   return Msg("info", text)
def ok(text: str) -> Msg:     return Msg("ok", text)
def warn(text: str) -> Msg:   return Msg("warn", text)
def err(text: str) -> Msg:    return Msg("err", text)
def head(text: str) -> Msg:   return Msg("head", text)
def mono(text: str) -> Msg:   return Msg("mono", text)
def clear() -> Msg:           return Msg("clear", "")

# ----------------------------------------------------------------------------- regions

REGIONS: list[tuple[str, str]] = [
    ("us-east-1", "N. Virginia"), ("us-east-2", "Ohio"),
    ("us-west-1", "N. California"), ("us-west-2", "Oregon"),
    ("af-south-1", "Cape Town"), ("ap-east-1", "Hong Kong"),
    ("ap-south-1", "Mumbai"), ("ap-south-2", "Hyderabad"),
    ("ap-southeast-1", "Singapore"), ("ap-southeast-2", "Sydney"),
    ("ap-southeast-3", "Jakarta"), ("ap-southeast-4", "Melbourne"),
    ("ap-southeast-5", "Malaysia"), ("ap-northeast-1", "Tokyo"),
    ("ap-northeast-2", "Seoul"), ("ap-northeast-3", "Osaka"),
    ("ca-central-1", "Canada Central"), ("ca-west-1", "Calgary"),
    ("eu-central-1", "Frankfurt"), ("eu-central-2", "Zurich"),
    ("eu-west-1", "Ireland"), ("eu-west-2", "London"), ("eu-west-3", "Paris"),
    ("eu-north-1", "Stockholm"), ("eu-south-1", "Milan"), ("eu-south-2", "Spain"),
    ("il-central-1", "Tel Aviv"), ("me-central-1", "UAE"), ("me-south-1", "Bahrain"),
    ("sa-east-1", "Sao Paulo"),
    ("us-gov-east-1", "GovCloud East"), ("us-gov-west-1", "GovCloud West"),
]

REGION_ALIASES = {
    "virginia": "us-east-1", "north virginia": "us-east-1", "northern virginia": "us-east-1",
    "n virginia": "us-east-1", "ohio": "us-east-2", "california": "us-west-1",
    "oregon": "us-west-2", "cape town": "af-south-1", "south africa": "af-south-1",
    "hong kong": "ap-east-1", "mumbai": "ap-south-1", "india": "ap-south-1",
    "hyderabad": "ap-south-2", "singapore": "ap-southeast-1", "sydney": "ap-southeast-2",
    "australia": "ap-southeast-2", "jakarta": "ap-southeast-3", "indonesia": "ap-southeast-3",
    "melbourne": "ap-southeast-4", "malaysia": "ap-southeast-5", "kuala lumpur": "ap-southeast-5",
    "tokyo": "ap-northeast-1", "japan": "ap-northeast-1", "seoul": "ap-northeast-2",
    "korea": "ap-northeast-2", "osaka": "ap-northeast-3", "canada": "ca-central-1",
    "calgary": "ca-west-1", "frankfurt": "eu-central-1", "germany": "eu-central-1",
    "zurich": "eu-central-2", "switzerland": "eu-central-2", "ireland": "eu-west-1",
    "dublin": "eu-west-1", "london": "eu-west-2", "uk": "eu-west-2",
    "paris": "eu-west-3", "france": "eu-west-3", "stockholm": "eu-north-1",
    "milan": "eu-south-1", "italy": "eu-south-1", "spain": "eu-south-2", "madrid": "eu-south-2",
    "tel aviv": "il-central-1", "israel": "il-central-1", "uae": "me-central-1",
    "dubai": "me-central-1", "bahrain": "me-south-1", "sao paulo": "sa-east-1",
    "brazil": "sa-east-1",
}
REGION_ALIASES.update({name.lower(): code for code, name in REGIONS})

def region_code_for(word: str) -> str | None:
    w = (word or "").strip().lower().replace("_", "-")
    if not w:
        return None
    if w in REGION_ALIASES:
        return REGION_ALIASES[w]
    # allow "ap south 1" / "ap-south-1" / "apsouth1"
    squashed = w.replace(" ", "").replace("-", "")
    for code, _name in REGIONS:
        if squashed == code.replace("-", ""):
            return code
    return None

def region_name_for(code: str) -> str:
    for c, n in REGIONS:
        if c == code:
            return n
    return code

def default_region() -> str:
    env = os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION")
    if env and region_code_for(env):
        return env
    return "ap-south-1"  # sensible default for the user's location (India); changeable in GUI

# ----------------------------------------------------------------------------- config

def load_config() -> dict:
    try:
        if CONFIG_PATH.exists():
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}

def save_config(cfg: dict) -> None:
    try:
        CONFIG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except Exception:
        pass

# ----------------------------------------------------------------------------- audit

class AuditLog:
    """Append-only JSONL audit trail of every AWS action executed from the GUI."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        LOG_DIR.mkdir(exist_ok=True)

    def log(self, raw: str, profile: str, region: str, summary: str) -> None:
        entry = {
            "ts": datetime.now().isoformat(timespec="seconds"),
            "profile": profile,
            "region": region,
            "command": raw,
            "result": summary,
        }
        try:
            with self._lock:
                path = LOG_DIR / f"audit-{datetime.now():%Y-%m-%d}.jsonl"
                with path.open("a", encoding="utf-8") as fh:
                    fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception:
            pass  # never crash the app because of logging

    def tail(self, n: int = 50) -> list[dict]:
        entries: list[dict] = []
        try:
            files = sorted(LOG_DIR.glob("audit-*.jsonl"), reverse=True)
            for f in files:
                lines = f.read_text(encoding="utf-8").splitlines()
                for line in reversed(lines):
                    if line.strip():
                        try:
                            entries.append(json.loads(line))
                        except Exception:
                            pass
                    if len(entries) >= n:
                        return entries
        except Exception:
            pass
        return entries

# ----------------------------------------------------------------------------- AWS session

def available_profiles() -> list[str]:
    """Profiles found in ~/.aws/credentials (the standard AWS file the GUI can write to)."""
    path = Path.home() / ".aws" / "credentials"
    names: list[str] = []
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("[") and line.endswith("]"):
                names.append(line[1:-1].strip())
    except Exception:
        pass
    if not names and (os.environ.get("AWS_ACCESS_KEY_ID") and os.environ.get("AWS_SECRET_ACCESS_KEY")):
        names.append("env")
    return names

def save_credentials_profile(profile: str, access_key: str, secret_key: str, region: str) -> None:
    """Persist credentials to ~/.aws/credentials (standard format used by all AWS tooling)."""
    creds_path = Path.home() / ".aws" / "credentials"
    creds_path.parent.mkdir(parents=True, exist_ok=True)
    sections: dict[str, list[str]] = {}
    current = "default"
    try:
        for line in creds_path.read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if s.startswith("[") and s.endswith("]"):
                current = s[1:-1].strip()
                sections[current] = []
            elif current:
                sections.setdefault(current, []).append(line)
    except Exception:
        pass
    block = [
        f"aws_access_key_id = {access_key.strip()}",
        f"aws_secret_access_key = {secret_key.strip()}",
    ]
    if region:
        block.append(f"region = {region}")
    sections[profile.strip() or "default"] = block
    out_lines: list[str] = []
    for name, lines in sections.items():
        out_lines.append(f"[{name}]")
        out_lines.extend(lines)
        out_lines.append("")
    creds_path.write_text("\n".join(out_lines), encoding="utf-8")


class AwsManager:
    """Holds the boto3 Session for the current profile/region. Thread-safe client cache."""

    def __init__(self) -> None:
        self.profile = "default"
        self.region = default_region()
        self.identity: dict = {}
        self.demo = False
        self._session = None
        self._clients: dict = {}
        self._lock = threading.Lock()

    # -- lifecycle ------------------------------------------------------------
    @property
    def connected(self) -> bool:
        return bool(self.identity or self.demo)

    def disconnect(self) -> None:
        with self._lock:
            self._session = None
            self._clients = {}
            self.identity = {}
            self.demo = False

    def set_region(self, region: str) -> None:
        self.region = region
        with self._lock:  # force fresh clients
            self._clients = {}
            self._session = None

    def _boto3(self):
        import boto3  # lazy
        return boto3

    def connect(self, profile: str | None = None, region: str | None = None,
                keys: dict | None = None) -> dict:
        """Create a session and verify it with STS. Returns caller identity dict."""
        boto3 = self._boto3()
        with self._lock:
            self._clients = {}
            self.demo = False
            if profile:
                self.profile = profile
            if region:
                self.region = region
            if keys and keys.get("access_key"):
                self._session = boto3.Session(
                    aws_access_key_id=keys["access_key"],
                    aws_secret_access_key=keys.get("secret_key", ""),
                    region_name=self.region,
                )
            else:
                self._session = boto3.Session(profile_name=self.profile,
                                              region_name=self.region)
            sts = self._session.client("sts")
            ident = sts.get_caller_identity()
            self.identity = {
                "account": ident.get("Account", "?"),
                "arn": ident.get("Arn", "?"),
                "user": ident.get("Arn", "?").split("/")[-1],
            }
            return self.identity

    def client(self, service: str):
        with self._lock:
            if not self._session:
                raise RuntimeError("Not connected. Use the 'Connect' button in the sidebar "
                                   "(or 'Configure AWS' to enter credentials).")
            if service not in self._clients:
                self._clients[service] = self._session.client(service)
            return self._clients[service]
