"""Built-in command reference shown by the 'help' prompt and the Help menu."""

HELP = r"""
RCW - AWSNixOps :: COMMAND REFERENCE
====================================
Type plain English. Region can be appended to any command ("... in mumbai").
Chain commands with "then" or ";". Everything runs from this window - no CLI.

GETTING STARTED
  whoami                              who am I connected as?
  regions                             list all AWS regions
  use region mumbai                   switch region (city names work)
  use profile myprofile               switch AWS credentials profile
  cost last 7 days                    spend report by service
  cost this month
  open ec2 console                    open the AWS web console in browser
  audit                               recent actions taken from this tool
  help                                this screen

EC2 (virtual machines)
  list instances [running|stopped]
  create instance web1 t3.medium with ports 22 and 80
  create 2 instances in mumbai t3.large named worker
  create windows instance win1 t3.medium
  start i-0abc123 / stop i-0abc123 / reboot i-0abc123
  stop all running instances
  terminate i-0abc123                 (asks for confirmation)
  describe instance i-0abc123
  create alarm high-cpu for instance i-0abc123 at 80

NETWORK
  list vpcs / create vpc 10.0.0.0/16 named prod
  list subnets / create subnet 10.0.1.0/24 in vpc vpc-123
  list sg / create security group web-sg with ports 80 and 443
  open port 8080 on sg web-sg
  open port 22 from 1.2.3.4/32 on sg web-sg
  close port 22 on sg web-sg
  list keypairs / create keypair deploy-key / delete keypair old-key
  list volumes / create volume 100gb / attach volume vol-1 to instance i-2
  list snapshots / create snapshot of volume vol-1
  list eips / create eip / associate eip 3.1.2.3 with instance i-1 / release eip eipalloc-1
  list amis / describe ami ami-0abc

S3 (object storage)
  list buckets
  create bucket my-unique-name-2026
  describe bucket my-bucket             size + object count
  list objects in bucket my-bucket
  upload C:\reports\q1.pdf to bucket reports as docs/q1.pdf
  download bucket reports docs/q1.pdf to C:\Users\me\Downloads
  empty bucket my-bucket                delete all objects (confirm)
  delete bucket my-bucket

LAMBDA
  list functions
  invoke function my-fn with payload {"k": 1}
  create function my-fn from C:\code.zip with role lambda-execute runtime python3.12
  delete function my-fn

RDS (databases)
  list dbs
  create db appdb postgres t3.micro        (password generated & shown once)
  create mysql db named blogdb
  describe db appdb / stop db appdb / start db appdb / delete db appdb

DYNAMODB
  list tables
  create table orders with key order_id
  list items in table orders
  put item {"id":"1","qty":2} into table orders
  describe table orders / delete table orders

IAM
  list users / create user alice / delete user alice
  list roles / list policies
  attach policy AmazonS3FullAccess to user alice
  detach policy AdministratorAccess from user alice
  create access key for user alice

CLOUDWATCH
  list alarms / describe alarm high-cpu / delete alarm high-cpu
  list log groups
  logs /aws/lambda/my-fn                  tail latest log lines

CONTAINERS
  list clusters / list services / list taskdefs        (ECS)
  list repos / create repo my-app / delete repo my-app (ECR)
  list eks clusters / describe cluster my-eks

LOAD BALANCING & DNS
  list load balancers / list target groups
  list zones
  list records in zone example.com
  create record api.example.com -> 1.2.3.4 in zone example.com
  delete record api.example.com in zone example.com

CLOUDFORMATION
  list stacks / describe stack my-stack
  deploy stack my-stack from C:\templates\vpc.yaml [with iam]
  stack events my-stack / delete stack my-stack

MESSAGING & MORE
  list topics / create topic alerts / publish message "deploy done" to topic alerts
  list queues / create queue jobs / send message "job 1" to queue jobs
  list eks clusters / list keys (KMS) / list secrets
  create secret my-api-key with value abc123 / describe secret my-api-key
  list distributions (CloudFront) / list asgs / list cache clusters / list apis

ANYTHING ELSE (full AWS coverage)
  boto3 <service> <operation> {json args}
  e.g. boto3 firehose list_delivery_streams {}
       boto3 batch describe_job_queues {}
  aws <cli command>                        if AWS CLI is installed

NOTES
  * Destructive actions always ask for confirmation first.
  * Tick 'Dry run' in the sidebar to preview without executing.
  * Every action is written to logs/audit-*.jsonl.
"""
