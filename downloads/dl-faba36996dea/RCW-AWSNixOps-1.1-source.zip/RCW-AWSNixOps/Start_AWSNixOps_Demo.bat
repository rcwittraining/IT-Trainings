@echo off
REM  RCW - AWSNixOps launcher (DEMO MODE - no AWS account needed)
start "" /min pyw -3 "%~dp0RCW_AWSNixOps.py" --demo 2>nul || start "" /min pythonw "%~dp0RCW_AWSNixOps.py" --demo
