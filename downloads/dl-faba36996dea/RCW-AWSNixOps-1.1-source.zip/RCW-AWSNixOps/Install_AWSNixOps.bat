@echo off
REM ============================================================
REM  RCW - AWSNixOps installer: installs the Python dependency
REM  (boto3). Run this once (double-click), then use
REM  Start_AWSNixOps.bat to open the tool.
REM ============================================================
title RCW - AWSNixOps installer
echo.
echo  RCW - AWSNixOps : installing dependencies...
echo.

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 -m pip install --user -r "%~dp0requirements.txt"
    goto :done
)
where python >nul 2>nul
if %errorlevel%==0 (
    python -m pip install --user -r "%~dp0requirements.txt"
    goto :done
)
echo  Python was not found on this computer.
echo  Install Python 3.10+ from https://www.python.org/downloads/
echo  IMPORTANT: tick "Add python.exe to PATH" during setup.
echo.
pause
exit /b 1

:done
echo.
echo  Done! Now double-click Start_AWSNixOps.bat
echo.
pause
