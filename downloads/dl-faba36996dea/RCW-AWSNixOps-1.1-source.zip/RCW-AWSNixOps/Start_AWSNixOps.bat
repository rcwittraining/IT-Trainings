@echo off
REM ============================================================
REM  RCW - AWSNixOps launcher - opens the GUI window.
REM  (GUI only - no command window stays open.)
REM ============================================================
if not exist "%~dp0logs" mkdir "%~dp0logs"
start "" /min pyw -3 "%~dp0RCW_AWSNixOps.py" 2>"%~dp0logs\error.txt"
if errorlevel 1 start "" /min pythonw "%~dp0RCW_AWSNixOps.py" 2>"%~dp0logs\error.txt"
