# RCW — AWSNixOps

**Deploy and manage AWS services by typing plain English — from a single GUI window.**

> 📦 **Portable edition (v1.1)** — prefer a single double-click `.exe` with zero
> installs? Ask RCW IT Training for the *Portable EXE edition*: one folder,
> bundled Python + tkinter + boto3, no command line anywhere.
> This repository/zip is the *Python source edition* (for developers).

A Windows desktop tool (Python + Tkinter + boto3) with a chat-style interface.
No command line needed anywhere: installation is a double-click, credentials are
entered in a dialog inside the app, and every operation is driven by text prompts
like:

```
create ec2 instance web1 t3.medium with ports 22 and 80 in mumbai
list running instances
cost last 7 days
empty bucket my-data then delete bucket my-data
```

![screenshot](docs/screenshot-main.png)

---

## Quick start (Windows)

| Step | Action |
|------|--------|
| 1 | Install **Python 3.10+** from python.org — tick **"Add python.exe to PATH"** during setup |
| 2 | Double-click **`Install_AWSNixOps.bat`** (one-time; installs boto3) |
| 3 | Double-click **`Start_AWSNixOps.bat`** — the GUI opens |
| 4 | Click **`Configure AWS…`** in the sidebar, paste your Access Key + Secret, pick a region, **Save & Connect** |
| 5 | Type `help` in the prompt box — or explore safely first with **`Start_AWSNixOps_Demo.bat`** (simulated AWS, zero risk) |

Everything else happens in the one window: prompts in the box at the bottom,
results (tables, IDs, errors, hints) in the chat log.

## What it can do (built-in)

- **EC2** — create (auto AMI/keypair/security-group), list, describe, start/stop/reboot/terminate, bulk actions (`stop all running instances`), CPU alarms
- **Networking** — VPCs, subnets, security groups (`open port 8080 on sg web-sg`), key pairs, EBS volumes/snapshots, Elastic IPs
- **S3** — buckets, upload/download, list/empty/delete, size reports
- **Lambda** — create from zip, invoke with JSON payload, logs tail
- **RDS** — create MySQL/Postgres/Aurora (password generated & shown once), start/stop/delete
- **DynamoDB** — tables, scan items, put items
- **IAM** — users, roles, policies attach/detach, access keys
- **CloudWatch** — alarms, log groups, log tailing
- **Containers** — ECS clusters/services/task-defs, ECR repos, EKS clusters
- **Load balancing & DNS** — ALB/NLB/target groups, Route53 zones & records
- **CloudFormation** — deploy stacks from a local template, watch events
- **Messaging** — SNS topics (publish), SQS queues (send)
- **More** — KMS keys, Secrets Manager, CloudFront, Auto Scaling groups, ElastiCache, API Gateway
- **Cost** — `cost last 7 days` / `cost this month` grouped by service
- **ANY other AWS service** — raw mode right in the prompt box:
  `boto3 firehose list_delivery_streams {}` · or pass through the `aws` CLI if installed
- Conveniences — `use region mumbai` (city names work), `open ec2 console`, `whoami`, `audit`, chaining with `then` / `;`

Type `help` (or press **F1**) for the full command reference.

## Safety

- **Destructive actions always ask for confirmation** (delete/terminate/stop/empty/…) — disable per-session in the sidebar if you really want to.
- **Dry-run mode** — tick the box and every prompt is previewed, nothing executes.
- **Audit log** — every action is appended to `logs/audit-YYYY-MM-DD.jsonl` (View → Audit log in the GUI).
- Credentials are stored only in the standard `~/.aws/credentials` file on your own machine — never sent anywhere except AWS.

## Project layout

```
RCW_AWSNixOps.py          entry point (GUI only)
Install_AWSNixOps.bat     one-time dependency install (boto3)
Start_AWSNixOps.bat       launch the tool
Start_AWSNixOps_Demo.bat  launch in demo mode (no AWS account needed)
awsnixops/
  gui.py                  Tkinter app: sidebar, chat log, prompt bar, dialogs
  parser.py               rule-based natural-language parser (67 tested patterns)
  handlers.py             ~120 actions across 25+ AWS services (boto3)
  core.py                 sessions, regions, config, audit log
  demo.py                 simulated AWS account for safe exploration
  help_text.py            built-in command reference
tests/test_parser.py      parser test suite
assets/logo.png           app icon
```

## Extending it

Add a new capability in two steps, e.g. for a "list firehose streams" prompt:

1. `awsnixops/parser.py` → add noun phrases to `RESOURCE_PHRASES` (e.g. `(("firehose",), "firehose", "stream")`).
2. `awsnixops/handlers.py` → add a method and register it in `ACTIONS` as `("firehose", "stream", "list")`.

Anything else is already reachable today via the `boto3 <service> <operation> {json}` escape hatch.

## Troubleshooting

| Symptom | Fix |
|---|---|
| "Missing dependency: boto3" | Run `Install_AWSNixOps.bat` |
| "Python was not found" | Reinstall Python and tick *Add python.exe to PATH* |
| `InvalidClientTokenId` / `SignatureDoesNotMatch` | Re-enter credentials via *Configure AWS…* |
| `AccessDenied` | Your IAM user lacks permission for that action |
| Cost report empty | Enable Cost Explorer in the AWS billing console (IAM/billing perms needed) |
| Clock skew errors | Enable Windows time sync (settings → time & language → sync now) |

## Notes

- Tested with Python 3.10–3.13; the GUI uses only the standard library (Tkinter) plus boto3.
- Rule-based language understanding — **no API keys, no cloud AI calls, works offline for parsing**.
- Demo mode covers EC2, S3, Lambda, RDS, DynamoDB, IAM, CloudWatch, containers, DNS, messaging, cost reports, and more.

*RCW — AWSNixOps v1.0.0 — every action confirmed, audited, and one text box away.*
