RCW AI Log Analyzer — Offline Edition

How to use without internet:
1. Extract this ZIP while you have access to it.
2. Open index.html in Chrome, Edge, Firefox, or another modern browser.
3. Paste logs or choose a local text/log file.

The analyzer is self-contained. It makes no network calls and keeps logs in the browser on this device.
